package com.qmaxsale.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM products ORDER BY name") fun observeProducts(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM customers ORDER BY name") fun observeCustomers(): Flow<List<CustomerEntity>>
    @Query("SELECT * FROM work_periods ORDER BY openedAt DESC") fun observeWorkPeriods(): Flow<List<WorkPeriodEntity>>
    @Query("SELECT * FROM work_periods WHERE isOpen = 1 LIMIT 1") suspend fun getOpenWorkPeriod(): WorkPeriodEntity?
    @Query("SELECT COUNT(*) FROM sales_invoices WHERE createdAt >= :startOfDay AND createdAt < :endOfDay") fun observeTodayInvoiceCount(startOfDay: Long, endOfDay: Long): Flow<Int>
    @Query("SELECT COALESCE(SUM(total),0) FROM sales_invoices WHERE createdAt >= :startOfDay AND createdAt < :endOfDay") fun observeTodaySales(startOfDay: Long, endOfDay: Long): Flow<Double>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveProduct(item: ProductEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveCustomer(item: CustomerEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveWorkPeriod(item: WorkPeriodEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveInvoice(item: SalesInvoiceEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveInvoiceLines(items: List<SalesInvoiceLineEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveStockItem(item: StockItemEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveRecipe(item: RecipeEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveStockMovement(item: StockMovementEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun savePayment(item: PaymentEntity)
}
