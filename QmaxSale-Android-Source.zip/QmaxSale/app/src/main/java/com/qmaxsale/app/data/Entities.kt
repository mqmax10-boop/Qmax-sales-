package com.qmaxsale.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val code: String = "",
    val barcode: String = "",
    val category: String = "عام",
    val purchaseCost: Double = 0.0,
    val sellingPrice: Double = 0.0,
    val stockQuantity: Double = 0.0,
    val imagePath: String? = null,
    val updatedAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val mobile: String = "",
    val governorate: String = "",
    val area: String = "",
    val shopName: String = "",
    val customerCode: String = "",
    val balance: Double = 0.0,
    val updatedAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)

@Entity(tableName = "work_periods")
data class WorkPeriodEntity(
    @PrimaryKey val id: String,
    val openedAt: Long,
    val openingCash: Double = 0.0,
    val closedAt: Long? = null,
    val closingCash: Double? = null,
    val isOpen: Boolean = true,
    val syncPending: Boolean = true
)

@Entity(tableName = "sales_invoices")
data class SalesInvoiceEntity(
    @PrimaryKey val id: String,
    val invoiceNumber: String,
    val customerId: String? = null,
    val workPeriodId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val subtotal: Double,
    val discount: Double = 0.0,
    val total: Double,
    val paid: Double = 0.0,
    val due: Double = 0.0,
    val status: String = "completed",
    val syncPending: Boolean = true
)

@Entity(tableName = "sales_invoice_lines")
data class SalesInvoiceLineEntity(
    @PrimaryKey val id: String,
    val invoiceId: String,
    val productId: String,
    val productNameSnapshot: String,
    val quantity: Double,
    val purchaseCostSnapshot: Double,
    val sellingPriceSnapshot: Double,
    val lineTotal: Double
)

@Entity(tableName = "stock_items")
data class StockItemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val barcode: String = "",
    val quantity: Double = 0.0,
    val syncPending: Boolean = true
)

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val stockItemId: String,
    val quantityPerProduct: Double = 1.0,
    val syncPending: Boolean = true
)

@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey val id: String,
    val stockItemId: String,
    val movementType: String,
    val quantity: Double,
    val beforeQuantity: Double,
    val afterQuantity: Double,
    val reason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val workPeriodId: String? = null,
    val syncPending: Boolean = true
)

@Entity(tableName = "payments")
data class PaymentEntity(
    @PrimaryKey val id: String,
    val invoiceId: String? = null,
    val customerId: String? = null,
    val workPeriodId: String? = null,
    val method: String,
    val amount: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)
