package com.qmaxsale.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1677D2)
private val Ink = Color(0xFF17324D)
private val Bg = Color(0xFFF5F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = LocalDb(this)
        setContent { QmaxApp(db) }
    }
}

private class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "qmax_sale.db", null, 5) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,barcode TEXT,category TEXT,cost REAL DEFAULT 0,price REAL DEFAULT 0,qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,mobile TEXT,governorate TEXT,area TEXT,shop TEXT,balance REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,total REAL,paid REAL,due REAL,method TEXT)")
        db.execSQL("CREATE TABLE invoice_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,qty REAL,price REAL,cost REAL)")
        db.execSQL("CREATE TABLE stock_items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,barcode TEXT,qty REAL DEFAULT 0,code TEXT DEFAULT '',unit TEXT DEFAULT 'قطعة',min_qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE recipes(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'قطعة')")
        db.execSQL("CREATE TABLE stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,stock_item_id INTEGER NOT NULL,type TEXT NOT NULL,quantity REAL NOT NULL,before_qty REAL NOT NULL,after_qty REAL NOT NULL,reason TEXT,invoice_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,work_period_id INTEGER)")
        db.execSQL("CREATE TABLE stock_add_invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,note TEXT)")
        db.execSQL("CREATE TABLE stock_add_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL)")
        db.execSQL("CREATE TABLE work_periods(id INTEGER PRIMARY KEY AUTOINCREMENT,opened_at TEXT DEFAULT CURRENT_TIMESTAMP,opening_cash REAL,closed_at TEXT,is_open INTEGER DEFAULT 1)")
        db.execSQL("ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0")
        db.execSQL("CREATE TABLE invoice_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("ALTER TABLE invoices ADD COLUMN customer_id INTEGER")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0")
            db.execSQL("CREATE TABLE IF NOT EXISTS invoice_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        }
        if (oldVersion < 3) db.execSQL("ALTER TABLE invoices ADD COLUMN customer_id INTEGER")
        if (oldVersion < 4) {
            // Legacy "حساب العمل" entries were incorrectly counted as collected money.
            // Reclassify them as customer credit: remove them from cash movements and
            // recalculate each invoice's actual collected amount and outstanding balance.
            db.execSQL("DELETE FROM invoice_payments WHERE method='حساب العمل'")
            db.execSQL("UPDATE invoices SET paid=COALESCE((SELECT SUM(amount) FROM invoice_payments p WHERE p.invoice_id=invoices.id),0)")
            db.execSQL("UPDATE invoices SET due=MAX(COALESCE(total,0)-COALESCE(paid,0),0)")
            db.execSQL("UPDATE invoices SET method=REPLACE(method,'حساب العمل','حساب العميل') WHERE method LIKE '%حساب العمل%'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE stock_items ADD COLUMN code TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE stock_items ADD COLUMN unit TEXT DEFAULT 'قطعة'")
            db.execSQL("ALTER TABLE stock_items ADD COLUMN min_qty REAL DEFAULT 0")
            db.execSQL("CREATE TABLE IF NOT EXISTS recipes(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'قطعة')")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,stock_item_id INTEGER NOT NULL,type TEXT NOT NULL,quantity REAL NOT NULL,before_qty REAL NOT NULL,after_qty REAL NOT NULL,reason TEXT,invoice_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,work_period_id INTEGER)")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_add_invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,note TEXT)")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_add_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL)")
        }
    }
    fun addProduct(n:String,c:String,b:String,cat:String,cost:Double,price:Double,qty:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost);put("price",price);put("qty",qty) }
        writableDatabase.insert("products",null,v)
    }
    fun products():List<Product> { val a=mutableListOf<Product>();readableDatabase.rawQuery("SELECT id,name,code,barcode,category,cost,price,qty FROM products ORDER BY name",null).use { c->while(c.moveToNext())a.add(Product(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getDouble(5),c.getDouble(6),c.getDouble(7))) };return a }
    fun updateProductDetails(id:Long,n:String,c:String,b:String,cat:String,cost:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost) }
        writableDatabase.update("products",v,"id=?",arrayOf(id.toString()))
    }
    fun updateProductPrice(id:Long,price:Double) {
        val v=ContentValues().apply { put("price",price) }
        writableDatabase.update("products",v,"id=?",arrayOf(id.toString()))
    }
    fun deleteProduct(id:Long) {
        // Invoice lines keep their saved name, quantity, price and cost snapshots.
        writableDatabase.delete("products","id=?",arrayOf(id.toString()))
    }
    fun customerNameExists(name:String, exceptId:Long?=null):Boolean {
        val normalized=name.trim()
        val sql=if(exceptId==null) "SELECT 1 FROM customers WHERE LOWER(TRIM(name))=LOWER(?) LIMIT 1" else "SELECT 1 FROM customers WHERE LOWER(TRIM(name))=LOWER(?) AND id<>? LIMIT 1"
        val args=if(exceptId==null) arrayOf(normalized) else arrayOf(normalized,exceptId.toString())
        readableDatabase.rawQuery(sql,args).use { return it.moveToFirst() }
    }
    fun addCustomer(n:String,m:String,g:String,a:String,s:String):Long {
        if(customerNameExists(n)) return -1L
        val v=ContentValues().apply{put("name",n.trim());put("mobile",m);put("governorate",g);put("area",a);put("shop",s)}
        return writableDatabase.insert("customers",null,v)
    }
    fun updateCustomer(id:Long,n:String,m:String,g:String,a:String,s:String) { val v=ContentValues().apply{put("name",n);put("mobile",m);put("governorate",g);put("area",a);put("shop",s)};writableDatabase.update("customers",v,"id=?",arrayOf(id.toString())) }
    fun customers(query:String=""):List<Customer> { val a=mutableListOf<Customer>();readableDatabase.rawQuery("SELECT id,name,ifnull(mobile,''),ifnull(governorate,''),ifnull(area,''),ifnull(shop,'') FROM customers WHERE name LIKE ? OR mobile LIKE ? OR governorate LIKE ? OR area LIKE ? OR shop LIKE ? ORDER BY name", arrayOf("%$query%","%$query%","%$query%","%$query%","%$query%")).use{c->while(c.moveToNext())a.add(Customer(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5)))};return a }
    fun customerInvoices(id:Long):List<String>{val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT 'فاتورة #'||id||' | الإجمالي '||total||' | مدفوع '||paid||' | متبقي '||due||' | '||created_at FROM invoices WHERE customer_id=? ORDER BY id DESC",arrayOf(id.toString())).use{c->while(c.moveToNext())a.add(c.getString(0))};return a}
    fun customerTotals(id:Long):Pair<Double,Double>{readableDatabase.rawQuery("SELECT ifnull(sum(total),0),ifnull(sum(due),0) FROM invoices WHERE customer_id=?",arrayOf(id.toString())).use{it.moveToFirst();return it.getDouble(0) to it.getDouble(1)}}
    fun totalCustomerOutstanding():Double{readableDatabase.rawQuery("SELECT ifnull(sum(due),0) FROM invoices WHERE customer_id IS NOT NULL",null).use{it.moveToFirst();return it.getDouble(0)}}
    fun collectCustomer(id:Long,amount:Double,method:String):Boolean {
        if(amount<=0.0 || method !in listOf("نقدي","إنستا باي","حساب بنكي")) return false
        val d=writableDatabase; d.beginTransaction()
        try {
            var left=amount
            d.rawQuery("SELECT id,due,paid FROM invoices WHERE customer_id=? AND due>0 ORDER BY id ASC",arrayOf(id.toString())).use { c ->
                while(c.moveToNext() && left>0.009) {
                    val invoiceId=c.getLong(0); val due=c.getDouble(1); val oldPaid=c.getDouble(2)
                    val part=minOf(left,due)
                    val pay=ContentValues().apply{put("invoice_id",invoiceId);put("method",method);put("amount",part)}
                    d.insert("invoice_payments",null,pay)
                    val update=ContentValues().apply{put("paid",oldPaid+part);put("due",(due-part).coerceAtLeast(0.0))}
                    d.update("invoices",update,"id=?",arrayOf(invoiceId.toString()))
                    left-=part
                }
            }
            if(left>0.009) return false
            d.setTransactionSuccessful(); return true
        } finally { d.endTransaction() }
    }
    fun stockItems():List<StockItem> { val a=mutableListOf<StockItem>();readableDatabase.rawQuery("SELECT id,name,ifnull(barcode,''),ifnull(code,''),ifnull(unit,'قطعة'),ifnull(qty,0),ifnull(min_qty,0) FROM stock_items ORDER BY name",null).use{c->while(c.moveToNext())a.add(StockItem(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getDouble(5),c.getDouble(6)))};return a }
    fun addStock(n:String,b:String,code:String,unit:String,q:Double,minQty:Double=0.0) { val v=ContentValues().apply{put("name",n);put("barcode",b);put("code",code);put("unit",unit);put("qty",q);put("min_qty",minQty)};writableDatabase.insert("stock_items",null,v) }
    fun updateStockItem(item:StockItem,n:String,b:String,code:String,unit:String,minQty:Double){val v=ContentValues().apply{put("name",n);put("barcode",b);put("code",code);put("unit",unit);put("min_qty",minQty)};writableDatabase.update("stock_items",v,"id=?",arrayOf(item.id.toString()))}
    fun deleteStockItem(id:Long){writableDatabase.delete("stock_items","id=?",arrayOf(id.toString()))}
    fun hasOpenPeriod():Boolean=readableDatabase.rawQuery("SELECT 1 FROM work_periods WHERE is_open=1 LIMIT 1",null).use{it.moveToFirst()}
    fun canEditStock():Boolean=readableDatabase.rawQuery("SELECT is_open,closed_at FROM work_periods ORDER BY id DESC LIMIT 1",null).use{it.moveToFirst() && it.getInt(0)==0 && !it.isNull(1)}
    fun stockLedger():List<StockMovement>{val a=mutableListOf<StockMovement>();readableDatabase.rawQuery("SELECT m.id,m.stock_item_id,s.name,m.type,m.quantity,m.before_qty,m.after_qty,m.reason,m.created_at FROM stock_movements m JOIN stock_items s ON s.id=m.stock_item_id ORDER BY m.id DESC",null).use{c->while(c.moveToNext())a.add(StockMovement(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getString(7)?:"",c.getString(8)?:""))};return a}
    fun adjustStock(id:Long,newQty:Double,reason:String):Boolean{if(!canEditStock()||newQty<0)return false;val d=writableDatabase;d.beginTransaction();try{val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else return false};val delta=newQty-before;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(newQty,id));val period=d.rawQuery("SELECT id FROM work_periods ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())it.getLong(0) else null};val v=ContentValues().apply{put("stock_item_id",id);put("type","تسوية رصيد");put("quantity",delta);put("before_qty",before);put("after_qty",newQty);put("reason",reason);if(period!=null)put("work_period_id",period)};d.insert("stock_movements",null,v);d.setTransactionSuccessful();return true}finally{d.endTransaction()}}
    fun editStockMovement(m:StockMovement,newAfter:Double,reason:String):Boolean{if(!canEditStock()||newAfter<0)return false;val d=writableDatabase;d.beginTransaction();try{val current=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(m.stockItemId.toString())).use{it.moveToFirst();it.getDouble(0)};val delta=newAfter-m.after;val final=current+delta;if(final<0)return false;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(final,m.stockItemId));val v=ContentValues().apply{put("quantity",newAfter-m.before);put("after_qty",newAfter);put("reason",reason)};d.update("stock_movements",v,"id=?",arrayOf(m.id.toString()));d.execSQL("UPDATE stock_movements SET before_qty=before_qty+?,after_qty=after_qty+? WHERE stock_item_id=? AND id>?",arrayOf(delta,delta,m.stockItemId,m.id));d.setTransactionSuccessful();return true}finally{d.endTransaction()}}

    fun recipes():List<RecipeRow>{val a=mutableListOf<RecipeRow>();readableDatabase.rawQuery("SELECT r.id,r.product_id,p.name,r.stock_item_id,s.name,r.quantity,r.unit FROM recipes r JOIN products p ON p.id=r.product_id JOIN stock_items s ON s.id=r.stock_item_id ORDER BY p.name",null).use{c->while(c.moveToNext())a.add(RecipeRow(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4),c.getDouble(5),c.getString(6)))};return a}
    fun addRecipe(productId:Long,stockId:Long,qty:Double,unit:String){val v=ContentValues().apply{put("product_id",productId);put("stock_item_id",stockId);put("quantity",qty);put("unit",unit)};writableDatabase.insert("recipes",null,v)}
    fun deleteRecipe(id:Long){writableDatabase.delete("recipes","id=?",arrayOf(id.toString()))}
    fun addStockPurchase(rows:List<Pair<Long,Double>>,note:String=""):Boolean{if(rows.isEmpty()||rows.any{it.second<=0})return false;val d=writableDatabase;d.beginTransaction();try{val h=ContentValues().apply{put("note",note)};val invoice=d.insert("stock_add_invoices",null,h);rows.forEach{(id,q)->val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val after=before+q;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,id));val l=ContentValues().apply{put("invoice_id",invoice);put("stock_item_id",id);put("quantity",q)};d.insert("stock_add_lines",null,l);val m=ContentValues().apply{put("stock_item_id",id);put("type","إضافة مخزون");put("quantity",q);put("before_qty",before);put("after_qty",after);put("reason","فاتورة إضافة مخزون #$invoice");put("invoice_id",invoice)};d.insert("stock_movements",null,m)};d.setTransactionSuccessful();return true}finally{d.endTransaction()}}
    fun stockPurchaseInvoices():List<String>{val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT 'فاتورة إضافة #'||h.id||' | '||h.created_at||' | أصناف: '||(SELECT count(*) FROM stock_add_lines l WHERE l.invoice_id=h.id) FROM stock_add_invoices h ORDER BY h.id DESC",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a}
    fun saveSale(lines:List<Pair<Product,Double>>,paid:Double,method:String,customerId:Long?=null) {
        saveSale(lines, mapOf(method to paid.coerceAtLeast(0.0)), 0.0, customerId)
    }
    fun saveSale(lines:List<Pair<Product,Double>>,payments:Map<String,Double>,discount:Double,customerId:Long?=null) {
        val gross=lines.sumOf{it.first.price*it.second}
        val discountValue=(gross*discount.coerceIn(0.0,100.0)/100.0).coerceAtMost(gross)
        val total=(gross-discountValue).coerceAtLeast(0.0)
        // Only real collection methods count as paid. Customer credit is an amount due,
        // never a cash movement and never an invoice_payment row.
        val collected=payments.filterKeys{it!="حساب العميل" && it!="حساب العمل"}.values.filter{it>0.0}.sum().coerceAtMost(total)
        val due=(total-collected).coerceAtLeast(0.0)
        require(due<=0.009 || customerId!=null) { "يجب اختيار العميل لتسجيل المبلغ على حسابه" }
        val d=writableDatabase;d.beginTransaction()
        try {
            val collectedMethods=payments.filterKeys{it!="حساب العميل" && it!="حساب العمل"}.filterValues{it>0.0}.keys
            val methods=(collectedMethods.toList()+if(due>0.009) listOf("حساب العميل") else emptyList()).joinToString(" + ").ifBlank{"غير محدد"}
            val methodLabel=if(methods.contains(" + "))"متعدد" else methods
            val finalMethod=if(methods.contains("حساب العميل") && collectedMethods.isNotEmpty()) "متعدد + حساب العميل" else methodLabel
            val v=ContentValues().apply{put("total",total);put("paid",collected);put("due",due);put("method",finalMethod);put("discount",discountValue);if(customerId!=null)put("customer_id",customerId)}
            val id=d.insert("invoices",null,v)
            lines.forEach{(p,q)->val x=ContentValues().apply{put("invoice_id",id);put("product_id",p.id);put("name",p.name);put("qty",q);put("price",p.price);put("cost",p.cost)};d.insert("invoice_lines",null,x);d.execSQL("UPDATE products SET qty=qty-? WHERE id=?",arrayOf(q,p.id));consumeRecipe(d,p.id,q,id)}
            payments.filterKeys{it!="حساب العميل" && it!="حساب العمل"}.filterValues{it>0.0}.forEach{(method,amount)->val pay=ContentValues().apply{put("invoice_id",id);put("method",method);put("amount",amount)};d.insert("invoice_payments",null,pay)}
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun paymentAccountBalances():Map<String,Double>{
        val result=linkedMapOf("نقدية" to 0.0,"إنستا باي" to 0.0,"حساب بنكي" to 0.0)
        readableDatabase.rawQuery("SELECT CASE WHEN method='نقدي' THEN 'نقدية' ELSE method END,ifnull(sum(amount),0) FROM invoice_payments WHERE method IN ('نقدي','إنستا باي','حساب بنكي') GROUP BY method",null).use{c->while(c.moveToNext())result[c.getString(0)]=c.getDouble(1)}
        return result
    }
    fun paymentMovements(method:String):List<PaymentMovement>{
        val a=mutableListOf<PaymentMovement>()
        val storedMethod=if(method=="نقدية")"نقدي" else method
        readableDatabase.rawQuery("SELECT p.id,p.invoice_id,p.amount,p.created_at FROM invoice_payments p WHERE p.method=? ORDER BY p.id DESC",arrayOf(storedMethod)).use{c->while(c.moveToNext())a.add(PaymentMovement(c.getLong(0),c.getLong(1),c.getDouble(2),c.getString(3)?:""))}
        return a
    }
    fun invoiceSummaries(query:String=""):List<InvoiceSummary>{
        val a=mutableListOf<InvoiceSummary>()
        val q="%$query%"
        readableDatabase.rawQuery("SELECT i.id,ifnull(i.created_at,''),ifnull(i.total,0),ifnull(i.paid,0),ifnull(i.due,0),ifnull(i.method,''),i.customer_id,ifnull(c.name,'عميل نقدي'),ifnull(c.mobile,''),ifnull(c.governorate,''),ifnull(c.shop,''),ifnull(i.discount,0) FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE CAST(i.id AS TEXT) LIKE ? OR ifnull(c.name,'') LIKE ? OR ifnull(c.mobile,'') LIKE ? ORDER BY i.id DESC",arrayOf(q,q,q)).use{c->while(c.moveToNext())a.add(InvoiceSummary(c.getLong(0),c.getString(1),c.getDouble(2),c.getDouble(3),c.getDouble(4),c.getString(5),if(c.isNull(6))null else c.getLong(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),c.getDouble(11)))}
        return a
    }
    fun invoiceLines(invoiceId:Long):List<InvoiceLine>{
        val a=mutableListOf<InvoiceLine>()
        readableDatabase.rawQuery("SELECT id,ifnull(product_id,0),ifnull(name,''),ifnull(qty,0),ifnull(price,0),ifnull(cost,0) FROM invoice_lines WHERE invoice_id=? ORDER BY id",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())a.add(InvoiceLine(c.getLong(0),c.getLong(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getDouble(5)))}
        return a
    }
    fun invoicePayments(invoiceId:Long):Map<String,Double>{
        val result=linkedMapOf("نقدي" to 0.0,"إنستا باي" to 0.0,"حساب بنكي" to 0.0,"حساب العميل" to 0.0)
        readableDatabase.rawQuery("SELECT method,ifnull(sum(amount),0) FROM invoice_payments WHERE invoice_id=? GROUP BY method",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())result[c.getString(0)]=c.getDouble(1)}
        readableDatabase.rawQuery("SELECT ifnull(due,0) FROM invoices WHERE id=?",arrayOf(invoiceId.toString())).use{c->if(c.moveToFirst())result["حساب العميل"]=c.getDouble(0)}
        return result
    }
    fun deleteInvoice(invoiceId:Long):Boolean{
        val d=writableDatabase;d.beginTransaction()
        try{
            val old=mutableListOf<Pair<Long,Double>>()
            d.rawQuery("SELECT ifnull(product_id,0),ifnull(qty,0) FROM invoice_lines WHERE invoice_id=?",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())old.add(c.getLong(0) to c.getDouble(1))}
            if(old.isEmpty() && !invoiceExists(d,invoiceId)) return false
            old.forEach{(productId,qty)->if(productId>0)d.execSQL("UPDATE products SET qty=qty+? WHERE id=?",arrayOf(qty,productId))}
            reverseRecipeMovements(d,invoiceId,false)
            d.delete("invoice_payments","invoice_id=?",arrayOf(invoiceId.toString()))
            d.delete("invoice_lines","invoice_id=?",arrayOf(invoiceId.toString()))
            val removed=d.delete("invoices","id=?",arrayOf(invoiceId.toString()))
            if(removed==0)return false
            d.setTransactionSuccessful();return true
        }finally{d.endTransaction()}
    }
    private fun consumeRecipe(d:SQLiteDatabase,productId:Long,soldQty:Double,invoiceId:Long){d.rawQuery("SELECT stock_item_id,quantity,unit FROM recipes WHERE product_id=?",arrayOf(productId.toString())).use{c->while(c.moveToNext()){val stockId=c.getLong(0);val used=c.getDouble(1)*soldQty;val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val after=before-used;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,stockId));val m=ContentValues().apply{put("stock_item_id",stockId);put("type","خصم بيع");put("quantity",-used);put("before_qty",before);put("after_qty",after);put("reason","بيع منتج #$productId");put("invoice_id",invoiceId)};d.insert("stock_movements",null,m)}}}
    private fun reverseRecipeMovements(d:SQLiteDatabase,invoiceId:Long,clearOriginal:Boolean){
        val totals=mutableListOf<Pair<Long,Double>>()
        d.rawQuery("SELECT stock_item_id,ifnull(sum(quantity),0) FROM stock_movements WHERE invoice_id=? AND type IN ('خصم بيع','إرجاع إلغاء فاتورة','عكس تعديل فاتورة') GROUP BY stock_item_id",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())totals.add(c.getLong(0) to c.getDouble(1))}
        totals.forEach{(stockId,netDelta)->
            val reversal=-netDelta
            if(kotlin.math.abs(reversal)>0.000001){
                val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0}
                val after=before+reversal
                d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,stockId))
                val movementType=if(clearOriginal)"عكس تعديل فاتورة" else "إلغاء فاتورة"
                val m=ContentValues().apply{put("stock_item_id",stockId);put("type",movementType);put("quantity",reversal);put("before_qty",before);put("after_qty",after);put("reason",if(clearOriginal)"إعادة احتساب ريسبي الفاتورة #$invoiceId" else "إلغاء فاتورة #$invoiceId");put("invoice_id",invoiceId)}
                d.insert("stock_movements",null,m)
            }
        }
        if(clearOriginal)d.delete("stock_movements","invoice_id=? AND type IN ('خصم بيع','إرجاع إلغاء فاتورة','عكس تعديل فاتورة')",arrayOf(invoiceId.toString()))
    }

    private fun invoiceExists(d:SQLiteDatabase,id:Long):Boolean{d.rawQuery("SELECT 1 FROM invoices WHERE id=?",arrayOf(id.toString())).use{return it.moveToFirst()}}
    fun updateInvoice(invoiceId:Long,updatedLines:List<InvoiceLine>):Boolean{
        if(updatedLines.any{it.qty<0||it.price<0})return false
        val d=writableDatabase;d.beginTransaction()
        try{
            val old=mutableListOf<InvoiceLine>()
            d.rawQuery("SELECT id,ifnull(product_id,0),ifnull(name,''),ifnull(qty,0),ifnull(price,0),ifnull(cost,0) FROM invoice_lines WHERE invoice_id=?",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())old.add(InvoiceLine(c.getLong(0),c.getLong(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getDouble(5)))}
            if(!invoiceExists(d,invoiceId))return false
            old.forEach{if(it.productId>0)d.execSQL("UPDATE products SET qty=qty+? WHERE id=?",arrayOf(it.qty,it.productId))}
            reverseRecipeMovements(d,invoiceId,true)
            val keep=updatedLines.filter{it.qty>0.0}
            val keepIds=keep.map{it.id}.toSet()
            old.filter{it.id !in keepIds}.forEach{d.delete("invoice_lines","id=? AND invoice_id=?",arrayOf(it.id.toString(),invoiceId.toString()))}
            keep.forEach{line->
                if(line.productId>0){d.execSQL("UPDATE products SET qty=qty-? WHERE id=?",arrayOf(line.qty,line.productId));consumeRecipe(d,line.productId,line.qty,invoiceId)}
                val v=ContentValues().apply{put("qty",line.qty);put("price",line.price);put("name",line.name)}
                d.update("invoice_lines",v,"id=? AND invoice_id=?",arrayOf(line.id.toString(),invoiceId.toString()))
            }
            val discount=d.rawQuery("SELECT ifnull(discount,0) FROM invoices WHERE id=?",arrayOf(invoiceId.toString())).use{c->c.moveToFirst();c.getDouble(0)}
            val total=(keep.sumOf{it.qty*it.price}-discount).coerceAtLeast(0.0)
            val paid=d.rawQuery("SELECT ifnull(sum(amount),0) FROM invoice_payments WHERE invoice_id=?",arrayOf(invoiceId.toString())).use{c->c.moveToFirst();c.getDouble(0)}
            if(paid>total+0.009)return false
            val due=(total-paid).coerceAtLeast(0.0)
            val v=ContentValues().apply{put("total",total);put("paid",paid);put("due",due)}
            d.update("invoices",v,"id=?",arrayOf(invoiceId.toString()))
            d.setTransactionSuccessful();return true
        }finally{d.endTransaction()}
    }
    fun totals():Triple<Double,Double,Int>{readableDatabase.rawQuery("SELECT ifnull(sum(total),0),ifnull(sum(due),0),count(*) FROM invoices WHERE date(created_at)=date('now','localtime')",null).use{it.moveToFirst();return Triple(it.getDouble(0),it.getDouble(1),it.getInt(2))}}
    private fun reportPeriodClause(alias:String="i"):String = "datetime($alias.created_at)>=datetime((SELECT opened_at FROM work_periods ORDER BY id DESC LIMIT 1)) AND ((SELECT closed_at FROM work_periods ORDER BY id DESC LIMIT 1) IS NULL OR datetime($alias.created_at)<=datetime((SELECT closed_at FROM work_periods ORDER BY id DESC LIMIT 1)))"
    fun periodReport():PeriodReport {
        val d=readableDatabase
        val hasPeriod=d.rawQuery("SELECT 1 FROM work_periods ORDER BY id DESC LIMIT 1",null).use{it.moveToFirst()}
        val where=if(hasPeriod) "WHERE ${reportPeriodClause()}" else ""
        val sales=d.rawQuery("SELECT ifnull(sum(total),0),ifnull(sum(due),0),count(*) FROM invoices i $where",null).use{it.moveToFirst();Triple(it.getDouble(0),it.getDouble(1),it.getInt(2))}
        val payments=linkedMapOf("نقدي" to 0.0,"إنستا باي" to 0.0,"حساب بنكي" to 0.0)
        val paymentWhere=if(hasPeriod) "WHERE datetime(created_at)>=datetime((SELECT opened_at FROM work_periods ORDER BY id DESC LIMIT 1)) AND ((SELECT closed_at FROM work_periods ORDER BY id DESC LIMIT 1) IS NULL OR datetime(created_at)<=datetime((SELECT closed_at FROM work_periods ORDER BY id DESC LIMIT 1)))" else ""
        d.rawQuery("SELECT method,ifnull(sum(amount),0) FROM invoice_payments $paymentWhere GROUP BY method",null).use{c->while(c.moveToNext())if(payments.containsKey(c.getString(0)))payments[c.getString(0)]=c.getDouble(1)}
        val items=mutableListOf<SalesProductRow>()
        d.rawQuery("SELECT l.name,ifnull(sum(l.qty),0),ifnull(sum(l.qty*l.price),0) FROM invoice_lines l JOIN invoices i ON i.id=l.invoice_id $where GROUP BY l.name ORDER BY sum(l.qty*l.price) DESC",null).use{c->while(c.moveToNext())items.add(SalesProductRow(c.getString(0),c.getDouble(1),c.getDouble(2)))}
        return PeriodReport(sales.first,sales.second,sales.third,payments,items)
    }
    fun allProductSales():List<SalesProductRow>{val a=mutableListOf<SalesProductRow>();readableDatabase.rawQuery("SELECT name,ifnull(sum(qty),0),ifnull(sum(qty*price),0) FROM invoice_lines GROUP BY name ORDER BY sum(qty*price) DESC",null).use{c->while(c.moveToNext())a.add(SalesProductRow(c.getString(0),c.getDouble(1),c.getDouble(2)))};return a}
    fun inventoryReport():List<InventoryRow>{val a=mutableListOf<InventoryRow>();val d=readableDatabase;d.rawQuery("SELECT name,qty,price,cost FROM products ORDER BY name",null).use{c->while(c.moveToNext()){val sold=d.rawQuery("SELECT ifnull(sum(qty),0) FROM invoice_lines WHERE name=?",arrayOf(c.getString(0))).use{it.moveToFirst();it.getDouble(0)};val current=c.getDouble(1);a.add(InventoryRow(c.getString(0),current,c.getDouble(2),c.getDouble(3),"منتج","وحدة",current+sold,0.0,sold,0.0))}};d.rawQuery("SELECT id,name,qty,unit,min_qty FROM stock_items ORDER BY name",null).use{c->while(c.moveToNext()){val id=c.getLong(0);val current=c.getDouble(2);val incoming=d.rawQuery("SELECT ifnull(sum(quantity),0) FROM stock_movements WHERE stock_item_id=? AND quantity>0",arrayOf(id.toString())).use{it.moveToFirst();it.getDouble(0)};val sold=d.rawQuery("SELECT ifnull(sum(-quantity),0) FROM stock_movements WHERE stock_item_id=? AND quantity<0",arrayOf(id.toString())).use{it.moveToFirst();it.getDouble(0)};val opening=current-incoming+sold;a.add(InventoryRow(c.getString(1),current,0.0,0.0,"صنف مخزون",c.getString(3)?:"قطعة",opening,incoming,sold,c.getDouble(4)))}};return a}
    fun stockAlerts():List<InventoryRow> = inventoryReport().filter{it.quantity<=0.0 || (it.minQty>0.0 && it.quantity<=it.minQty)}
    fun stockValue():Double{readableDatabase.rawQuery("SELECT ifnull(sum(qty*cost),0) FROM products",null).use{it.moveToFirst();return it.getDouble(0)}}
    fun period():String{readableDatabase.rawQuery("SELECT opened_at FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())return "فترة مفتوحة منذ ${it.getString(0)}"};return "لا توجد فترة عمل مفتوحة"}
    fun openPeriod(cash:Double){writableDatabase.execSQL("UPDATE work_periods SET is_open=0 WHERE is_open=1");val v=ContentValues().apply{put("opening_cash",cash)};writableDatabase.insert("work_periods",null,v)}
    fun closePeriod(){writableDatabase.execSQL("UPDATE work_periods SET is_open=0,closed_at=CURRENT_TIMESTAMP WHERE is_open=1")}
}
private data class StockItem(val id:Long,val name:String,val barcode:String,val code:String,val unit:String,val qty:Double,val minQty:Double)
private data class StockMovement(val id:Long,val stockItemId:Long,val stockName:String,val type:String,val quantity:Double,val before:Double,val after:Double,val reason:String,val createdAt:String)
private data class RecipeRow(val id:Long,val productId:Long,val productName:String,val stockId:Long,val stockName:String,val quantity:Double,val unit:String)
private data class Customer(val id:Long,val name:String,val mobile:String,val governorate:String,val area:String,val shop:String)
private data class PaymentMovement(val id:Long,val invoiceId:Long,val amount:Double,val createdAt:String)
private data class InvoiceSummary(val id:Long,val createdAt:String,val total:Double,val paid:Double,val due:Double,val method:String,val customerId:Long?,val customerName:String,val mobile:String,val governorate:String,val shop:String,val discount:Double)
private data class InvoiceLine(val id:Long,val productId:Long,val name:String,val qty:Double,val price:Double,val cost:Double)
private data class Product(val id:Long,val name:String,val code:String,val barcode:String,val category:String,val cost:Double,val price:Double,val qty:Double)
private data class Tile(val name:String,val icon:ImageVector)
private data class SalesProductRow(val name:String,val quantity:Double,val total:Double)
private data class InventoryRow(val name:String,val quantity:Double,val price:Double,val cost:Double,val source:String,val unit:String="وحدة",val opening:Double=0.0,val incoming:Double=0.0,val sold:Double=0.0,val minQty:Double=0.0)
private data class PeriodReport(val sales:Double,val due:Double,val invoices:Int,val payments:Map<String,Double>,val items:List<SalesProductRow>)

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun QmaxApp(db:LocalDb) {
    var page by remember{mutableStateOf("الرئيسية")};var revision by remember{mutableIntStateOf(0)}
    var pendingLines by remember{mutableStateOf<List<Pair<Product,Double>>>(emptyList())}
    var activeCustomer by remember{mutableStateOf<Customer?>(null)}
    var selectedPaymentAccount by remember{mutableStateOf("نقدية")}
    var selectedInvoiceId by remember{mutableStateOf(0L)};var selectedReport by remember{mutableStateOf("تقرير فترة العمل")}
    val tiles=listOf(Tile("نقاط البيع",Icons.Default.PointOfSale),Tile("الفواتير",Icons.Default.Receipt),Tile("حركة المبيعات",Icons.Default.ReceiptLong),Tile("حسابات العملاء",Icons.Default.Groups),Tile("المخزون",Icons.Default.Inventory2),Tile("الحسابات",Icons.Default.AccountBalanceWallet),Tile("التقارير",Icons.Default.Assessment),Tile("إدارة البرنامج",Icons.Default.Settings),Tile("فترة العمل",Icons.Default.Schedule))
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(topBar={if(page!="الرئيسية")TopAppBar(title={Text(page,fontWeight=FontWeight.Bold)},navigationIcon={IconButton(onClick={page="الرئيسية"}){Icon(Icons.Default.ArrowBack,"رجوع")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.White))},containerColor=Bg){pad->
            key(revision){when(page){
                "الرئيسية"->Home(db,tiles,pad){page=it}
                "المنتجات"->Products(db,pad){revision++}
                "نقاط البيع"->POS(db,pad,initialLines=pendingLines,customer=activeCustomer,done={revision++},newInvoice={pendingLines= emptyList();activeCustomer=null;revision++;page="الرئيسية"},openSettlement={lines->pendingLines=lines;page="تسوية الحساب"})
                "تسوية الحساب"->SettlementScreen(db,pendingLines,pad,customerId=activeCustomer?.id,onBack={page="نقاط البيع"},onDone={revision++;pendingLines= emptyList();activeCustomer=null;page="الرئيسية"})
                "الفواتير"->InvoicesPage(db,pad,onSelect={selectedInvoiceId=it;page="عرض الفاتورة"})
                "عرض الفاتورة"->InvoiceDetails(db,selectedInvoiceId,pad,onEdit={page="تعديل الفاتورة"},onDeleted={revision++;page="الفواتير"})
                "تعديل الفاتورة"->InvoiceEditor(db,selectedInvoiceId,pad,onSaved={revision++;page="حركة المبيعات"},onCancel={page="عرض الفاتورة"})
                "حركة المبيعات"->SalesMovements(db,pad,onView={selectedInvoiceId=it;page="عرض الفاتورة"})
                "حسابات العملاء"->Customers(db,pad,onSale={customer->activeCustomer=customer;pendingLines= emptyList();page="نقاط البيع"},onDetails={customer->activeCustomer=customer;page="تفاصيل حساب العميل"},done={revision++})
                "تفاصيل حساب العميل"->CustomerDetails(db,activeCustomer,pad,onSale={customer->activeCustomer=customer;pendingLines= emptyList();page="نقاط البيع"},onEdit={page="تعديل بيانات العميل"},onCollect={page="تحصيل العميل"})
                "تحصيل العميل"->CustomerCollection(db,activeCustomer,pad,onDone={revision++;page="تفاصيل حساب العميل"},onCancel={page="تفاصيل حساب العميل"})
                "تعديل بيانات العميل"->CustomerEditor(activeCustomer,pad,onSave={c,n,m,g,a,shop->db.updateCustomer(c.id,n,m,g,a,shop);activeCustomer=Customer(c.id,n,m,g,a,shop);revision++;page="تفاصيل حساب العميل"},onCancel={page="تفاصيل حساب العميل"})
                "المخزون"->Inventory(db,pad){revision++}
                "الحسابات"->AccountsHome(db,pad,onPayments={page="حركة المدفوعات"},onCustomers={page="عملاء الحسابات"})
                "عملاء الحسابات"->AccountsCustomers(db,pad,onDetails={activeCustomer=it;page="تفاصيل حساب العميل"})
                "حركة المدفوعات"->PaymentAccounts(db,pad,onSelect={selectedPaymentAccount=it;page="كشف حساب $it"})
                "كشف حساب نقدية","كشف حساب إنستا باي","كشف حساب حساب بنكي"->PaymentStatement(db,selectedPaymentAccount,pad)
                "التقارير"->ReportsMenu(pad){selectedReport=it;page=it}
                "تقرير فترة العمل"->PeriodReportPage(db,pad)
                "تقرير مبيعات المنتجات"->ProductSalesReportPage(db,pad)
                "تقرير الجرد"->InventoryReportPage(db,pad)
                "تنبيهات المخزون"->StockAlertsReportPage(db,pad)
                "إدارة البرنامج"->ProgramManagementMenu(pad){page=it}
                "إدارة المخزون"->StockManagementMenu(pad){page=it}
                "أصناف المخزون"->StockCatalog(db,pad){revision++}
                "الريسبي"->RecipeManager(db,pad){revision++}
                "حركة إضافة المخزون"->StockAddInvoicePage(db,pad){revision++}
                "سجلات حركة المخزون"->StockLedgerPage(db,pad){revision++}
                "قائمة المنتجات"->ProductCatalog(db,pad){revision++}
                "حذف المنتجات","تعديل المنتجات","تعديل الأسعار"->ProductManagement(db,page,pad){revision++}
                "فترة العمل"->Work(db,pad){revision++}
            }}
        }
    }
}
@Composable private fun Home(db:LocalDb,tiles:List<Tile>,pad:PaddingValues,open:(String)->Unit){val t=db.totals();val balances=db.paymentAccountBalances();Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){Text("Qmax Sale",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink);Text("إدارة المبيعات والمخزون",color=Color.Gray);Spacer(Modifier.height(14.dp));Card(colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("ملخص اليوم",fontWeight=FontWeight.Bold,fontSize=17.sp);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("مبيعات اليوم",fmt(t.first));Metric("المستحقات",fmt(t.second))};Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("عدد الفواتير",t.third.toString());Metric("رصيد المخزون",fmt(db.stockValue()))};Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("النقدية بالأرصدة",fmt(balances["نقدية"]?:0.0));Metric("إنستا باي بالأرصدة",fmt(balances["إنستا باي"]?:0.0))}}};Spacer(Modifier.height(14.dp));LazyVerticalGrid(columns=GridCells.Fixed(3),modifier=Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){items(tiles){tile->Card(Modifier.height(112.dp).clickable{open(tile.name)},colors=CardDefaults.cardColors(containerColor=Blue)){Column(Modifier.fillMaxSize().padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(tile.icon,tile.name,tint=Color.White,modifier=Modifier.size(30.dp));Spacer(Modifier.height(7.dp));Text(tile.name,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}}}}
@Composable private fun Metric(label:String,value:String){Column{Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=Ink,fontWeight=FontWeight.Bold,fontSize=16.sp)}}
@Composable private fun Products(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var n by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var bar by remember{mutableStateOf("")};var cat by remember{mutableStateOf("")};var cost by remember{mutableStateOf("0")};var price by remember{mutableStateOf("")};var qty by remember{mutableStateOf("0")};var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("إضافة منتج",fontWeight=FontWeight.Bold,fontSize=18.sp)
        Input("اسم المنتج",n,{n=it});Input("كود المنتج",code,{code=it});Input("الباركود",bar,{bar=it});Input("التصنيف",cat,{cat=it})
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Input("سعر الشراء",cost,{cost=it},Modifier.weight(1f),true);Input("سعر البيع *",price,{price=it},Modifier.weight(1f),true)}
        Input("الكمية الافتتاحية",qty,{qty=it},numeric=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        Button(onClick={val selling=price.toDoubleOrNull();if(n.isBlank()){error="اسم المنتج مطلوب"}else if(selling==null||selling<=0.0){error="السعر مطلوب، أدخل سعر بيع صحيحًا"}else{db.addProduct(n,code,bar,cat,cost.toDoubleOrNull()?:0.0,selling,qty.toDoubleOrNull()?:0.0);n="";code="";bar="";cat="";cost="0";price="";qty="0";error="";done()}},Modifier.fillMaxWidth()){Text("حفظ المنتج")}
        Text("قائمة المنتجات",fontWeight=FontWeight.Bold)
        LazyColumn{items(db.products()){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","الكود ${p.code} | الكمية ${p.qty} | التكلفة ${fmt(p.cost)}")}}
    }
}

@Composable private fun ProgramManagementMenu(pad:PaddingValues,open:(String)->Unit){
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("إدارة البرنامج",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("إدارة المنتجات وبيانات البرنامج",color=Color.Gray)
        Spacer(Modifier.height(10.dp))
        RowCard("قائمة المنتجات","عرض وإضافة وبحث وتعديل وحذف المنتجات وتعديل أسعارها"){open("قائمة المنتجات")}
        RowCard("المخزون","إدارة أصناف المخزون والريسبي والإضافات وسجلات الحركة"){open("إدارة المخزون")}
    }
}

@Composable private fun StockManagementMenu(pad:PaddingValues,open:(String)->Unit){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("إدارة المخزون",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink);RowCard("أصناف المخزون","إضافة صنف بالاسم والباركود والوحدة والكود"){open("أصناف المخزون")};RowCard("الريسبي","ربط منتج المبيعات بأصناف المخزون وكمياتها"){open("الريسبي")};RowCard("حركة إضافة المخزون","إنشاء فاتورة إضافة وزيادة الرصيد القديم"){open("حركة إضافة المخزون")};RowCard("سجلات حركة المخزون","عرض وتعديل السجلات والرصيد بعد إغلاق فترة العمل فقط"){open("سجلات حركة المخزون")}}}


@Composable private fun ProductCatalog(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var query by remember{mutableStateOf("")}
    var selected by remember{mutableStateOf<Product?>(null)}
    var dialog by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    var name by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var barcode by remember{mutableStateOf("")};var category by remember{mutableStateOf("")}
    var cost by remember{mutableStateOf("0")};var price by remember{mutableStateOf("")};var qty by remember{mutableStateOf("0")}
    fun load(p:Product){selected=p;name=p.name;code=p.code;barcode=p.barcode;category=p.category;cost=p.cost.toString();price=p.price.toString();qty=p.qty.toString();error=""}
    val filtered=db.products().filter{it.name.contains(query,true)||it.code.contains(query,true)||it.barcode.contains(query,true)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("قائمة المنتجات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp),label={Text("بحث عن منتج بالاسم أو الكود أو الباركود")},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)})
        Button(onClick={selected=null;name="";code="";barcode="";category="";cost="0";price="";qty="0";error="";dialog="إضافة"},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("إضافة منتج") }
        Spacer(Modifier.height(8.dp))
        Text("المنتجات (${filtered.size})",fontWeight=FontWeight.Bold,color=Ink)
        LazyColumn(Modifier.weight(1f)){
            items(filtered,key={it.id}){p->
                Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.fillMaxWidth().padding(11.dp)){
                        Text(p.name,fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp)
                        Text("الكود: ${p.code.ifBlank{"—"}} | الباركود: ${p.barcode.ifBlank{"—"}}",fontSize=12.sp,color=Color.Gray)
                        Text("سعر البيع: ${fmt(p.price)} ج.م | الكمية: ${fmt(p.qty)}",fontSize=13.sp,color=Ink)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            TextButton(onClick={load(p);dialog="تعديل"},modifier=Modifier.weight(1f)){Icon(Icons.Default.Edit,null);Text("تعديل")}
                            TextButton(onClick={load(p);dialog="السعر"},modifier=Modifier.weight(1f)){Icon(Icons.Default.PriceChange,null);Text("تعديل السعر")}
                            TextButton(onClick={load(p);dialog="حذف"},modifier=Modifier.weight(1f)){Icon(Icons.Default.Delete,null,tint=MaterialTheme.colorScheme.error);Text("حذف",color=MaterialTheme.colorScheme.error)}
                        }
                    }
                }
            }
        }
    }
    if(dialog=="إضافة"||dialog=="تعديل") AlertDialog(
        onDismissRequest={dialog=""},title={Text(if(dialog=="إضافة")"إضافة منتج جديد" else "تعديل بيانات المنتج")},
        text={Column(Modifier.heightIn(max=430.dp)){
            Input("اسم المنتج *",name,{name=it});Input("كود المنتج",code,{code=it});Input("الباركود",barcode,{barcode=it});Input("التصنيف",category,{category=it})
            Input("سعر الشراء",cost,{cost=it},numeric=true)
            if(dialog=="إضافة") {Input("سعر البيع *",price,{price=it},numeric=true);Input("الكمية الافتتاحية",qty,{qty=it},numeric=true)}
            else Text("سعر البيع والكمية لا يتغيران من تعديل البيانات. استخدم زر تعديل السعر لتغيير سعر البيع.",fontSize=12.sp,color=Color.Gray)
            if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
        }},
        confirmButton={TextButton(onClick={
            val c=cost.toDoubleOrNull()?:0.0
            if(name.isBlank())error="اسم المنتج مطلوب"
            else if(c<0.0)error="أدخل تكلفة صحيحة"
            else if(dialog=="إضافة") {val selling=price.toDoubleOrNull();val q=qty.toDoubleOrNull();if(selling==null||selling<=0.0)error="السعر مطلوب، من فضلك أدخل سعر المنتج" else if(q==null||q<0.0)error="أدخل كمية صحيحة" else{db.addProduct(name.trim(),code.trim(),barcode.trim(),category.trim(),c,selling,q);dialog="";error="";done()}}
            else {db.updateProductDetails(selected!!.id,name.trim(),code.trim(),barcode.trim(),category.trim(),c);dialog="";error="";done()}
        }){Text("حفظ")}},dismissButton={TextButton(onClick={dialog="";error=""}){Text("إلغاء")}}
    )
    if(dialog=="السعر") AlertDialog(onDismissRequest={dialog=""},title={Text("تعديل سعر ${selected?.name.orEmpty()}")},text={Column{Input("سعر البيع الجديد *",price,{price=it},numeric=true);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val v=price.toDoubleOrNull();if(v==null||v<=0.0)error="السعر مطلوب ويجب أن يكون أكبر من صفر" else{db.updateProductPrice(selected!!.id,v);dialog="";error="";done()}}){Text("حفظ السعر")}},dismissButton={TextButton(onClick={dialog="";error=""}){Text("إلغاء")}})
    if(dialog=="حذف") AlertDialog(onDismissRequest={dialog=""},title={Text("تأكيد حذف المنتج")},text={Text("هل تريد حذف ${selected?.name.orEmpty()} نهائيًا من قائمة المنتجات؟ ستظل بياناته وأسعاره في الفواتير القديمة محفوظة.")},confirmButton={TextButton(onClick={db.deleteProduct(selected!!.id);dialog="";done()}){Text("حذف",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={dialog=""}){Text("إلغاء")}})
}

@Composable private fun ProductManagement(db:LocalDb,mode:String,pad:PaddingValues,done:()->Unit){
    var selected by remember{mutableStateOf<Product?>(null)}
    var showDeleteConfirm by remember{mutableStateOf(false)}
    var name by remember(selected){mutableStateOf(selected?.name?:"")}
    var code by remember(selected){mutableStateOf(selected?.code?:"")}
    var barcode by remember(selected){mutableStateOf(selected?.barcode?:"")}
    var category by remember(selected){mutableStateOf(selected?.category?:"")}
    var cost by remember(selected){mutableStateOf(selected?.cost?.toString()?:"0")}
    var price by remember(selected){mutableStateOf(selected?.price?.toString()?:"")}
    var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(mode,fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text(when(mode){"حذف المنتجات"->"اختر المنتج المراد حذفه";"تعديل المنتجات"->"اختر المنتج لتعديل بياناته";else->"اختر المنتج لتعديل سعر البيع"},color=Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyColumn{items(db.products(),key={it.id}){p->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{selected=p;if(mode=="حذف المنتجات")showDeleteConfirm=true},colors=CardDefaults.cardColors(containerColor=Color.White)){
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                    Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.SemiBold,color=Ink);Text("السعر: ${fmt(p.price)} ج.م  |  الكود: ${p.code}",fontSize=12.sp,color=Color.Gray)}
                    Text(when(mode){"حذف المنتجات"->"حذف";"تعديل المنتجات"->"تعديل";else->"السعر"},color=Blue,fontWeight=FontWeight.Bold)
                }
            }
        }}
    }
    if(mode=="تعديل المنتجات"&&selected!=null){
        AlertDialog(onDismissRequest={selected=null},title={Text("تعديل بيانات المنتج")},text={Column{Input("اسم المنتج",name,{name=it});Input("كود المنتج",code,{code=it});Input("الباركود",barcode,{barcode=it});Input("التصنيف",category,{category=it});Input("سعر الشراء",cost,{cost=it},numeric=true);Text("سعر البيع لا يتغير من هنا؛ استخدم تعديل الأسعار.",fontSize=12.sp,color=Color.Gray);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val c=cost.toDoubleOrNull();if(name.isBlank())error="اسم المنتج مطلوب" else if(c==null||c<0.0)error="أدخل تكلفة صحيحة" else{db.updateProductDetails(selected!!.id,name,code,barcode,category,c);selected=null;error="";done()}}){Text("حفظ")}},dismissButton={TextButton(onClick={selected=null}){Text("إلغاء")}})
    }
    if(mode=="تعديل الأسعار"&&selected!=null){
        AlertDialog(onDismissRequest={selected=null},title={Text("تعديل سعر ${selected!!.name}")},text={Column{Input("سعر البيع الجديد *",price,{price=it},numeric=true);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val v=price.toDoubleOrNull();if(v==null||v<=0.0)error="السعر مطلوب ويجب أن يكون أكبر من صفر" else{db.updateProductPrice(selected!!.id,v);selected=null;price="";error="";done()}}){Text("حفظ السعر")}},dismissButton={TextButton(onClick={selected=null;error=""}){Text("إلغاء")}})
    }
    if(mode=="حذف المنتجات"&&showDeleteConfirm&&selected!=null){
        AlertDialog(onDismissRequest={showDeleteConfirm=false;selected=null},title={Text("تأكيد حذف المنتج")},text={Text("هل تريد حذف ${selected!!.name}؟ ستظل تفاصيله وأسعاره المسجلة في الفواتير القديمة محفوظة.")},confirmButton={TextButton(onClick={db.deleteProduct(selected!!.id);showDeleteConfirm=false;selected=null;done()}){Text("حذف")}},dismissButton={TextButton(onClick={showDeleteConfirm=false;selected=null}){Text("إلغاء")}})
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun POS(db:LocalDb,pad:PaddingValues,initialLines:List<Pair<Product,Double>>,customer:Customer?,done:()->Unit,newInvoice:()->Unit,openSettlement:(List<Pair<Product,Double>>)->Unit){
    val products=db.products();var cart by remember(initialLines){mutableStateOf(initialLines.associate{it.first.id to it.second})}
    var paymentMethod by remember{mutableStateOf("نقدي")}
    var saveError by remember{mutableStateOf("")}
    var saving by remember{mutableStateOf(false)}
    val lines=products.filter{(cart[it.id]?:0.0)>0}.map{it to (cart[it.id]?:0.0)}
    val total=lines.sumOf{it.first.price*it.second}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("نقاط البيع",fontWeight=FontWeight.Bold,fontSize=20.sp,color=Ink)
        if(customer!=null) Text("العميل: ${customer.name} | ${customer.mobile}",fontWeight=FontWeight.SemiBold,color=Blue)
        Text("نظام الدفع",fontWeight=FontWeight.SemiBold,color=Ink)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            FilterChip(selected=paymentMethod=="نقدي",onClick={paymentMethod="نقدي"},label={Text("نقدي")})
            FilterChip(selected=paymentMethod=="إنستا باي",onClick={paymentMethod="إنستا باي"},label={Text("إنستا باي")})
            OutlinedButton(onClick={if(lines.isNotEmpty())openSettlement(lines)},enabled=lines.isNotEmpty()){Text("تسوية الحساب")}
        }
        Text("الأصناف",fontWeight=FontWeight.Bold,color=Ink)
        LazyColumn(Modifier.weight(0.42f)){
            items(products,key={it.id}){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","اضغط لإضافة الصنف — المتاح ${p.qty}"){cart=cart+(p.id to ((cart[p.id]?:0.0)+1))}}
        }
        Divider(color=Color.LightGray)
        Text("جدول الفاتورة",fontWeight=FontWeight.Bold,fontSize=18.sp,color=Ink)
        Row(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween){
            Text("الصنف",fontWeight=FontWeight.Bold,modifier=Modifier.weight(2f));Text("الكمية",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text("سعر الوحدة",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1.3f));Text("الإجمالي",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1.2f))
        }
        Divider(color=Color.LightGray)
        if(lines.isEmpty()) Text("لم تتم إضافة أصناف للفاتورة بعد",color=Color.Gray,modifier=Modifier.padding(vertical=12.dp))
        LazyColumn(Modifier.weight(0.42f)){
            items(lines,key={it.first.id}){(p,q)->
                Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Text(p.name,modifier=Modifier.weight(2f),fontSize=12.sp)
                        Text(fmt(q),modifier=Modifier.weight(1f),fontSize=12.sp)
                        Text(fmt(p.price),modifier=Modifier.weight(1.3f),fontSize=12.sp)
                        Text(fmt(p.price*q),modifier=Modifier.weight(1.2f),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
                        OutlinedButton(onClick={val next=q-1;cart=if(next<=0)cart-p.id else cart+(p.id to next)}){Text("−")}
                        OutlinedButton(onClick={cart=cart+(p.id to (q+1))}){Text("+")}
                        TextButton(onClick={cart=cart-p.id}){Text("حذف الصنف",color=MaterialTheme.colorScheme.error)}
                    }
                    Divider(color=Color.LightGray)
                }
            }
        }
        Text("إجمالي الفاتورة: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold,fontSize=18.sp,color=Ink,modifier=Modifier.padding(vertical=8.dp))
        if(saveError.isNotBlank()) Text(saveError,color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        Button(
            onClick={
                if(!saving && lines.isNotEmpty()){
                    saving=true
                    saveError=""
                    try {
                        db.saveSale(lines,total,paymentMethod,customer?.id)
                        cart= emptyMap()
                        newInvoice()
                    } catch(e:Exception) {
                        saveError="تعذر حفظ الفاتورة: ${e.localizedMessage ?: "حدث خطأ"}"
                        saving=false
                    }
                }
            },
            modifier=Modifier.fillMaxWidth(),
            enabled=lines.isNotEmpty() && !saving
        ){Text(if(saving)"جارٍ الحفظ..." else "حفظ الفاتورة وإغلاق") }
    }
}

@Composable private fun SettlementScreen(db:LocalDb,lines:List<Pair<Product,Double>>,pad:PaddingValues,customerId:Long?,onBack:()->Unit,onDone:()->Unit){
    val gross=lines.sumOf{it.first.price*it.second}
    var discountText by remember{mutableStateOf("0")}
    // Prefill the first payment method with the invoice total; the user can edit it
    // or split the amount across the other methods.
    var cashText by remember(gross){mutableStateOf(fmt(gross))}
    var bankText by remember{mutableStateOf("0")}
    var instaText by remember{mutableStateOf("0")}
    var customerAccountText by remember(gross){mutableStateOf("0")}
    var cashManuallyEdited by remember{mutableStateOf(false)}
    var saving by remember{mutableStateOf(false)}
    var saveError by remember{mutableStateOf("")}
    val discount=(discountText.toDoubleOrNull()?:0.0).coerceIn(0.0,100.0)
    val total=(gross-gross*discount/100.0).coerceAtLeast(0.0)
    val cash=cashText.toDoubleOrNull()?:0.0;val bank=bankText.toDoubleOrNull()?:0.0;val insta=instaText.toDoubleOrNull()?:0.0
    val customerAccount=customerAccountText.toDoubleOrNull()?:0.0
    val paid=cash+bank+insta
    val allocated=paid+customerAccount
    val remaining=(total-paid).coerceAtLeast(0.0)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("تسوية الحساب",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(12.dp)){
                Text("إجمالي الفاتورة: ${fmt(gross)} ج.م",fontWeight=FontWeight.Bold)
                Input("الخصم %",discountText,{value->
                    discountText=value
                    if(!cashManuallyEdited){
                        val discountValue=(value.toDoubleOrNull()?:0.0).coerceIn(0.0,100.0)
                        cashText=fmt((gross-gross*discountValue/100.0).coerceAtLeast(0.0))
                    }
                },numeric=true)
                Text("الإجمالي بعد الخصم: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold,color=Blue)
                Text("المدفوع: ${fmt(paid)} ج.م")
                Text("المتبقي على العميل: ${fmt(remaining)} ج.م",color=if(remaining<0)Color.Red else Ink,fontWeight=FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(8.dp));Text("طرق الدفع",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
            Input("نقدي",cashText,{cashText=it;cashManuallyEdited=true},Modifier.weight(1f),true)
            Input("إنستا باي",instaText,{instaText=it},Modifier.weight(1f),true)
        }
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
            Input("حساب العميل",customerAccountText,{customerAccountText=it},Modifier.weight(1f),true)
            Input("حساب بنكي",bankText,{bankText=it},Modifier.weight(1f),true)
        }
        Text("حساب العميل يسجل المبلغ الآجل في كشف حساب العميل ولا يُضاف إلى حركة المدفوعات. إجمالي الفاتورة مُدخل تلقائيًا في خانة النقدي ويمكن تقسيم المبلغ.",color=Color.Gray,fontSize=12.sp)
        Text("إجمالي المدفوع فعليًا: ${fmt(paid)} ج.م | المضاف لحساب العميل: ${fmt(customerAccount)} ج.م",color=Ink,fontWeight=FontWeight.SemiBold)
        Text("المتبقي غير المدفوع: ${fmt(remaining)} ج.م يُضاف لمستحقات العميل.",color=Color.Gray,fontSize=12.sp)
        Spacer(Modifier.height(8.dp))
        if(saveError.isNotBlank()) Text(saveError,color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        if(allocated>total+0.009) Text("إجمالي المبالغ الموزعة أكبر من إجمالي الفاتورة.",color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        if(remaining>0.009 && customerId==null) Text("اختر العميل أولاً لتسجيل المبلغ المتبقي على حسابه.",color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick=onBack,modifier=Modifier.weight(1f),enabled=!saving){Text("رجوع")}
            Button(
                onClick={
                    if(!saving && allocated<=total+0.009 && cash>=0 && bank>=0 && insta>=0 && customerAccount>=0 && lines.isNotEmpty() && (remaining<=0.009 || customerId!=null)){
                        saving=true
                        saveError=""
                        try {
                            db.saveSale(lines,mapOf("نقدي" to cash,"حساب بنكي" to bank,"إنستا باي" to insta,"حساب العميل" to customerAccount),discount,customerId)
                            onDone()
                        } catch (e:Exception) {
                            saveError="تعذر حفظ الفاتورة: ${e.localizedMessage ?: "حدث خطأ غير معروف"}"
                            saving=false
                        }
                    }
                },
                modifier=Modifier.weight(1f),
                enabled=!saving && allocated<=total+0.009 && cash>=0 && bank>=0 && insta>=0 && customerAccount>=0 && lines.isNotEmpty() && (remaining<=0.009 || customerId!=null)
            ){Text(if(saving)"جارٍ الحفظ..." else "حفظ الفاتورة وإغلاق")}
        }
    }
}

@Composable private fun Customers(db:LocalDb,pad:PaddingValues,onSale:(Customer)->Unit,onDetails:(Customer)->Unit,done:()->Unit){
    var query by remember{mutableStateOf("")};var showNew by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("حسابات العملاء",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Input("بحث عن عميل بالاسم أو الهاتف أو البيانات",query,{query=it})
        Button(onClick={showNew=true},Modifier.fillMaxWidth()){Text("+ عميل جديد")}
        Text("العملاء المسجلون",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
        val found=db.customers(query)
        if(found.isEmpty())Text(if(query.isBlank())"لا يوجد عملاء مسجلون" else "العميل غير مسجل، يمكنك إضافته من زر عميل جديد",color=Color.Gray,modifier=Modifier.padding(8.dp))
        LazyColumn{items(found,key={it.id}){c->RowCard(c.name,"${c.mobile} | ${c.governorate} | ${c.area} | ${c.shop}"){onDetails(c)}}}
    }
    if(showNew) CustomerFormDialog(null,db,onDismiss={showNew=false},onSave={n,m,g,a,shop->val id=db.addCustomer(n,m,g,a,shop);if(id>0){showNew=false;done()}})
}
@Composable private fun CustomerFormDialog(customer:Customer?,db:LocalDb,onDismiss:()->Unit,onSave:(String,String,String,String,String)->Unit){
    var n by remember(customer){mutableStateOf(customer?.name?:"")};var m by remember(customer){mutableStateOf(customer?.mobile?:"")};var g by remember(customer){mutableStateOf(customer?.governorate?:"")};var a by remember(customer){mutableStateOf(customer?.area?:"")};var shop by remember(customer){mutableStateOf(customer?.shop?:"")};var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(customer==null)"إضافة عميل جديد" else "تعديل بيانات العميل")},text={Column{Input("اسم العميل",n,{n=it});Input("رقم التليفون",m,{m=it},numeric=true);Input("المحافظة",g,{g=it});Input("اسم المنطقة",a,{a=it});Input("اسم المحل",shop,{shop=it});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={if(n.isBlank())error="اسم العميل مطلوب" else if(db.customerNameExists(n,customer?.id))error="هذا الاسم مسجل بالفعل، من فضلك أدخل اسمًا آخر أو ابحث عن العميل المسجل." else{onSave(n,m,g,a,shop)}}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun CustomerDetails(db:LocalDb,customer:Customer?,pad:PaddingValues,onSale:(Customer)->Unit,onEdit:()->Unit,onCollect:()->Unit){
    if(customer==null){Text("لم يتم تحديد عميل",modifier=Modifier.padding(pad));return}
    val totals=db.customerTotals(customer.id)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(customer.name,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("الهاتف: ${customer.mobile} | المحافظة: ${customer.governorate}",color=Color.Gray)
        Text("المنطقة: ${customer.area} | المحل: ${customer.shop}",color=Color.Gray)
        Card(Modifier.fillMaxWidth().padding(vertical=10.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text("إجمالي الفواتير: ${fmt(totals.first)} ج.م",fontWeight=FontWeight.Bold);Text("الرصيد المستحق: ${fmt(totals.second)} ج.م",fontWeight=FontWeight.Bold,color=Blue)}}
        Button(onClick={onSale(customer)},Modifier.fillMaxWidth()){Text("تحديد العميل وبدء فاتورة")}
        OutlinedButton(onClick=onCollect,Modifier.fillMaxWidth()){Text("تحصيل")}
        OutlinedButton(onClick=onEdit,Modifier.fillMaxWidth()){Text("تعديل عميل")}
        Text("تفاصيل الحساب والفواتير",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
        val invoices=db.customerInvoices(customer.id)
        if(invoices.isEmpty())Text("لا توجد فواتير مسجلة لهذا العميل",color=Color.Gray)
        LazyColumn{items(invoices){RowCard(it)}}
    }
}
@Composable private fun CustomerEditor(customer:Customer?,pad:PaddingValues,onSave:(Customer,String,String,String,String,String)->Unit,onCancel:()->Unit){
    if(customer==null)return
    var n by remember(customer){mutableStateOf(customer.name)};var m by remember(customer){mutableStateOf(customer.mobile)};var g by remember(customer){mutableStateOf(customer.governorate)};var a by remember(customer){mutableStateOf(customer.area)};var shop by remember(customer){mutableStateOf(customer.shop)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("تعديل بيانات العميل",fontWeight=FontWeight.Bold,fontSize=20.sp);Input("اسم العميل",n,{n=it});Input("رقم التليفون",m,{m=it},numeric=true);Input("المحافظة",g,{g=it});Input("اسم المنطقة",a,{a=it});Input("اسم المحل",shop,{shop=it});Button(onClick={if(n.isNotBlank())onSave(customer,n,m,g,a,shop)},Modifier.fillMaxWidth()){Text("حفظ التعديلات")};OutlinedButton(onClick=onCancel,Modifier.fillMaxWidth()){Text("إلغاء")}}
}
@Composable private fun Inventory(db:LocalDb,pad:PaddingValues,done:()->Unit){val rows=db.stockItems();Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("المخزون",fontWeight=FontWeight.Bold,fontSize=20.sp);Text("عرض فقط أثناء التشغيل",color=Color.Gray);ReportTableHeader(listOf("الصنف","الكود","الوحدة","الرصيد"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,it.code.ifBlank{"—"},it.unit,fmt(it.qty)))}}}}
@Composable private fun StockCatalog(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var name by remember{mutableStateOf("")}
    var barcode by remember{mutableStateOf("")}
    var code by remember{mutableStateOf("")}
    var unit by remember{mutableStateOf("قطعة")}
    var minQty by remember{mutableStateOf("0")}
    var search by remember{mutableStateOf("")}
    var selected by remember{mutableStateOf<StockItem?>(null)}
    var dialog by remember{mutableStateOf(false)}
    val rows=db.stockItems().filter{it.name.contains(search,true)||it.code.contains(search,true)||it.barcode.contains(search,true)}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("أصناف المخزون",fontSize=20.sp,fontWeight=FontWeight.Bold)
        Input("بحث بالاسم أو الكود أو الباركود",search,{search=it})
        Button(onClick={selected=null;name="";barcode="";code="";unit="قطعة";minQty="0";dialog=true},Modifier.fillMaxWidth()){Text("إضافة صنف")}
        LazyColumn{
            items(rows){item->
                Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(10.dp)){
                        Text(item.name,fontWeight=FontWeight.Bold)
                        Text("الباركود ${item.barcode.ifBlank{"—"}} | الكود ${item.code.ifBlank{"—"}} | الوحدة ${item.unit} | الرصيد ${fmt(item.qty)}",fontSize=12.sp)
                        Row{
                            TextButton(onClick={selected=item;name=item.name;barcode=item.barcode;code=item.code;unit=item.unit;minQty=item.minQty.toString();dialog=true}){Text("تعديل")}
                            TextButton(onClick={db.deleteStockItem(item.id);done()}){Text("حذف",color=MaterialTheme.colorScheme.error)}
                        }
                    }
                }
            }
        }
    }
    if(dialog)AlertDialog(
        onDismissRequest={dialog=false},
        title={Text(if(selected==null)"إضافة صنف مخزون" else "تعديل صنف مخزون")},
        text={Column{
            Input("اسم الصنف",name,{name=it})
            Input("باركود الصنف",barcode,{barcode=it})
            Input("كود الصنف",code,{code=it})
            Input("الوحدة (قطعة / كرتونة...)",unit,{unit=it})
            Input("حد تنبيه انخفاض المخزون",minQty,{minQty=it},numeric=true)
        }},
        confirmButton={TextButton(onClick={
            val min=minQty.toDoubleOrNull()
            if(name.isNotBlank()&&unit.isNotBlank()&&min!=null&&min>=0){
                if(selected==null)db.addStock(name,barcode,code,unit,0.0,min) else db.updateStockItem(selected!!,name,barcode,code,unit,min)
                dialog=false;done()
            }
        }){Text("حفظ")}},
        dismissButton={TextButton(onClick={dialog=false}){Text("إلغاء")}}
    )
}

@Composable private fun RecipeManager(db:LocalDb,pad:PaddingValues,done:()->Unit){val products=db.products();val stocks=db.stockItems();var productId by remember{mutableStateOf(products.firstOrNull()?.id?.toString().orEmpty())};var stockId by remember{mutableStateOf(stocks.firstOrNull()?.id?.toString().orEmpty())};var qty by remember{mutableStateOf("1")};var unit by remember{mutableStateOf("قطعة")};val recipes=db.recipes();Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("الريسبي",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("اختار منتج المبيعات وصنف المخزون والكمية التي تخصم عند بيع وحدة من المنتج",fontSize=12.sp,color=Color.Gray);if(products.isEmpty()||stocks.isEmpty())Text("أضف منتجات المبيعات وأصناف المخزون أولًا",color=MaterialTheme.colorScheme.error);else{var pExpanded by remember{mutableStateOf(false)};var sExpanded by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={pExpanded=true},Modifier.fillMaxWidth()){Text(products.firstOrNull{it.id.toString()==productId}?.name?:"اختيار منتج المبيعات")};DropdownMenu(expanded=pExpanded,onDismissRequest={pExpanded=false}){products.forEach{DropdownMenuItem(text={Text(it.name)},onClick={productId=it.id.toString();pExpanded=false})}}};Box{OutlinedButton(onClick={sExpanded=true},Modifier.fillMaxWidth()){Text(stocks.firstOrNull{it.id.toString()==stockId}?.name?:"اختيار صنف المخزون")};DropdownMenu(expanded=sExpanded,onDismissRequest={sExpanded=false}){stocks.forEach{DropdownMenuItem(text={Text(it.name)},onClick={stockId=it.id.toString();sExpanded=false})}}};Input("الكمية المستهلكة لكل منتج",qty,{qty=it},numeric=true);Input("وحدة الخصم (قطعة / كرتونة)",unit,{unit=it});Button(onClick={val q=qty.toDoubleOrNull();if(q!=null&&q>0){db.addRecipe(productId.toLong(),stockId.toLong(),q,unit);qty="1";done()}},Modifier.fillMaxWidth()){Text("حفظ الريسبي")}};Text("الربط الحالي",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));LazyColumn{items(recipes){r->RowCard("${r.productName} ← ${r.stockName}","${fmt(r.quantity)} ${r.unit} لكل وحدة مباعة"){db.deleteRecipe(r.id);done()}}}}}

@Composable private fun StockAddInvoicePage(db:LocalDb,pad:PaddingValues,done:()->Unit){val stocks=db.stockItems();var selectedId by remember{mutableStateOf(stocks.firstOrNull()?.id?.toString().orEmpty())};var qty by remember{mutableStateOf("1")};var note by remember{mutableStateOf("")};var lines by remember{mutableStateOf<List<Pair<Long,Double>>>(emptyList())};var expanded by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("فاتورة إضافة مخزون",fontSize=20.sp,fontWeight=FontWeight.Bold);if(stocks.isEmpty())Text("أضف أصناف المخزون أولًا",color=MaterialTheme.colorScheme.error)else{Box{OutlinedButton(onClick={expanded=true},Modifier.fillMaxWidth()){Text(stocks.firstOrNull{it.id.toString()==selectedId}?.name?:"اختيار الصنف")};DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){stocks.forEach{DropdownMenuItem(text={Text("${it.name} (${it.unit})")},onClick={selectedId=it.id.toString();expanded=false})}}};Input("الكمية المضافة",qty,{qty=it},numeric=true);Button(onClick={val q=qty.toDoubleOrNull();if(q!=null&&q>0&&selectedId.isNotBlank()){lines=lines+ (selectedId.toLong() to q);qty="1"}},Modifier.fillMaxWidth()){Text("إضافة الصنف للفاتورة")};Input("ملاحظات الفاتورة",note,{note=it});Text("أصناف الفاتورة (${lines.size})",fontWeight=FontWeight.Bold);LazyColumn(Modifier.weight(1f)){items(lines){line->RowCard(stocks.firstOrNull{it.id==line.first}?.name?:"صنف", "الكمية: ${fmt(line.second)}")}};Button(onClick={if(db.addStockPurchase(lines,note)){lines=emptyList();note="";done()}},Modifier.fillMaxWidth(),enabled=lines.isNotEmpty()){Text("حفظ فاتورة الإضافة")}};Text("فواتير الإضافة السابقة",fontWeight=FontWeight.Bold);db.stockPurchaseInvoices().forEach{RowCard(it)}}}

@Composable private fun StockLedgerPage(db:LocalDb,pad:PaddingValues,done:()->Unit){var selected by remember{mutableStateOf<StockMovement?>(null)};var newQty by remember{mutableStateOf("")};var reason by remember{mutableStateOf("")};val locked=!db.canEditStock();val rows=db.stockLedger();Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("سجلات حركة المخزون",fontSize=20.sp,fontWeight=FontWeight.Bold);Text(if(locked)"التعديل متاح فقط بعد إغلاق فترة العمل" else "يمكن تعديل السجلات والرصيد بعد إغلاق فترة العمل",color=if(locked)MaterialTheme.colorScheme.error else Color.Gray,fontSize=12.sp);if(!locked){Text("تعديل الرصيد الحالي",fontWeight=FontWeight.Bold);db.stockItems().forEach{item->RowCard(item.name,"الرصيد الحالي: ${fmt(item.qty)}"){selected=StockMovement(-item.id,item.id,item.name,"تسوية رصيد",0.0,item.qty,item.qty,"تعديل رصيد يدوي","");newQty=item.qty.toString();reason="تسوية رصيد يدوي"}}};LazyColumn{items(rows){m->Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(9.dp)){Text("${m.stockName} — ${m.type}",fontWeight=FontWeight.Bold);Text("${m.createdAt} | كمية ${fmt(m.quantity)} | قبل ${fmt(m.before)} | بعد ${fmt(m.after)}",fontSize=11.sp);Text(m.reason,fontSize=11.sp,color=Color.Gray);if(!locked)TextButton(onClick={selected=m;newQty=m.after.toString();reason=m.reason}){Text("تعديل السجل")}}}}};if(selected!=null)AlertDialog(onDismissRequest={selected=null},title={Text("تعديل رصيد ${selected!!.stockName}")},text={Column{Input("الرصيد الجديد بعد الحركة",newQty,{newQty=it},numeric=true);Input("سبب التعديل",reason,{reason=it})}},confirmButton={TextButton(onClick={val q=newQty.toDoubleOrNull();if(q!=null&&q>=0){val m=selected!!;val ok=if(m.id<0)db.adjustStock(m.stockItemId,q,reason) else db.editStockMovement(m,q,reason);if(ok){selected=null;done()}}}){Text("حفظ")}},dismissButton={TextButton(onClick={selected=null}){Text("إلغاء")}})} }

@Composable private fun ReportsMenu(pad:PaddingValues,open:(String)->Unit){
    val reports=listOf("تقرير فترة العمل","تقرير مبيعات المنتجات","تقرير الجرد","تنبيهات المخزون")
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) { Text("التقارير",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink); Spacer(Modifier.height(10.dp)); reports.forEachIndexed{index,name->Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{open(name)},colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("${index+1}.",fontWeight=FontWeight.Bold,color=Blue);Spacer(Modifier.width(10.dp));Text(name,fontWeight=FontWeight.SemiBold,color=Ink);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronLeft,"فتح",tint=Blue)}}} }
}
@Composable private fun ReportMetric(label:String,value:String){Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(label,color=Color.Gray);Text(value,fontWeight=FontWeight.Bold,color=Ink)}}}
@Composable private fun PeriodReportPage(db:LocalDb,pad:PaddingValues){val r=db.periodReport();val itemTotal=r.items.sumOf{it.total};Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تقرير فترة العمل",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);ReportMetric("إجمالي المبيعات", "${fmt(r.sales)} ج.م");ReportMetric("عدد الفواتير",r.invoices.toString());Text("المدفوعات الفعلية",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp));r.payments.forEach{(m,v)->ReportMetric(m,"${fmt(v)} ج.م")};ReportMetric("إجمالي المدفوعات","${fmt(r.payments.values.sum())} ج.م");ReportMetric("المتبقي على حساب العملاء","${fmt(r.due)} ج.م");Text("مبيعات الأصناف",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));ReportTableHeader(listOf("الصنف","الكمية","النسبة","الإجمالي"));LazyColumn{items(r.items){item->val percent=if(itemTotal>0)item.total*100/itemTotal else 0.0;ReportTableRow(listOf(item.name,fmt(item.quantity),"${fmt(percent)}%","${fmt(item.total)} ج.م"))};item{ReportTableRow(listOf("الإجمالي",fmt(r.items.sumOf{it.quantity}),"${if(itemTotal>0)"100" else "0"}%","${fmt(itemTotal)} ج.م"),true)}}}}
@Composable private fun ProductSalesReportPage(db:LocalDb,pad:PaddingValues){val rows=db.allProductSales();val qty=rows.sumOf{it.quantity};val total=rows.sumOf{it.total};Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تقرير مبيعات المنتجات",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);ReportMetric("إجمالي عدد المنتجات المباعة",fmt(qty));ReportMetric("إجمالي قيمة المبيعات","${fmt(total)} ج.م");ReportTableHeader(listOf("المنتج","الكمية المباعة","إجمالي البيع"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,fmt(it.quantity),"${fmt(it.total)} ج.م"))};item{ReportTableRow(listOf("الإجمالي",fmt(qty),"${fmt(total)} ج.م"),true)}}}}
@Composable private fun InventoryReportPage(db:LocalDb,pad:PaddingValues){val rows=db.inventoryReport();Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تقرير الجرد",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);Text("الأرصدة الحالية وحركة الوارد والمبيع",color=Color.Gray,fontSize=12.sp);ReportTableHeader(listOf("الصنف","الوحدة","افتتاحي","وارد","مبيع","حالي"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,it.unit,fmt(it.opening),fmt(it.incoming),fmt(it.sold),fmt(it.quantity)))};item{ReportTableRow(listOf("الإجمالي","",fmt(rows.sumOf{it.opening}),fmt(rows.sumOf{it.incoming}),fmt(rows.sumOf{it.sold}),fmt(rows.sumOf{it.quantity})),true)}}}}
@Composable private fun StockAlertsReportPage(db:LocalDb,pad:PaddingValues){val rows=db.stockAlerts();Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تنبيهات المخزون",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);ReportMetric("الأصناف النافدة",rows.size.toString());Text("الأصناف النافدة",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp));if(rows.isEmpty())Text("لا توجد أصناف منخفضة أو نافدة",color=Color.Gray,modifier=Modifier.padding(10.dp)) else {ReportTableHeader(listOf("الصنف","النوع","الرصيد","الحالة"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,it.source,fmt(it.quantity),if(it.quantity<=0.0)"نافد" else "منخفض"))}}};Text("يظهر الصنف منخفضًا عند بلوغ حد التنبيه الذي يتم ضبطه للصنف، والنافد عند وصول الرصيد إلى صفر.",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(top=12.dp))}}
@Composable private fun ReportTableHeader(cells:List<String>){Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=4.dp)){cells.forEach{Text(it,Modifier.weight(1f),fontSize=11.sp,fontWeight=FontWeight.Bold,color=Blue)}}}
@Composable private fun ReportTableRow(cells:List<String>,total:Boolean=false){Card(Modifier.fillMaxWidth().padding(vertical=2.dp),colors=CardDefaults.cardColors(containerColor=if(total)Color(0xFFE8F1FB) else Color.White)){Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){cells.forEach{Text(it,Modifier.weight(1f),fontSize=11.sp,fontWeight=if(total)FontWeight.Bold else FontWeight.Normal,color=Ink)}}}}
@Composable private fun Work(db:LocalDb,pad:PaddingValues,done:()->Unit){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("فترة العمل",fontWeight=FontWeight.Bold,fontSize=20.sp);RowCard(db.period());Button(onClick={db.openPeriod(0.0);done()},Modifier.fillMaxWidth()){Text("فتح فترة عمل")};OutlinedButton(onClick={db.closePeriod();done()},Modifier.fillMaxWidth()){Text("إنهاء فترة العمل")}}}
@Composable private fun InvoicesPage(db:LocalDb,pad:PaddingValues,onSelect:(Long)->Unit){
    var query by remember{mutableStateOf("")}
    val rows=db.invoiceSummaries(query)
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("الفواتير",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Input("بحث برقم الفاتورة أو اسم العميل أو الهاتف",query,{query=it})
        if(rows.isEmpty())Text("لا توجد فواتير مطابقة",color=Color.Gray,modifier=Modifier.padding(10.dp))
        LazyColumn{items(rows,key={it.id}){inv->
            RowCard("فاتورة رقم ${inv.id} | ${inv.customerName}","${inv.createdAt} | الإجمالي ${fmt(inv.total)} ج.م | المدفوع ${fmt(inv.paid)} | المتبقي ${fmt(inv.due)} | ${inv.method}"){onSelect(inv.id)}
        }}
    }
}

@Composable private fun InvoiceDetails(db:LocalDb,invoiceId:Long,pad:PaddingValues,onEdit:()->Unit,onDeleted:()->Unit){
    val inv=db.invoiceSummaries(invoiceId.toString()).firstOrNull{it.id==invoiceId}
    if(inv==null){Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){Text("الفاتورة غير موجودة")};return}
    val lines=db.invoiceLines(invoiceId)
    val payments=db.invoicePayments(invoiceId)
    var askDelete by remember(invoiceId){mutableStateOf(false)}
    var deleteMessage by remember(invoiceId){mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تفاصيل الفاتورة رقم ${inv.id}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(12.dp)){
                Text("رقم الفاتورة: ${inv.id}")
                Text("التاريخ: ${inv.createdAt}")
                Text("اسم العميل: ${inv.customerName}")
                Text("رقم العميل: ${inv.mobile.ifBlank{"—"}}")
                Text("اسم المحل: ${inv.shop.ifBlank{"—"}}")
                Text("المحافظة: ${inv.governorate.ifBlank{"—"}}")
                Text("نوع الدفع: ${inv.method}")
                payments.filterValues{it>0}.forEach{(method,amount)->Text("$method: ${fmt(amount)} ج.م",fontSize=12.sp,color=Color.Gray)}
            }
        }
        Text("تفاصيل الأصناف",fontWeight=FontWeight.Bold,color=Ink)
        Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Text("الصنف",Modifier.weight(2f),fontWeight=FontWeight.Bold,fontSize=11.sp)
            Text("الكمية",Modifier.weight(0.8f),fontWeight=FontWeight.Bold,fontSize=11.sp)
            Text("سعر الوحدة",Modifier.weight(1.2f),fontWeight=FontWeight.Bold,fontSize=11.sp)
            Text("الإجمالي",Modifier.weight(1.2f),fontWeight=FontWeight.Bold,fontSize=11.sp)
        }
        Divider()
        LazyColumn(Modifier.weight(1f)){
            items(lines,key={it.id}){line->Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                Text(line.name,Modifier.weight(2f),fontSize=11.sp)
                Text(fmt(line.qty),Modifier.weight(0.8f),fontSize=11.sp)
                Text(fmt(line.price),Modifier.weight(1.2f),fontSize=11.sp)
                Text(fmt(line.qty*line.price),Modifier.weight(1.2f),fontSize=11.sp)
            };Divider()}
        }
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(12.dp)){
                Text("إجمالي الفاتورة: ${fmt(inv.total)} ج.م",fontWeight=FontWeight.Bold)
                Text("المدفوع: ${fmt(inv.paid)} ج.م")
                Text("المتبقي: ${fmt(inv.due)} ج.م",color=if(inv.due>0.009)MaterialTheme.colorScheme.error else Ink,fontWeight=FontWeight.Bold)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(onClick=onEdit,Modifier.weight(1f)){Text("تعديل الفاتورة")}
            OutlinedButton(onClick={askDelete=true},Modifier.weight(1f),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.error)){Text("حذف الفاتورة")}
        }
    }
    if(askDelete)AlertDialog(onDismissRequest={askDelete=false},title={Text("تأكيد حذف الفاتورة")},text={Text("سيتم حذف الفاتورة رقم ${inv.id} وإلغاء كل التحصيلات المرتبطة بها وإرجاع كميات المنتجات والمخزون. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={val ok=db.deleteInvoice(invoiceId);askDelete=false;deleteMessage=if(ok)"تم حذف الفاتورة وعكس حركاتها" else "تعذر حذف الفاتورة"}){Text("حذف نهائي",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={askDelete=false}){Text("إلغاء")}})
    if(deleteMessage.isNotBlank())AlertDialog(onDismissRequest={deleteMessage="";if(!db.invoiceSummaries(invoiceId.toString()).any{it.id==invoiceId})onDeleted()},title={Text("الفواتير")},text={Text(deleteMessage)},confirmButton={TextButton(onClick={val deleted=!db.invoiceSummaries(invoiceId.toString()).any{it.id==invoiceId};deleteMessage="";if(deleted)onDeleted()}){Text("حسنًا")}})
}

@Composable private fun SalesMovements(db:LocalDb,pad:PaddingValues,onView:(Long)->Unit){
    var query by remember{mutableStateOf("")}
    val rows=db.invoiceSummaries(query)
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("حركة المبيعات",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Input("بحث برقم الفاتورة أو اسم العميل أو الهاتف",query,{query=it})
        if(rows.isEmpty())Text("لا توجد حركات مبيعات",color=Color.Gray)
        LazyColumn{items(rows,key={it.id}){inv->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                Column(Modifier.padding(11.dp)){
                    Text("فاتورة رقم ${inv.id} — ${inv.customerName}",fontWeight=FontWeight.Bold,color=Ink)
                    Text("${inv.createdAt} | الإجمالي ${fmt(inv.total)} ج.م | المدفوع ${fmt(inv.paid)} | المتبقي ${fmt(inv.due)}",fontSize=11.sp,color=Color.Gray)
                    OutlinedButton(onClick={onView(inv.id)},Modifier.fillMaxWidth()){Text("عرض")}
                }
            }
        }}
    }
}

@Composable private fun InvoiceEditor(db:LocalDb,invoiceId:Long,pad:PaddingValues,onSaved:()->Unit,onCancel:()->Unit){
    val inv=db.invoiceSummaries(invoiceId.toString()).firstOrNull{it.id==invoiceId}
    if(inv==null){Text("الفاتورة غير موجودة",Modifier.padding(pad));return}
    var lines by remember(invoiceId){mutableStateOf(db.invoiceLines(invoiceId))}
    var error by remember{mutableStateOf("")}
    val total=(lines.filter{it.qty>0}.sumOf{it.qty*it.price}-inv.discount).coerceAtLeast(0.0)
    val paid=inv.paid
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تعديل الفاتورة رقم $invoiceId",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("${inv.customerName} | ${inv.createdAt}",color=Color.Gray,fontSize=12.sp)
        Text("الأصناف والكميات والأسعار",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
        LazyColumn(Modifier.weight(1f)){
            items(lines,key={it.id}){line->
                Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){
                    Text(line.name,fontWeight=FontWeight.SemiBold)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        Input("الكمية",line.qty.toString(),{v->val n=v.toDoubleOrNull();if(n!=null)lines=lines.map{if(it.id==line.id)it.copy(qty=n)else it}},Modifier.weight(1f),true)
                        Input("سعر الوحدة",line.price.toString(),{v->val n=v.toDoubleOrNull();if(n!=null)lines=lines.map{if(it.id==line.id)it.copy(price=n)else it}},Modifier.weight(1f),true)
                    }
                    TextButton(onClick={lines=lines.map{if(it.id==line.id)it.copy(qty=0.0)else it}}){Text("حذف الصنف من الفاتورة",color=MaterialTheme.colorScheme.error)}
                    Divider()
                }
            }
        }
        Text("المدفوع المسجل: ${fmt(paid)} ج.م — يتم الحفاظ على حركات الدفع والتحصيل كما هي.",color=Color.Gray,fontSize=12.sp)
        Text("الإجمالي الجديد: ${fmt(total)} ج.م | المتبقي: ${fmt((total-paid).coerceAtLeast(0.0))} ج.م",fontWeight=FontWeight.Bold,color=Ink,fontSize=12.sp)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick=onCancel,Modifier.weight(1f)){Text("إلغاء")}
            Button(onClick={
                when{paid>total+0.009->error="إجمالي الفاتورة الجديد أقل من المبلغ المدفوع؛ لا يمكن حفظ التعديل";lines.none{it.qty>0}->error="لا يمكن حفظ فاتورة بدون أصناف";db.updateInvoice(invoiceId,lines)->onSaved();else->error="تعذر حفظ تعديل الفاتورة"}
            },Modifier.weight(1f)){Text("حفظ التعديلات")}
        }
    }
}

@Composable private fun ListPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);if(data.isEmpty())Text("لا توجد سجلات حتى الآن",color=Color.Gray);LazyColumn{items(data){RowCard(it)}}}}
@Composable private fun AccountsHome(db:LocalDb,pad:PaddingValues,onPayments:()->Unit,onCustomers:()->Unit){
    val totals=db.totals()
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("الحسابات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        RowCard("الإيرادات","مبيعات اليوم: ${fmt(totals.first)} ج.م | المستحقات: ${fmt(totals.second)} ج.م")
        RowCard("حركة المدفوعات","النقدية وإنستا باي والحساب البنكي"){onPayments()}
        RowCard("العملاء","حسابات العملاء المسجلين وتفاصيل الحساب والتحصيل"){onCustomers()}
        RowCard("قيمة المخزون بالتكلفة: ${fmt(db.stockValue())} ج.م")
    }
}
@Composable private fun AccountsCustomers(db:LocalDb,pad:PaddingValues,onDetails:(Customer)->Unit){
    var query by remember{mutableStateOf("")}
    val customers=db.customers(query)
    val outstanding=db.totalCustomerOutstanding()
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
        Text("حسابات العملاء",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Card(Modifier.fillMaxWidth().padding(vertical=7.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(13.dp)) {
                Text("إجمالي المبالغ غير المحصلة",color=Color.Gray,fontSize=13.sp)
                Text("${fmt(outstanding)} ج.م",fontWeight=FontWeight.Bold,fontSize=23.sp,color=Blue)
            }
        }
        Input("بحث باسم العميل أو الهاتف",query,{query=it})
        Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween){
            Text("العميل",fontWeight=FontWeight.Bold,fontSize=12.sp)
            Text("المديونية  |  المحصل  |  المتبقي",fontWeight=FontWeight.Bold,fontSize=10.sp)
        }
        Divider(color=Color.LightGray)
        LazyColumn { items(customers,key={it.id}) { c ->
            val t=db.customerTotals(c.id)
            val collected=(t.first-t.second).coerceAtLeast(0.0)
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{onDetails(c)},colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(11.dp)) {
                    Text(c.name,fontWeight=FontWeight.Bold,color=Ink)
                    if(c.mobile.isNotBlank()) Text(c.mobile,color=Color.Gray,fontSize=11.sp)
                    Row(Modifier.fillMaxWidth().padding(top=7.dp),horizontalArrangement=Arrangement.SpaceBetween){
                        Column { Text("المديونية",fontSize=10.sp,color=Color.Gray);Text(fmt(t.first),fontSize=12.sp,fontWeight=FontWeight.SemiBold) }
                        Column { Text("المحصل",fontSize=10.sp,color=Color.Gray);Text(fmt(collected),fontSize=12.sp,fontWeight=FontWeight.SemiBold) }
                        Column { Text("المتبقي",fontSize=10.sp,color=Color.Gray);Text(fmt(t.second),fontSize=12.sp,color=Blue,fontWeight=FontWeight.Bold) }
                    }
                    OutlinedButton(onClick={onDetails(c)},modifier=Modifier.fillMaxWidth().padding(top=5.dp)){Text("تفاصيل الحساب")}
                }
            }
        } }
        if(customers.isEmpty()) Text("لا يوجد عملاء مسجلون",color=Color.Gray)
    }
}
@Composable private fun CustomerCollection(db:LocalDb,customer:Customer?,pad:PaddingValues,onDone:()->Unit,onCancel:()->Unit){
    var amount by remember{mutableStateOf("")}; var method by remember{mutableStateOf("نقدي")}; var error by remember{mutableStateOf("")}
    val due=customer?.let{db.customerTotals(it.id).second}?:0.0
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Text("تحصيل عميل",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("العميل: ${customer?.name.orEmpty()}")
        Text("الرصيد المستحق: ${fmt(due)} ج.م",fontWeight=FontWeight.Bold,color=Blue)
        Input("مبلغ التحصيل",amount,{amount=it},numeric=true)
        Text("طريقة التحصيل",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
        listOf("نقدي","إنستا باي","حساب بنكي").forEach{m->FilterChip(selected=method==m,onClick={method=m},label={Text(m)},modifier=Modifier.padding(end=5.dp))}
        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        Button(onClick={val v=amount.toDoubleOrNull();when{customer==null->error="لم يتم تحديد عميل";v==null||v<=0->error="أدخل مبلغ تحصيل صحيح";v>due+0.009->error="مبلغ التحصيل أكبر من الرصيد المستحق";db.collectCustomer(customer.id,v,method)->onDone();else->error="تعذر تسجيل التحصيل"}},Modifier.fillMaxWidth().padding(top=12.dp)){Text("حفظ التحصيل")}
        OutlinedButton(onClick=onCancel,Modifier.fillMaxWidth()){Text("إلغاء")}
    }
}
@Composable private fun PaymentAccounts(db:LocalDb,pad:PaddingValues,onSelect:(String)->Unit){
    val balances=db.paymentAccountBalances()
    val totalPaid=(balances["نقدية"]?:0.0)+(balances["إنستا باي"]?:0.0)+(balances["حساب بنكي"]?:0.0)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("حركة المدفوعات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("إجمالي المدفوعات المسجلة فعليًا",color=Color.Gray,fontSize=12.sp)
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(13.dp)){
                Text("الإجمالي الكلي",color=Color.Gray,fontSize=12.sp)
                Text("${fmt(totalPaid)} ج.م",fontWeight=FontWeight.Bold,fontSize=23.sp,color=Blue)
                Divider(Modifier.padding(vertical=7.dp),color=Color.LightGray)
                listOf("نقدية","إنستا باي","حساب بنكي").forEach{account->
                    Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.SpaceBetween){
                        Text("إجمالي $account",color=Ink,fontSize=13.sp)
                        Text("${fmt(balances[account]?:0.0)} ج.م",fontWeight=FontWeight.SemiBold,fontSize=13.sp)
                    }
                }
            }
        }
        Text("اضغط على الحساب لعرض كشف الحركات",color=Color.Gray,fontSize=12.sp)
        listOf("نقدية","إنستا باي","حساب بنكي").forEach{account->
            RowCard(account,"إجمالي المدفوعات: ${fmt(balances[account]?:0.0)} ج.م | عرض كشف الحساب"){onSelect(account)}
        }
    }
}
@Composable private fun PaymentStatement(db:LocalDb,account:String,pad:PaddingValues){
    val balances=db.paymentAccountBalances()
    val movements=db.paymentMovements(account)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("كشف حساب $account",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(14.dp)){
                Text("الرصيد الحالي",color=Color.Gray)
                Text("${fmt(balances[account]?:0.0)} ج.م",fontWeight=FontWeight.Bold,fontSize=23.sp,color=Blue)
            }
        }
        Text("حركات التحصيل",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=5.dp))
        if(movements.isEmpty()) Text("لا توجد حركات مسجلة لهذا الحساب حتى الآن",color=Color.Gray)
        LazyColumn{items(movements,key={it.id}){m->RowCard("فاتورة رقم ${m.invoiceId} | ${fmt(m.amount)} ج.م","التاريخ: ${m.createdAt}")}}
    }
}
@Composable private fun InfoPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);data.forEach{RowCard(it)}}}
@Composable private fun Input(label:String,value:String,onChange:(String)->Unit,modifier:Modifier=Modifier,numeric:Boolean=false){OutlinedTextField(value,onChange,modifier.fillMaxWidth().padding(vertical=3.dp),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(numeric)KeyboardType.Decimal else KeyboardType.Text))}
@Composable private fun RowCard(title:String,sub:String="",click:(()->Unit)?=null){Card(Modifier.fillMaxWidth().padding(vertical=4.dp).then(if(click!=null)Modifier.clickable{click()}else Modifier),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text(title,fontWeight=FontWeight.SemiBold,color=Ink);if(sub.isNotBlank())Text(sub,color=Color.Gray,fontSize=12.sp)}}}
private fun fmt(v:Double)="%.2f".format(v)
