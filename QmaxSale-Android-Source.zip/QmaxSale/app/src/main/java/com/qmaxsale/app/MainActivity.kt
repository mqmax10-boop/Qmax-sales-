package com.qmaxsale.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Color as AndroidColor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import android.print.PrintManager
import android.print.PrintAttributes
import android.provider.Settings
import android.provider.DocumentsContract
import android.content.Intent
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.ZoneOffset
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.delay
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import android.os.Bundle
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1677D2)
private val Ink = Color(0xFF17324D)
private val Bg = Color(0xFFF5F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = LocalDb(this)
        db.ensureAdmin()
        setContent { QmaxApp(db, this) }
    }
}

private class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "qmax_sale.db", null, 9) {
    private val appContext = ctx.applicationContext
    private val prefs = appContext.getSharedPreferences("qmax_backup", Context.MODE_PRIVATE)
    private val sessionPrefs = appContext.getSharedPreferences("qmax_session", Context.MODE_PRIVATE)
    private val accountPrefs = appContext.getSharedPreferences("qmax_account_settings", Context.MODE_PRIVATE)
    private val reportPrefs = appContext.getSharedPreferences("qmax_report_visibility", Context.MODE_PRIVATE)
    fun isReportVisible(name:String):Boolean = reportPrefs.getBoolean(name, true)
    fun setReportVisible(name:String, visible:Boolean) { reportPrefs.edit().putBoolean(name, visible).apply() }
    fun accountPeriod(key:String):String = accountPrefs.getString(key,"all") ?: "all"
    fun setAccountPeriod(key:String,value:String) { accountPrefs.edit().putString(key,value).apply() }
    private fun accountDateClause(alias:String, setting:String):String {
        val col="$alias.created_at"
        return when(setting) {
            "month" -> "strftime('%Y-%m',datetime($col,'localtime'))=strftime('%Y-%m','now','localtime')"
            "period" -> "EXISTS(SELECT 1 FROM work_periods wp WHERE wp.is_open=1) AND datetime($col)>=datetime((SELECT opened_at FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1)) AND datetime($col)<=datetime('now')"
            "week" -> "date($col,'localtime')>=date('now','localtime','weekday 0','-6 days') AND date($col,'localtime')<date('now','localtime','weekday 0','+1 days')"
            "last_week" -> "date($col,'localtime')>=date('now','localtime','weekday 0','-13 days') AND date($col,'localtime')<date('now','localtime','weekday 0','-6 days')"
            else -> "1=1"
        }
    }
    fun accountPeriodLabel(value:String):String = when(value){"month"->"الشهر";"period"->"فترة العمل";"week"->"الأسبوع الحالي";"last_week"->"الأسبوع الماضي";else->"الكل"}
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,barcode TEXT,category TEXT,cost REAL DEFAULT 0,price REAL DEFAULT 0,qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,mobile TEXT,governorate TEXT,area TEXT,shop TEXT,balance REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,total REAL,paid REAL,due REAL,method TEXT)")
        db.execSQL("CREATE TABLE invoice_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,qty REAL,price REAL,cost REAL)")
        db.execSQL("CREATE TABLE stock_items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,barcode TEXT,qty REAL DEFAULT 0,code TEXT DEFAULT '',unit TEXT DEFAULT 'قطعة',min_qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE recipes(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'قطعة')")
        db.execSQL("CREATE TABLE stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,stock_item_id INTEGER NOT NULL,type TEXT NOT NULL,quantity REAL NOT NULL,before_qty REAL NOT NULL,after_qty REAL NOT NULL,reason TEXT,invoice_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,work_period_id INTEGER)")
        db.execSQL("CREATE TABLE stock_add_invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,note TEXT,representative TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE stock_add_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL)")
        db.execSQL("CREATE TABLE work_periods(id INTEGER PRIMARY KEY AUTOINCREMENT,opened_at TEXT DEFAULT CURRENT_TIMESTAMP,opening_cash REAL,closed_at TEXT,is_open INTEGER DEFAULT 1)")
        db.execSQL("ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0")
        db.execSQL("CREATE TABLE invoice_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("ALTER TABLE invoices ADD COLUMN customer_id INTEGER")
        db.execSQL("CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,salt TEXT NOT NULL,role TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,permissions TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE product_commissions(product_id INTEGER PRIMARY KEY,amount REAL NOT NULL DEFAULT 0)")
        db.execSQL("ALTER TABLE invoices ADD COLUMN user_id INTEGER")
        db.execSQL("ALTER TABLE invoices ADD COLUMN user_name TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE invoice_lines ADD COLUMN commission_per_unit REAL NOT NULL DEFAULT 0")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0")
            db.execSQL("CREATE TABLE IF NOT EXISTS invoice_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        }
        if (oldVersion < 3) db.execSQL("ALTER TABLE invoices ADD COLUMN customer_id INTEGER")
        if (oldVersion < 4) {
            // Legacy "حساب العمل" entries were incorrectly counted as collected money.
            // Reclassify them as customer credit: remove them from cash movements and
            // recalculate each invoice's actual collected amount and outstanding balance.
            db.execSQL("DELETE FROM invoice_payments WHERE method='حساب العمل'")
            db.execSQL("UPDATE invoices SET paid=COALESCE((SELECT SUM(amount) FROM invoice_payments p WHERE p.invoice_id=invoices.id),0)")
            db.execSQL("UPDATE invoices SET due=MAX(COALESCE(total,0)-COALESCE(paid,0),0)")
            db.execSQL("UPDATE invoices SET method=REPLACE(method,'حساب العمل','حساب العميل') WHERE method LIKE '%حساب العمل%'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE stock_items ADD COLUMN code TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE stock_items ADD COLUMN unit TEXT DEFAULT 'قطعة'")
            db.execSQL("ALTER TABLE stock_items ADD COLUMN min_qty REAL DEFAULT 0")
            db.execSQL("CREATE TABLE IF NOT EXISTS recipes(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL,unit TEXT NOT NULL DEFAULT 'قطعة')")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,stock_item_id INTEGER NOT NULL,type TEXT NOT NULL,quantity REAL NOT NULL,before_qty REAL NOT NULL,after_qty REAL NOT NULL,reason TEXT,invoice_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,work_period_id INTEGER)")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_add_invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,note TEXT)")
            db.execSQL("CREATE TABLE IF NOT EXISTS stock_add_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,stock_item_id INTEGER NOT NULL,quantity REAL NOT NULL)")
        }
        if (oldVersion < 6) db.execSQL("CREATE TABLE IF NOT EXISTS app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,salt TEXT NOT NULL,role TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        if (oldVersion < 7) { db.execSQL("ALTER TABLE app_users ADD COLUMN permissions TEXT NOT NULL DEFAULT ''"); db.execSQL("UPDATE app_users SET permissions='pos' WHERE role='مندوب' AND (permissions IS NULL OR permissions='')") }
        if (oldVersion < 8) db.execSQL("ALTER TABLE stock_add_invoices ADD COLUMN representative TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 9) {
            db.execSQL("CREATE TABLE IF NOT EXISTS product_commissions(product_id INTEGER PRIMARY KEY,amount REAL NOT NULL DEFAULT 0)")
            db.execSQL("ALTER TABLE invoices ADD COLUMN user_id INTEGER")
            db.execSQL("ALTER TABLE invoices ADD COLUMN user_name TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE invoice_lines ADD COLUMN commission_per_unit REAL NOT NULL DEFAULT 0")
        }
    }
    private fun passwordHash(password:String,salt:String):String {
        val spec=PBEKeySpec(password.toCharArray(),Base64.decode(salt,Base64.NO_WRAP),120000,256)
        return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,Base64.NO_WRAP)
    }
    fun ensureAdmin(){val count=readableDatabase.rawQuery("SELECT count(*) FROM app_users",null).use{it.moveToFirst();it.getInt(0)};if(count==0){val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}.let{Base64.encodeToString(it,Base64.NO_WRAP)};val v=ContentValues().apply{put("username","admin");put("salt",salt);put("password_hash",passwordHash("1234",salt));put("role","مدير")};writableDatabase.insert("app_users",null,v)}}
    fun saveSession(user:AppUser?){if(user==null)sessionPrefs.edit().remove("user_id").apply() else sessionPrefs.edit().putLong("user_id",user.id).apply()}
    fun restoreSession():AppUser?{val id=sessionPrefs.getLong("user_id",-1L);if(id<0)return null;return users().firstOrNull{it.id==id}.also{if(it==null)saveSession(null)}}
    fun authenticate(username:String,password:String):AppUser?{readableDatabase.rawQuery("SELECT id,username,password_hash,salt,role,permissions FROM app_users WHERE username=?",arrayOf(username.trim())).use{if(!it.moveToFirst())return null;val salt=it.getString(3);if(passwordHash(password,salt)!=it.getString(2))return null;return AppUser(it.getLong(0),it.getString(1),it.getString(4),it.getString(5).orEmpty().split(",").filter{v->v.isNotBlank()}.toSet())}}
    fun users():List<AppUser>{val a=mutableListOf<AppUser>();readableDatabase.rawQuery("SELECT id,username,role,permissions FROM app_users ORDER BY id",null).use{while(it.moveToNext())a.add(AppUser(it.getLong(0),it.getString(1),it.getString(2),it.getString(3).orEmpty().split(",").filter{v->v.isNotBlank()}.toSet()))};return a}
    fun addUser(username:String,password:String,role:String,permissions:Set<String>):Boolean{if(username.isBlank()||password.length<4)return false;val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}.let{Base64.encodeToString(it,Base64.NO_WRAP)};val v=ContentValues().apply{put("username",username.trim());put("salt",salt);put("password_hash",passwordHash(password,salt));put("role",role);put("permissions",permissions.joinToString(","))};return writableDatabase.insert("app_users",null,v)>0}
    fun updateUser(id:Long,username:String,password:String,role:String,permissions:Set<String>):Boolean{if(username.isBlank()||(password.isNotBlank()&&password.length<4))return false;val v=ContentValues().apply{put("username",username.trim());put("role",role);put("permissions",permissions.joinToString(","));if(password.isNotBlank()){val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}.let{Base64.encodeToString(it,Base64.NO_WRAP)};put("salt",salt);put("password_hash",passwordHash(password,salt))}};return writableDatabase.update("app_users",v,"id=?",arrayOf(id.toString()))>0}
    fun deleteUser(id:Long):Boolean{if(users().size<=1)return false;return writableDatabase.delete("app_users","id=?",arrayOf(id.toString()))>0}
    fun addProduct(n:String,c:String,b:String,cat:String,cost:Double,price:Double,qty:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost);put("price",price);put("qty",qty) }
        writableDatabase.insert("products",null,v)
    }
    fun products():List<Product> { val a=mutableListOf<Product>();readableDatabase.rawQuery("SELECT id,name,code,barcode,category,cost,price,qty FROM products ORDER BY name",null).use { c->while(c.moveToNext())a.add(Product(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getDouble(5),c.getDouble(6),c.getDouble(7))) };return a }
    fun updateProductDetails(id:Long,n:String,c:String,b:String,cat:String,cost:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost) }
        writableDatabase.update("products",v,"id=?",arrayOf(id.toString()))
    }
    fun updateProductPrice(id:Long,price:Double) {
        val v=ContentValues().apply { put("price",price) }
        writableDatabase.update("products",v,"id=?",arrayOf(id.toString()))
    }
    fun deleteProduct(id:Long) {
        // Historical invoice lines keep their commission snapshot; only remove the future product setting.
        writableDatabase.delete("product_commissions","product_id=?",arrayOf(id.toString()))
        writableDatabase.delete("products","id=?",arrayOf(id.toString()))
    }
    fun productCommissions():Map<Long,Double>{
        val result=linkedMapOf<Long,Double>()
        readableDatabase.rawQuery("SELECT product_id,amount FROM product_commissions ORDER BY product_id",null).use{c->while(c.moveToNext())result[c.getLong(0)]=c.getDouble(1)}
        return result
    }
    fun setProductCommission(productId:Long,amount:Double){
        require(amount>=0.0)
        val v=ContentValues().apply{put("product_id",productId);put("amount",amount)}
        writableDatabase.insertWithOnConflict("product_commissions",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun userCommissionReport(user:AppUser,filter:String):List<UserCommissionRow>{
        val where=if(filter=="الكل")"" else " AND ${reportDateClause("i",filter)}"
        val rows=mutableListOf<UserCommissionRow>()
        readableDatabase.rawQuery("SELECT i.id,ifnull(i.created_at,''),ifnull(l.name,''),ifnull(l.qty,0),ifnull(l.commission_per_unit,0),ifnull(l.qty,0)*ifnull(l.commission_per_unit,0) FROM invoices i JOIN invoice_lines l ON l.invoice_id=i.id WHERE i.user_id=?$where ORDER BY i.id DESC,l.id",arrayOf(user.id.toString())).use{c->while(c.moveToNext())rows.add(UserCommissionRow(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getDouble(5)))}
        return rows
    }
    fun customerNameExists(name:String, exceptId:Long?=null):Boolean {
        val normalized=name.trim()
        val sql=if(exceptId==null) "SELECT 1 FROM customers WHERE LOWER(TRIM(name))=LOWER(?) LIMIT 1" else "SELECT 1 FROM customers WHERE LOWER(TRIM(name))=LOWER(?) AND id<>? LIMIT 1"
        val args=if(exceptId==null) arrayOf(normalized) else arrayOf(normalized,exceptId.toString())
        readableDatabase.rawQuery(sql,args).use { return it.moveToFirst() }
    }
    fun addCustomer(n:String,m:String,g:String,a:String,s:String):Long {
        if(customerNameExists(n)) return -1L
        val v=ContentValues().apply{put("name",n.trim());put("mobile",m);put("governorate",g);put("area",a);put("shop",s)}
        return writableDatabase.insert("customers",null,v)
    }
    fun updateCustomer(id:Long,n:String,m:String,g:String,a:String,s:String) { val v=ContentValues().apply{put("name",n);put("mobile",m);put("governorate",g);put("area",a);put("shop",s)};writableDatabase.update("customers",v,"id=?",arrayOf(id.toString())) }
    fun customers(query:String=""):List<Customer> { val a=mutableListOf<Customer>();readableDatabase.rawQuery("SELECT id,name,ifnull(mobile,''),ifnull(governorate,''),ifnull(area,''),ifnull(shop,'') FROM customers WHERE name LIKE ? OR mobile LIKE ? OR governorate LIKE ? OR area LIKE ? OR shop LIKE ? ORDER BY name", arrayOf("%$query%","%$query%","%$query%","%$query%","%$query%")).use{c->while(c.moveToNext())a.add(Customer(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5)))};return a }
    fun customerInvoices(id:Long):List<String>{val a=mutableListOf<String>();val clause=accountDateClause("i",accountPeriod("customers"));readableDatabase.rawQuery("SELECT 'فاتورة #'||i.id||' | الإجمالي '||i.total||' | مدفوع '||i.paid||' | متبقي '||i.due||' | '||i.created_at FROM invoices i WHERE i.customer_id=? AND $clause ORDER BY i.id DESC",arrayOf(id.toString())).use{c->while(c.moveToNext())a.add(c.getString(0))};return a}
    fun customerTotals(id:Long):Pair<Double,Double>{val clause=accountDateClause("i",accountPeriod("customers"));readableDatabase.rawQuery("SELECT ifnull(sum(i.total),0),ifnull(sum(i.due),0) FROM invoices i WHERE i.customer_id=? AND $clause",arrayOf(id.toString())).use{it.moveToFirst();return it.getDouble(0) to it.getDouble(1)}}
    fun totalCustomerOutstanding():Double{val clause=accountDateClause("i",accountPeriod("customers"));readableDatabase.rawQuery("SELECT ifnull(sum(i.due),0) FROM invoices i WHERE i.customer_id IS NOT NULL AND $clause",null).use{it.moveToFirst();return it.getDouble(0)}}
    fun collectCustomer(id:Long,amount:Double,method:String):Boolean {
        if(amount<=0.0 || method !in listOf("نقدي","إنستا باي","حساب بنكي")) return false
        val d=writableDatabase; d.beginTransaction()
        try {
            var left=amount
            val clause=accountDateClause("i",accountPeriod("customers"))
            d.rawQuery("SELECT i.id,i.due,i.paid FROM invoices i WHERE i.customer_id=? AND i.due>0 AND $clause ORDER BY i.id ASC",arrayOf(id.toString())).use { c ->
                while(c.moveToNext() && left>0.009) {
                    val invoiceId=c.getLong(0); val due=c.getDouble(1); val oldPaid=c.getDouble(2)
                    val part=minOf(left,due)
                    val pay=ContentValues().apply{put("invoice_id",invoiceId);put("method",method);put("amount",part)}
                    d.insert("invoice_payments",null,pay)
                    val update=ContentValues().apply{put("paid",oldPaid+part);put("due",(due-part).coerceAtLeast(0.0))}
                    d.update("invoices",update,"id=?",arrayOf(invoiceId.toString()))
                    left-=part
                }
            }
            if(left>0.009) return false
            d.setTransactionSuccessful(); return true
        } finally { d.endTransaction() }
    }
    fun stockItems():List<StockItem> { val a=mutableListOf<StockItem>();readableDatabase.rawQuery("SELECT id,name,ifnull(barcode,''),ifnull(code,''),ifnull(unit,'قطعة'),ifnull(qty,0),ifnull(min_qty,0) FROM stock_items ORDER BY name",null).use{c->while(c.moveToNext())a.add(StockItem(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getDouble(5),c.getDouble(6)))};return a }
    fun stockDashboard():List<StockDashboardRow>{
        val rows=mutableListOf<StockDashboardRow>()
        readableDatabase.rawQuery("""SELECT s.id,s.name,ifnull(s.unit,'قطعة'),ifnull(s.qty,0),
            ifnull((SELECT sum(quantity) FROM stock_movements m WHERE m.stock_item_id=s.id AND m.type='إضافة مخزون'),0),
            max(0,-ifnull((SELECT sum(quantity) FROM stock_movements m WHERE m.stock_item_id=s.id AND m.type IN ('خصم بيع','إرجاع إلغاء فاتورة','عكس تعديل فاتورة')),0))
            FROM stock_items s ORDER BY s.name""",null).use{c->while(c.moveToNext())rows.add(StockDashboardRow(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(5),c.getDouble(4),c.getDouble(3)))}
        return rows
    }
    fun addStock(n:String,b:String,code:String,unit:String,q:Double,minQty:Double=0.0) { val v=ContentValues().apply{put("name",n);put("barcode",b);put("code",code);put("unit",unit);put("qty",q);put("min_qty",minQty)};writableDatabase.insert("stock_items",null,v) }
    fun updateStockItem(item:StockItem,n:String,b:String,code:String,unit:String,minQty:Double){val v=ContentValues().apply{put("name",n);put("barcode",b);put("code",code);put("unit",unit);put("min_qty",minQty)};writableDatabase.update("stock_items",v,"id=?",arrayOf(item.id.toString()))}
    fun deleteStockItem(id:Long){writableDatabase.delete("stock_items","id=?",arrayOf(id.toString()))}
    fun hasOpenPeriod():Boolean=readableDatabase.rawQuery("SELECT 1 FROM work_periods WHERE is_open=1 LIMIT 1",null).use{it.moveToFirst()}
    fun canEditStock():Boolean=readableDatabase.rawQuery("SELECT is_open,closed_at FROM work_periods ORDER BY id DESC LIMIT 1",null).use{it.moveToFirst() && it.getInt(0)==0 && !it.isNull(1)}
    fun stockLedger():List<StockMovement>{val a=mutableListOf<StockMovement>();readableDatabase.rawQuery("SELECT m.id,m.stock_item_id,s.name,m.type,m.quantity,m.before_qty,m.after_qty,m.reason,m.created_at FROM stock_movements m JOIN stock_items s ON s.id=m.stock_item_id ORDER BY m.id DESC",null).use{c->while(c.moveToNext())a.add(StockMovement(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5),c.getDouble(6),c.getString(7)?:"",c.getString(8)?:""))};return a}
    fun adjustStock(id:Long,newQty:Double,reason:String):Boolean{if(!canEditStock()||newQty<0)return false;val d=writableDatabase;d.beginTransaction();try{val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else return false};val delta=newQty-before;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(newQty,id));val period=d.rawQuery("SELECT id FROM work_periods ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())it.getLong(0) else null};val v=ContentValues().apply{put("stock_item_id",id);put("type","تسوية رصيد");put("quantity",delta);put("before_qty",before);put("after_qty",newQty);put("reason",reason);if(period!=null)put("work_period_id",period)};d.insert("stock_movements",null,v);d.setTransactionSuccessful();return true}finally{d.endTransaction()}}
    fun editStockMovement(m:StockMovement,newAfter:Double,reason:String):Boolean{if(!canEditStock()||newAfter<0)return false;val d=writableDatabase;d.beginTransaction();try{val current=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(m.stockItemId.toString())).use{it.moveToFirst();it.getDouble(0)};val delta=newAfter-m.after;val final=current+delta;if(final<0)return false;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(final,m.stockItemId));val v=ContentValues().apply{put("quantity",newAfter-m.before);put("after_qty",newAfter);put("reason",reason)};d.update("stock_movements",v,"id=?",arrayOf(m.id.toString()));d.execSQL("UPDATE stock_movements SET before_qty=before_qty+?,after_qty=after_qty+? WHERE stock_item_id=? AND id>?",arrayOf(delta,delta,m.stockItemId,m.id));d.setTransactionSuccessful();return true}finally{d.endTransaction()}}

    fun recipes():List<RecipeRow>{val a=mutableListOf<RecipeRow>();readableDatabase.rawQuery("SELECT r.id,r.product_id,p.name,r.stock_item_id,s.name,r.quantity,r.unit FROM recipes r JOIN products p ON p.id=r.product_id JOIN stock_items s ON s.id=r.stock_item_id ORDER BY p.name",null).use{c->while(c.moveToNext())a.add(RecipeRow(c.getLong(0),c.getLong(1),c.getString(2),c.getLong(3),c.getString(4),c.getDouble(5),c.getString(6)))};return a}
    fun addRecipe(productId:Long,stockId:Long,qty:Double,unit:String){val v=ContentValues().apply{put("product_id",productId);put("stock_item_id",stockId);put("quantity",qty);put("unit",unit)};writableDatabase.insert("recipes",null,v)}
    fun updateRecipe(id:Long,productId:Long,stockId:Long,qty:Double,unit:String){val v=ContentValues().apply{put("product_id",productId);put("stock_item_id",stockId);put("quantity",qty);put("unit",unit)};writableDatabase.update("recipes",v,"id=?",arrayOf(id.toString()))}
    fun deleteRecipe(id:Long){writableDatabase.delete("recipes","id=?",arrayOf(id.toString()))}
    fun addStockPurchase(rows:List<Pair<Long,Double>>,note:String=""):Boolean{if(rows.isEmpty()||rows.any{it.second<=0})return false;val d=writableDatabase;d.beginTransaction();try{val h=ContentValues().apply{put("note",note)};val invoice=d.insert("stock_add_invoices",null,h);rows.forEach{(id,q)->val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val after=before+q;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,id));val l=ContentValues().apply{put("invoice_id",invoice);put("stock_item_id",id);put("quantity",q)};d.insert("stock_add_lines",null,l);val m=ContentValues().apply{put("stock_item_id",id);put("type","إضافة مخزون");put("quantity",q);put("before_qty",before);put("after_qty",after);put("reason","فاتورة إضافة مخزون #$invoice");put("invoice_id",invoice)};d.insert("stock_movements",null,m)}
            // Reconcile sales made before this stock item/recipe was registered.
            // Existing stock movements are subtracted from the historical requirement,
            // so the same sale can never be deducted twice.
            rows.map{it.first}.distinct().forEach{stockId->
                val expected=d.rawQuery("SELECT ifnull(sum(il.qty*r.quantity),0) FROM recipes r JOIN invoice_lines il ON il.product_id=r.product_id WHERE r.stock_item_id=?",arrayOf(stockId.toString())).use{it.moveToFirst();it.getDouble(0)}
                val alreadyApplied=d.rawQuery("SELECT -ifnull(sum(quantity),0) FROM stock_movements WHERE stock_item_id=? AND type IN ('خصم بيع','إرجاع إلغاء فاتورة','عكس تعديل فاتورة')",arrayOf(stockId.toString())).use{it.moveToFirst();it.getDouble(0)}
                val deferred=(expected-alreadyApplied).coerceAtLeast(0.0)
                if(deferred>0.000001){val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val after=before-deferred;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,stockId));val adj=ContentValues().apply{put("stock_item_id",stockId);put("type","خصم بيع");put("quantity",-deferred);put("before_qty",before);put("after_qty",after);put("reason","خصم المبيعات السابقة قبل تسجيل الوارد")};d.insert("stock_movements",null,adj)}
            }
            d.setTransactionSuccessful();return true}finally{d.endTransaction()}}
    fun stockPurchaseInvoices():List<String>{val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT 'فاتورة إضافة #'||h.id||' | '||h.created_at||' | أصناف: '||(SELECT count(*) FROM stock_add_lines l WHERE l.invoice_id=h.id) FROM stock_add_invoices h ORDER BY h.id DESC",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a}
    fun stockDocuments(filter:String="الكل"):List<StockDocumentRow>{
        val a=mutableListOf<StockDocumentRow>()
        val where=if(filter=="الكل")"" else "WHERE ${reportDateClause("h",filter)}"
        readableDatabase.rawQuery("SELECT h.id,h.created_at,ifnull(h.note,''),(SELECT count(*) FROM stock_add_lines l WHERE l.invoice_id=h.id) FROM stock_add_invoices h $where ORDER BY h.id DESC",null).use{c->while(c.moveToNext())a.add(StockDocumentRow(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3)))}
        return a
    }
    fun stockDocumentLines(invoiceId:Long):List<StockDocumentLine>{
        val a=mutableListOf<StockDocumentLine>()
        readableDatabase.rawQuery("SELECT l.stock_item_id,s.name,ifnull(s.unit,'قطعة'),l.quantity FROM stock_add_lines l JOIN stock_items s ON s.id=l.stock_item_id WHERE l.invoice_id=? ORDER BY s.name",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())a.add(StockDocumentLine(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3)))}
        return a
    }
    fun updateStockDocumentLine(invoiceId:Long,stockId:Long,newQty:Double):Boolean {
        if(newQty<=0)return false
        val d=writableDatabase;d.beginTransaction()
        try{
            val old=d.rawQuery("SELECT quantity FROM stock_add_lines WHERE invoice_id=? AND stock_item_id=?",arrayOf(invoiceId.toString(),stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else return false}
            val delta=newQty-old
            val current=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else return false}
            if(current+delta<0)return false
            d.execSQL("UPDATE stock_items SET qty=qty+? WHERE id=?",arrayOf(delta,stockId))
            d.execSQL("UPDATE stock_add_lines SET quantity=? WHERE invoice_id=? AND stock_item_id=?",arrayOf(newQty,invoiceId,stockId))
            d.execSQL("UPDATE stock_movements SET quantity=quantity+?,after_qty=after_qty+? WHERE invoice_id=? AND stock_item_id=? AND type='إضافة مخزون'",arrayOf(delta,delta,invoiceId,stockId))
            d.setTransactionSuccessful();return true
        }finally{d.endTransaction()}
    }
    fun deleteStockDocument(invoiceId:Long):Boolean {
        val d=writableDatabase;d.beginTransaction()
        try{
            val lines=stockDocumentLines(invoiceId)
            for(line in lines){
                val current=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(line.stockItemId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0}
                if(current-line.quantity < -0.000001)return false
            }
            for(line in lines){
                d.execSQL("UPDATE stock_items SET qty=qty-? WHERE id=?",arrayOf(line.quantity,line.stockItemId))
                d.delete("stock_movements","invoice_id=? AND stock_item_id=? AND type='إضافة مخزون'",arrayOf(invoiceId.toString(),line.stockItemId.toString()))
            }
            d.delete("stock_add_lines","invoice_id=?",arrayOf(invoiceId.toString()))
            d.delete("stock_add_invoices","id=?",arrayOf(invoiceId.toString()))
            d.setTransactionSuccessful();return true
        }finally{d.endTransaction()}
    }


    fun saveSale(lines:List<Pair<Product,Double>>,paid:Double,method:String,customerId:Long?=null,user:AppUser?=null) {
        saveSale(lines, mapOf(method to paid.coerceAtLeast(0.0)), 0.0, customerId, user)
    }
    fun saveSale(lines:List<Pair<Product,Double>>,payments:Map<String,Double>,discount:Double,customerId:Long?=null,user:AppUser?=null) {
        val gross=lines.sumOf{it.first.price*it.second}
        val discountValue=(gross*discount.coerceIn(0.0,100.0)/100.0).coerceAtMost(gross)
        val total=(gross-discountValue).coerceAtLeast(0.0)
        // Only real collection methods count as paid. Customer credit is an amount due,
        // never a cash movement and never an invoice_payment row.
        val collected=payments.filterKeys{it!="حساب العميل" && it!="حساب العمل"}.values.filter{it>0.0}.sum().coerceAtMost(total)
        val due=(total-collected).coerceAtLeast(0.0)
        require(due<=0.009 || customerId!=null) { "يجب اختيار العميل لتسجيل المبلغ على حسابه" }
        val d=writableDatabase;d.beginTransaction()
        try {
            val collectedMethods=payments.filterKeys{it!="حساب العميل" && it!="حساب العمل"}.filterValues{it>0.0}.keys
            val methods=(collectedMethods.toList()+if(due>0.009) listOf("حساب العميل") else emptyList()).joinToString(" + ").ifBlank{"غير محدد"}
            val methodLabel=if(methods.contains(" + "))"متعدد" else methods
            val finalMethod=if(methods.contains("حساب العميل") && collectedMethods.isNotEmpty()) "متعدد + حساب العميل" else methodLabel
            val v=ContentValues().apply{put("total",total);put("paid",collected);put("due",due);put("method",finalMethod);put("discount",discountValue);if(customerId!=null)put("customer_id",customerId);if(user!=null){put("user_id",user.id);put("user_name",user.username)}}
            val id=d.insert("invoices",null,v)
            lines.forEach{(p,q)->val commission=d.rawQuery("SELECT amount FROM product_commissions WHERE product_id=?",arrayOf(p.id.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val x=ContentValues().apply{put("invoice_id",id);put("product_id",p.id);put("name",p.name);put("qty",q);put("price",p.price);put("cost",p.cost);put("commission_per_unit",commission)};d.insert("invoice_lines",null,x);d.execSQL("UPDATE products SET qty=qty-? WHERE id=?",arrayOf(q,p.id));consumeRecipe(d,p.id,q,id)}
            payments.filterKeys{it!="حساب العميل" && it!="حساب العمل"}.filterValues{it>0.0}.forEach{(method,amount)->val pay=ContentValues().apply{put("invoice_id",id);put("method",method);put("amount",amount)};d.insert("invoice_payments",null,pay)}
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun paymentAccountBalances():Map<String,Double>{
        val result=linkedMapOf("نقدية" to 0.0,"إنستا باي" to 0.0,"حساب بنكي" to 0.0)
        val clause=accountDateClause("p",accountPeriod("payments"))
        readableDatabase.rawQuery("SELECT CASE WHEN p.method='نقدي' THEN 'نقدية' ELSE p.method END,ifnull(sum(p.amount),0) FROM invoice_payments p WHERE p.method IN ('نقدي','إنستا باي','حساب بنكي') AND $clause GROUP BY p.method",null).use{c->while(c.moveToNext())result[c.getString(0)]=c.getDouble(1)}
        return result
    }
    fun paymentMovements(method:String):List<PaymentMovement>{
        val a=mutableListOf<PaymentMovement>()
        val storedMethod=if(method=="نقدية")"نقدي" else method
        val clause=accountDateClause("p",accountPeriod("payments"))
        readableDatabase.rawQuery("SELECT p.id,p.invoice_id,p.amount,p.created_at FROM invoice_payments p WHERE p.method=? AND $clause ORDER BY p.id DESC",arrayOf(storedMethod)).use{c->while(c.moveToNext())a.add(PaymentMovement(c.getLong(0),c.getLong(1),c.getDouble(2),c.getString(3)?:""))}
        return a
    }
    fun filteredPaymentMovements(method:String,filter:String):List<PaymentMovement>{
        val storedMethod=if(method=="نقدية")"نقدي" else method
        val clause=when(filter){
            "فترة العمل الحالية" -> accountDateClause("p","period")
            "فترة العمل السابقة" -> "datetime(p.created_at)>=datetime((SELECT wp.opened_at FROM work_periods wp WHERE wp.id < COALESCE((SELECT id FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1),(SELECT ifnull(max(id),0)+1 FROM work_periods)) ORDER BY wp.id DESC LIMIT 1)) AND datetime(p.created_at)<datetime(COALESCE((SELECT wp.closed_at FROM work_periods wp WHERE wp.id < COALESCE((SELECT id FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1),(SELECT ifnull(max(id),0)+1 FROM work_periods)) ORDER BY wp.id DESC LIMIT 1),(SELECT opened_at FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1),datetime('now')))"
            "الشهر" -> accountDateClause("p","month")
            "الأسبوع الماضي" -> accountDateClause("p","last_week")
            else -> "1=1"
        }
        val a=mutableListOf<PaymentMovement>()
        readableDatabase.rawQuery("SELECT p.id,p.invoice_id,p.amount,p.created_at FROM invoice_payments p WHERE p.method=? AND $clause ORDER BY p.id ASC",arrayOf(storedMethod)).use{c->while(c.moveToNext())a.add(PaymentMovement(c.getLong(0),c.getLong(1),c.getDouble(2),c.getString(3)?:""))}
        return a
    }
    fun salesAccountInvoices(query:String=""):List<InvoiceSummary>{
        val a=mutableListOf<InvoiceSummary>();val q="%$query%";val clause=accountDateClause("i",accountPeriod("sales"))
        readableDatabase.rawQuery("SELECT i.id,ifnull(i.created_at,''),ifnull(i.total,0),ifnull(i.paid,0),ifnull(i.due,0),ifnull(i.method,''),i.customer_id,ifnull(c.name,'عميل نقدي'),ifnull(c.mobile,''),ifnull(c.governorate,''),ifnull(c.shop,''),ifnull(i.discount,0) FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE $clause AND (CAST(i.id AS TEXT) LIKE ? OR ifnull(c.name,'') LIKE ? OR ifnull(c.mobile,'') LIKE ?) ORDER BY i.id DESC",arrayOf(q,q,q)).use{c->while(c.moveToNext())a.add(InvoiceSummary(c.getLong(0),c.getString(1),c.getDouble(2),c.getDouble(3),c.getDouble(4),c.getString(5),if(c.isNull(6))null else c.getLong(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),c.getDouble(11)))}
        return a
    }
    fun invoiceSummaries(query:String=""):List<InvoiceSummary>{
        val a=mutableListOf<InvoiceSummary>()
        val q="%$query%"
        readableDatabase.rawQuery("SELECT i.id,ifnull(i.created_at,''),ifnull(i.total,0),ifnull(i.paid,0),ifnull(i.due,0),ifnull(i.method,''),i.customer_id,ifnull(c.name,'عميل نقدي'),ifnull(c.mobile,''),ifnull(c.governorate,''),ifnull(c.shop,''),ifnull(i.discount,0) FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE CAST(i.id AS TEXT) LIKE ? OR ifnull(c.name,'') LIKE ? OR ifnull(c.mobile,'') LIKE ? ORDER BY i.id DESC",arrayOf(q,q,q)).use{c->while(c.moveToNext())a.add(InvoiceSummary(c.getLong(0),c.getString(1),c.getDouble(2),c.getDouble(3),c.getDouble(4),c.getString(5),if(c.isNull(6))null else c.getLong(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),c.getDouble(11)))}
        return a
    }
    fun invoiceLines(invoiceId:Long):List<InvoiceLine>{
        val a=mutableListOf<InvoiceLine>()
        readableDatabase.rawQuery("SELECT id,ifnull(product_id,0),ifnull(name,''),ifnull(qty,0),ifnull(price,0),ifnull(cost,0) FROM invoice_lines WHERE invoice_id=? ORDER BY id",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())a.add(InvoiceLine(c.getLong(0),c.getLong(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getDouble(5)))}
        return a
    }
    fun invoicePayments(invoiceId:Long):Map<String,Double>{
        val result=linkedMapOf("نقدي" to 0.0,"إنستا باي" to 0.0,"حساب بنكي" to 0.0,"حساب العميل" to 0.0)
        readableDatabase.rawQuery("SELECT method,ifnull(sum(amount),0) FROM invoice_payments WHERE invoice_id=? GROUP BY method",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())result[c.getString(0)]=c.getDouble(1)}
        readableDatabase.rawQuery("SELECT ifnull(due,0) FROM invoices WHERE id=?",arrayOf(invoiceId.toString())).use{c->if(c.moveToFirst())result["حساب العميل"]=c.getDouble(0)}
        return result
    }
    fun deleteInvoice(invoiceId:Long):Boolean{
        val d=writableDatabase;d.beginTransaction()
        try{
            val old=mutableListOf<Pair<Long,Double>>()
            d.rawQuery("SELECT ifnull(product_id,0),ifnull(qty,0) FROM invoice_lines WHERE invoice_id=?",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())old.add(c.getLong(0) to c.getDouble(1))}
            if(old.isEmpty() && !invoiceExists(d,invoiceId)) return false
            old.forEach{(productId,qty)->if(productId>0)d.execSQL("UPDATE products SET qty=qty+? WHERE id=?",arrayOf(qty,productId))}
            reverseRecipeMovements(d,invoiceId,false)
            d.delete("invoice_payments","invoice_id=?",arrayOf(invoiceId.toString()))
            d.delete("invoice_lines","invoice_id=?",arrayOf(invoiceId.toString()))
            val removed=d.delete("invoices","id=?",arrayOf(invoiceId.toString()))
            if(removed==0)return false
            d.setTransactionSuccessful();return true
        }finally{d.endTransaction()}
    }
    private fun consumeRecipe(d:SQLiteDatabase,productId:Long,soldQty:Double,invoiceId:Long){d.rawQuery("SELECT stock_item_id,quantity,unit FROM recipes WHERE product_id=?",arrayOf(productId.toString())).use{c->while(c.moveToNext()){val stockId=c.getLong(0);val used=c.getDouble(1)*soldQty;val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0};val after=before-used;d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,stockId));val m=ContentValues().apply{put("stock_item_id",stockId);put("type","خصم بيع");put("quantity",-used);put("before_qty",before);put("after_qty",after);put("reason","بيع منتج #$productId");put("invoice_id",invoiceId)};d.insert("stock_movements",null,m)}}}
    private fun reverseRecipeMovements(d:SQLiteDatabase,invoiceId:Long,clearOriginal:Boolean){
        val totals=mutableListOf<Pair<Long,Double>>()
        d.rawQuery("SELECT stock_item_id,ifnull(sum(quantity),0) FROM stock_movements WHERE invoice_id=? AND type IN ('خصم بيع','إرجاع إلغاء فاتورة','عكس تعديل فاتورة') GROUP BY stock_item_id",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())totals.add(c.getLong(0) to c.getDouble(1))}
        totals.forEach{(stockId,netDelta)->
            val reversal=-netDelta
            if(kotlin.math.abs(reversal)>0.000001){
                val before=d.rawQuery("SELECT qty FROM stock_items WHERE id=?",arrayOf(stockId.toString())).use{if(it.moveToFirst())it.getDouble(0) else 0.0}
                val after=before+reversal
                d.execSQL("UPDATE stock_items SET qty=? WHERE id=?",arrayOf(after,stockId))
                val movementType=if(clearOriginal)"عكس تعديل فاتورة" else "إلغاء فاتورة"
                val m=ContentValues().apply{put("stock_item_id",stockId);put("type",movementType);put("quantity",reversal);put("before_qty",before);put("after_qty",after);put("reason",if(clearOriginal)"إعادة احتساب ريسبي الفاتورة #$invoiceId" else "إلغاء فاتورة #$invoiceId");put("invoice_id",invoiceId)}
                d.insert("stock_movements",null,m)
            }
        }
        if(clearOriginal)d.delete("stock_movements","invoice_id=? AND type IN ('خصم بيع','إرجاع إلغاء فاتورة','عكس تعديل فاتورة')",arrayOf(invoiceId.toString()))
    }

    private fun invoiceExists(d:SQLiteDatabase,id:Long):Boolean{d.rawQuery("SELECT 1 FROM invoices WHERE id=?",arrayOf(id.toString())).use{return it.moveToFirst()}}
    fun updateInvoice(invoiceId:Long,updatedLines:List<InvoiceLine>):Boolean{
        if(updatedLines.any{it.qty<0||it.price<0})return false
        val d=writableDatabase;d.beginTransaction()
        try{
            val old=mutableListOf<InvoiceLine>()
            d.rawQuery("SELECT id,ifnull(product_id,0),ifnull(name,''),ifnull(qty,0),ifnull(price,0),ifnull(cost,0) FROM invoice_lines WHERE invoice_id=?",arrayOf(invoiceId.toString())).use{c->while(c.moveToNext())old.add(InvoiceLine(c.getLong(0),c.getLong(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getDouble(5)))}
            if(!invoiceExists(d,invoiceId))return false
            old.forEach{if(it.productId>0)d.execSQL("UPDATE products SET qty=qty+? WHERE id=?",arrayOf(it.qty,it.productId))}
            reverseRecipeMovements(d,invoiceId,true)
            val keep=updatedLines.filter{it.qty>0.0}
            val keepIds=keep.map{it.id}.toSet()
            old.filter{it.id !in keepIds}.forEach{d.delete("invoice_lines","id=? AND invoice_id=?",arrayOf(it.id.toString(),invoiceId.toString()))}
            keep.forEach{line->
                if(line.productId>0){d.execSQL("UPDATE products SET qty=qty-? WHERE id=?",arrayOf(line.qty,line.productId));consumeRecipe(d,line.productId,line.qty,invoiceId)}
                val v=ContentValues().apply{put("qty",line.qty);put("price",line.price);put("name",line.name)}
                d.update("invoice_lines",v,"id=? AND invoice_id=?",arrayOf(line.id.toString(),invoiceId.toString()))
            }
            val discount=d.rawQuery("SELECT ifnull(discount,0) FROM invoices WHERE id=?",arrayOf(invoiceId.toString())).use{c->c.moveToFirst();c.getDouble(0)}
            val total=(keep.sumOf{it.qty*it.price}-discount).coerceAtLeast(0.0)
            val paid=d.rawQuery("SELECT ifnull(sum(amount),0) FROM invoice_payments WHERE invoice_id=?",arrayOf(invoiceId.toString())).use{c->c.moveToFirst();c.getDouble(0)}
            if(paid>total+0.009)return false
            val due=(total-paid).coerceAtLeast(0.0)
            val v=ContentValues().apply{put("total",total);put("paid",paid);put("due",due)}
            d.update("invoices",v,"id=?",arrayOf(invoiceId.toString()))
            d.setTransactionSuccessful();return true
        }finally{d.endTransaction()}
    }
    private fun dashboardPeriodClause(alias:String,filter:String):String = when(filter){
        "فترة العمل الحالية" -> "EXISTS(SELECT 1 FROM work_periods wp WHERE wp.is_open=1 AND datetime($alias.created_at)>=datetime(wp.opened_at) AND datetime($alias.created_at)<=datetime('now'))"
        // Older app versions closed a period by clearing is_open without setting closed_at.
        // Infer its end from the next period's opening time so historical invoices remain visible.
        "فترة العمل السابقة" -> "datetime($alias.created_at)>=datetime((SELECT wp.opened_at FROM work_periods wp WHERE wp.id < COALESCE((SELECT id FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1),(SELECT ifnull(max(id),0)+1 FROM work_periods)) ORDER BY wp.id DESC LIMIT 1)) AND datetime($alias.created_at)<datetime(COALESCE((SELECT wp.closed_at FROM work_periods wp WHERE wp.id < COALESCE((SELECT id FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1),(SELECT ifnull(max(id),0)+1 FROM work_periods)) ORDER BY wp.id DESC LIMIT 1),(SELECT opened_at FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1),datetime('now')))"
        "اليوم" -> "date($alias.created_at,'localtime')=date('now','localtime')"
        "الشهر" -> "strftime('%Y-%m',datetime($alias.created_at,'localtime'))=strftime('%Y-%m','now','localtime')"
        "الأسبوع الحالي" -> "date($alias.created_at,'localtime')>=date('now','localtime','weekday 0','-6 days') AND date($alias.created_at,'localtime')<date('now','localtime','weekday 0','+1 days')"
        "الأسبوع الماضي" -> "date($alias.created_at,'localtime')>=date('now','localtime','weekday 0','-13 days') AND date($alias.created_at,'localtime')<date('now','localtime','weekday 0','-6 days')"
        else -> "1=1"
    }
    fun dashboardTotals(filter:String):Triple<Double,Double,Int>{val where=dashboardPeriodClause("i",filter);readableDatabase.rawQuery("SELECT ifnull(sum(i.total),0),ifnull(sum(i.due),0),count(*) FROM invoices i WHERE $where",null).use{it.moveToFirst();return Triple(it.getDouble(0),it.getDouble(1),it.getInt(2))}}
    fun accountInvoiceDetails(accountType:String,filter:String,query:String=""):List<InvoiceSummary>{
        val where=when(filter){"فترة العمل الحالية","فترة العمل السابقة","اليوم"->dashboardPeriodClause("i",filter);"الشهر"->accountDateClause("i","month");"الأسبوع الحالي"->accountDateClause("i","week");"الأسبوع الماضي"->accountDateClause("i","last_week");else->"1=1"}
        val dueOnly=if(accountType=="المستحقات")" AND i.due>0" else ""
        val q="%$query%";val a=mutableListOf<InvoiceSummary>()
        readableDatabase.rawQuery("SELECT i.id,ifnull(i.created_at,''),ifnull(i.total,0),ifnull(i.paid,0),ifnull(i.due,0),ifnull(i.method,''),i.customer_id,ifnull(c.name,'عميل نقدي'),ifnull(c.mobile,''),ifnull(c.governorate,''),ifnull(c.shop,''),ifnull(i.discount,0) FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE $where$dueOnly AND (CAST(i.id AS TEXT) LIKE ? OR ifnull(c.name,'') LIKE ?) ORDER BY i.id DESC",arrayOf(q,q)).use{c->while(c.moveToNext())a.add(InvoiceSummary(c.getLong(0),c.getString(1),c.getDouble(2),c.getDouble(3),c.getDouble(4),c.getString(5),if(c.isNull(6))null else c.getLong(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10),c.getDouble(11)))}
        return a
    }
    fun totals():Triple<Double,Double,Int> = dashboardTotals(if(hasOpenPeriod())"فترة العمل الحالية" else "اليوم")
    private fun reportDateClause(alias:String,filter:String):String=when(filter){
        "اليوم"->"date($alias.created_at,'localtime')=date('now','localtime')"
        "أمس"->"date($alias.created_at,'localtime')=date('now','localtime','-1 day')"
        "الأسبوع"->"date($alias.created_at,'localtime')>=date('now','localtime','weekday 0','-6 days') AND date($alias.created_at,'localtime')<date('now','localtime','weekday 0','+1 day')"
        "الشهر"->"strftime('%Y-%m',datetime($alias.created_at,'localtime'))=strftime('%Y-%m','now','localtime')"
        "الشهر الماضي"->"strftime('%Y-%m',datetime($alias.created_at,'localtime'))=strftime('%Y-%m','now','localtime','-1 month')"
        else->"1=1"
    }
    private fun reportPeriodClause(alias:String="i"):String = "datetime($alias.created_at)>=datetime((SELECT opened_at FROM work_periods ORDER BY id DESC LIMIT 1)) AND ((SELECT closed_at FROM work_periods ORDER BY id DESC LIMIT 1) IS NULL OR datetime($alias.created_at)<=datetime((SELECT closed_at FROM work_periods ORDER BY id DESC LIMIT 1)))"
    fun periodReport(filter:String="الكل"):PeriodReport {
        val d=readableDatabase
        val where=if(filter=="الكل") "" else "WHERE ${reportDateClause("i",filter)}"
        val sales=d.rawQuery("SELECT ifnull(sum(total),0),ifnull(sum(due),0),count(*) FROM invoices i $where",null).use{it.moveToFirst();Triple(it.getDouble(0),it.getDouble(1),it.getInt(2))}
        val payments=linkedMapOf("نقدي" to 0.0,"إنستا باي" to 0.0,"حساب بنكي" to 0.0)
        val paymentWhere=if(filter=="الكل") "" else "WHERE ${reportDateClause("invoice_payments",filter).replace("invoice_payments.created_at","created_at")}"
        d.rawQuery("SELECT method,ifnull(sum(amount),0) FROM invoice_payments $paymentWhere GROUP BY method",null).use{c->while(c.moveToNext())if(payments.containsKey(c.getString(0)))payments[c.getString(0)]=c.getDouble(1)}
        val discount=d.rawQuery("SELECT ifnull(sum(i.discount),0) FROM invoices i $where",null).use{it.moveToFirst();it.getDouble(0)}
        val items=mutableListOf<SalesProductRow>()
        d.rawQuery("SELECT l.name,ifnull(sum(l.qty),0),ifnull(sum(l.qty*l.price),0) FROM invoice_lines l JOIN invoices i ON i.id=l.invoice_id $where GROUP BY l.name ORDER BY sum(l.qty*l.price) DESC",null).use{c->while(c.moveToNext())items.add(SalesProductRow(c.getString(0),c.getDouble(1),c.getDouble(2)))}
        return PeriodReport(sales.first,sales.second,sales.third,payments,items,discount)
    }
    fun allProductSales(filter:String="الكل"):List<SalesProductRow>{val a=mutableListOf<SalesProductRow>();val where=if(filter=="الكل")"" else "WHERE ${reportDateClause("i",filter)}";readableDatabase.rawQuery("SELECT l.name,ifnull(sum(l.qty),0),ifnull(sum(l.qty*l.price),0) FROM invoice_lines l JOIN invoices i ON i.id=l.invoice_id $where GROUP BY l.name ORDER BY sum(l.qty*l.price) DESC",null).use{c->while(c.moveToNext())a.add(SalesProductRow(c.getString(0),c.getDouble(1),c.getDouble(2)))};return a}
    private fun reportStartExpr(filter:String):String=when(filter){
        "اليوم"->"datetime('now','localtime','start of day')"
        "أمس"->"datetime('now','localtime','start of day','-1 day')"
        "الأسبوع"->"datetime('now','localtime','weekday 0','-6 days','start of day')"
        "الشهر"->"datetime('now','localtime','start of month')"
        "الشهر الماضي"->"datetime('now','localtime','start of month','-1 month')"
        else->"datetime('0001-01-01')"
    }
    private fun reportEndExpr(filter:String):String=when(filter){
        "اليوم"->"datetime('now','localtime','start of day','+1 day')"
        "أمس"->"datetime('now','localtime','start of day')"
        "الأسبوع"->"datetime('now','localtime','weekday 0','+1 day','start of day')"
        "الشهر"->"datetime('now','localtime','start of month','+1 month')"
        "الشهر الماضي"->"datetime('now','localtime','start of month')"
        else->"datetime('9999-12-31')"
    }
    fun inventoryReport(filter:String="الكل"):List<InventoryRow>{
        val a=mutableListOf<InventoryRow>();val d=readableDatabase
        d.rawQuery("SELECT id,name,qty,unit,min_qty FROM stock_items ORDER BY name",null).use{c->while(c.moveToNext()){
            val id=c.getLong(0);val current=c.getDouble(2)
            val incoming:Double;val sold:Double;val opening:Double;val closing:Double
            if(filter=="الكل"){
                incoming=d.rawQuery("SELECT ifnull(sum(quantity),0) FROM stock_movements WHERE stock_item_id=? AND quantity>0",arrayOf(id.toString())).use{it.moveToFirst();it.getDouble(0)}
                sold=d.rawQuery("SELECT ifnull(sum(-quantity),0) FROM stock_movements WHERE stock_item_id=? AND quantity<0",arrayOf(id.toString())).use{it.moveToFirst();it.getDouble(0)}
                closing=current;opening=current-incoming+sold
            }else{
                val where=reportDateClause("sm",filter)
                incoming=d.rawQuery("SELECT ifnull(sum(sm.quantity),0) FROM stock_movements sm WHERE sm.stock_item_id=? AND sm.quantity>0 AND $where",arrayOf(id.toString())).use{it.moveToFirst();it.getDouble(0)}
                sold=d.rawQuery("SELECT ifnull(sum(-sm.quantity),0) FROM stock_movements sm WHERE sm.stock_item_id=? AND sm.quantity<0 AND $where",arrayOf(id.toString())).use{it.moveToFirst();it.getDouble(0)}
                val start=reportStartExpr(filter);val end=reportEndExpr(filter)
                val beforeStart=d.rawQuery("SELECT after_qty FROM stock_movements WHERE stock_item_id=? AND datetime(created_at,'localtime')<${start} ORDER BY datetime(created_at) DESC,id DESC LIMIT 1",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else null}
                val firstAtOrAfterStart=d.rawQuery("SELECT before_qty FROM stock_movements WHERE stock_item_id=? AND datetime(created_at,'localtime')>=${start} ORDER BY datetime(created_at),id LIMIT 1",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else null}
                opening=beforeStart ?: firstAtOrAfterStart ?: current
                val lastBeforeEnd=d.rawQuery("SELECT after_qty FROM stock_movements WHERE stock_item_id=? AND datetime(created_at,'localtime')<${end} ORDER BY datetime(created_at) DESC,id DESC LIMIT 1",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else null}
                val firstAfterEnd=d.rawQuery("SELECT before_qty FROM stock_movements WHERE stock_item_id=? AND datetime(created_at,'localtime')>=${end} ORDER BY datetime(created_at),id LIMIT 1",arrayOf(id.toString())).use{if(it.moveToFirst())it.getDouble(0) else null}
                closing=lastBeforeEnd ?: firstAfterEnd ?: current
            }
            a.add(InventoryRow(c.getString(1),closing,0.0,0.0,"صنف مخزون",c.getString(3)?:"قطعة",opening,incoming,sold,c.getDouble(4)))
        }}
        return a
    }
    fun stockAlerts(filter:String="الكل"):List<InventoryRow> = inventoryReport(filter).filter{it.quantity<=0.0 || (it.minQty>0.0 && it.quantity<=it.minQty)}
    fun stockValue():Double{readableDatabase.rawQuery("SELECT ifnull(sum(qty*cost),0) FROM products",null).use{it.moveToFirst();return it.getDouble(0)}}
    fun period():String{readableDatabase.rawQuery("SELECT opened_at FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())return "فترة مفتوحة منذ ${it.getString(0)}"};return "لا توجد فترة عمل مفتوحة"}
    fun latestPeriodTimes():Pair<Long,Long?>? {
        return readableDatabase.rawQuery("SELECT opened_at,closed_at FROM work_periods ORDER BY id DESC LIMIT 1",null).use { c ->
            if(!c.moveToFirst()) return@use null
            fun parse(value:String):Long?=runCatching { LocalDateTime.parse(value,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).toInstant(ZoneOffset.UTC).toEpochMilli() }.getOrNull()
            val start=parse(c.getString(0)) ?: return@use null
            start to (if(c.isNull(1)) null else parse(c.getString(1)))
        }
    }
    fun openPeriod(cash:Double){val d=writableDatabase;d.beginTransaction();try{d.execSQL("UPDATE work_periods SET is_open=0,closed_at=COALESCE(closed_at,CURRENT_TIMESTAMP) WHERE is_open=1");val v=ContentValues().apply{put("opening_cash",cash)};d.insert("work_periods",null,v);d.setTransactionSuccessful()}finally{d.endTransaction()}}
    fun closePeriod(){writableDatabase.execSQL("UPDATE work_periods SET is_open=0,closed_at=CURRENT_TIMESTAMP WHERE is_open=1")}
    fun setBackupFolder(uri:Uri){prefs.edit().putString("tree_uri",uri.toString()).apply()}
    fun backupFolder():Uri?=prefs.getString("tree_uri",null)?.let{runCatching{Uri.parse(it)}.getOrNull()}
    fun createBackup(treeUri:Uri):Boolean=runCatching{
        writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use{while(it.moveToNext()){} }
        val name="QmaxSale_Backup_${System.currentTimeMillis()}.zip"
        val parentUri=DocumentsContract.buildDocumentUriUsingTree(treeUri,DocumentsContract.getTreeDocumentId(treeUri))
        val outUri=DocumentsContract.createDocument(appContext.contentResolver,parentUri,"application/zip",name) ?: return false
        appContext.contentResolver.openOutputStream(outUri)?.use{raw->ZipOutputStream(raw).use{zip->
            val dbFile=appContext.getDatabasePath("qmax_sale.db")
            require(dbFile.exists())
            zip.putNextEntry(ZipEntry("qmax_sale.db"));dbFile.inputStream().use{it.copyTo(zip)};zip.closeEntry()
            val sp=File(appContext.applicationInfo.dataDir,"shared_prefs")
            if(sp.exists()) sp.listFiles()?.forEach{f->zip.putNextEntry(ZipEntry("shared_prefs/${f.name}"));f.inputStream().use{it.copyTo(zip)};zip.closeEntry()}
        }} ?: return false
        true
    }.getOrDefault(false)
    fun autoBackupAfterClose():Boolean{val folder=backupFolder()?:return false;return createBackup(folder)}
    fun closePeriodWithBackup():Boolean{
        val openId=readableDatabase.rawQuery("SELECT id FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())it.getLong(0) else return false}
        closePeriod()
        if(autoBackupAfterClose())return true
        writableDatabase.execSQL("UPDATE work_periods SET is_open=1,closed_at=NULL WHERE id=?",arrayOf(openId))
        return false
    }
    fun language():String = prefs.getString("app_language", "ar") ?: "ar"
    fun setLanguage(value:String) { prefs.edit().putString("app_language", if(value=="en") "en" else "ar").apply() }
    fun reportFolder():Uri?=appContext.getSharedPreferences("qmax_reports",Context.MODE_PRIVATE).getString("tree_uri",null)?.let{runCatching{Uri.parse(it)}.getOrNull()}
    fun setReportFolder(uri:Uri){appContext.getSharedPreferences("qmax_reports",Context.MODE_PRIVATE).edit().putString("tree_uri",uri.toString()).apply()}
    fun printerPaper():String=appContext.getSharedPreferences("qmax_printer",Context.MODE_PRIVATE).getString("paper","a4")?:"a4"
    fun setPrinterPaper(value:String){appContext.getSharedPreferences("qmax_printer",Context.MODE_PRIVATE).edit().putString("paper",value).apply()}
    fun printerOrientation():String=appContext.getSharedPreferences("qmax_printer",Context.MODE_PRIVATE).getString("orientation","portrait")?:"portrait"
    fun setPrinterOrientation(value:String){appContext.getSharedPreferences("qmax_printer",Context.MODE_PRIVATE).edit().putString("orientation",value).apply()}
    fun printerFontSize():String=appContext.getSharedPreferences("qmax_printer",Context.MODE_PRIVATE).getString("font_size","12")?:"12"
    fun setPrinterFontSize(value:String){appContext.getSharedPreferences("qmax_printer",Context.MODE_PRIVATE).edit().putString("font_size",value).apply()}
    private fun createInternalSafetyBackup():Boolean = runCatching {
        writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use { while(it.moveToNext()){} }
        val dir=File(appContext.filesDir,"safety_backups").apply{mkdirs()}
        val out=File(dir,"QmaxSale_Before_Clear_${System.currentTimeMillis()}.zip")
        ZipOutputStream(out.outputStream()).use { zip ->
            val dbFile=appContext.getDatabasePath("qmax_sale.db"); require(dbFile.exists())
            zip.putNextEntry(ZipEntry("qmax_sale.db")); dbFile.inputStream().use{it.copyTo(zip)}; zip.closeEntry()
            val sp=File(appContext.applicationInfo.dataDir,"shared_prefs")
            if(sp.exists()) sp.listFiles()?.forEach { f -> zip.putNextEntry(ZipEntry("shared_prefs/${f.name}")); f.inputStream().use{it.copyTo(zip)}; zip.closeEntry() }
        }
        out.exists() && out.length()>0
    }.getOrDefault(false)
    // Backup must succeed before any destructive operation. Definitions remain; transaction history and stock balances reset.
    fun clearAllTransactions():Boolean {
        val backedUp = backupFolder()?.let { createBackup(it) } ?: createInternalSafetyBackup()
        if(!backedUp) return false
        val d=writableDatabase
        d.beginTransaction()
        try {
            listOf("invoice_payments","invoice_lines","invoices","stock_movements","stock_add_lines","stock_add_invoices","work_periods").forEach { table -> d.delete(table,null,null) }
            d.execSQL("UPDATE products SET qty=0")
            d.execSQL("UPDATE stock_items SET qty=0")
            d.execSQL("UPDATE customers SET balance=0")
            d.setTransactionSuccessful()
            return true
        } finally { d.endTransaction() }
    }
    fun restoreBackup(uri:Uri):Boolean=runCatching{
        val temp=File(appContext.cacheDir,"restore_qmax_sale.db")
        val prefStage=File(appContext.cacheDir,"restore_prefs").apply{deleteRecursively();mkdirs()}
        var found=false
        appContext.contentResolver.openInputStream(uri)?.use{input->ZipInputStream(input).use{zip->
            while(true){val entry=zip.nextEntry?:break
                if(entry.name=="qmax_sale.db") {temp.outputStream().use{zip.copyTo(it)};found=true}
                else if(entry.name.startsWith("shared_prefs/") && entry.name.substringAfter("shared_prefs/").matches(Regex("[A-Za-z0-9_.-]+"))) {
                    val prefName=entry.name.substringAfter("shared_prefs/")
                    File(prefStage,prefName).outputStream().use{zip.copyTo(it)}
                }
                zip.closeEntry()
            }
        }} ?: return false
        require(found && temp.length()>0)
        val header=ByteArray(16);temp.inputStream().use{require(it.read(header)==16)}
        require(String(header,Charsets.US_ASCII).startsWith("SQLite format 3"))
        val checkDb=SQLiteDatabase.openDatabase(temp.absolutePath,null,SQLiteDatabase.OPEN_READONLY)
        val integrity=try{checkDb.rawQuery("PRAGMA integrity_check",null).use{it.moveToFirst() && it.getString(0)=="ok"}}finally{checkDb.close()}
        require(integrity)
        close()
        val target=appContext.getDatabasePath("qmax_sale.db");target.parentFile?.mkdirs()
        File(target.path+"-wal").delete();File(target.path+"-shm").delete()
        temp.copyTo(target,true);temp.delete()
        if(prefStage.exists()) prefStage.listFiles()?.forEach{it.copyTo(File(File(appContext.applicationInfo.dataDir,"shared_prefs").apply{mkdirs()},it.name),true)}
        prefStage.deleteRecursively()
        true
    }.getOrDefault(false)
}
private data class AppUser(val id:Long,val username:String,val role:String,val permissions:Set<String> = emptySet())
private data class StockItem(val id:Long,val name:String,val barcode:String,val code:String,val unit:String,val qty:Double,val minQty:Double)
private data class StockDashboardRow(val id:Long,val name:String,val unit:String,val sold:Double,val incoming:Double,val current:Double)
private data class StockDocumentRow(val id:Long,val createdAt:String,val note:String,val itemCount:Int)
private data class StockDocumentLine(val stockItemId:Long,val name:String,val unit:String,val quantity:Double)
private data class StockMovement(val id:Long,val stockItemId:Long,val stockName:String,val type:String,val quantity:Double,val before:Double,val after:Double,val reason:String,val createdAt:String)
private data class RecipeRow(val id:Long,val productId:Long,val productName:String,val stockId:Long,val stockName:String,val quantity:Double,val unit:String)
private data class Customer(val id:Long,val name:String,val mobile:String,val governorate:String,val area:String,val shop:String)
private data class PaymentMovement(val id:Long,val invoiceId:Long,val amount:Double,val createdAt:String)
private data class InvoiceSummary(val id:Long,val createdAt:String,val total:Double,val paid:Double,val due:Double,val method:String,val customerId:Long?,val customerName:String,val mobile:String,val governorate:String,val shop:String,val discount:Double)
private data class InvoiceLine(val id:Long,val productId:Long,val name:String,val qty:Double,val price:Double,val cost:Double)
private data class Product(val id:Long,val name:String,val code:String,val barcode:String,val category:String,val cost:Double,val price:Double,val qty:Double)
private data class Tile(val name:String,val icon:ImageVector)
private data class SalesProductRow(val name:String,val quantity:Double,val total:Double)
private data class InventoryRow(val name:String,val quantity:Double,val price:Double,val cost:Double,val source:String,val unit:String="وحدة",val opening:Double=0.0,val incoming:Double=0.0,val sold:Double=0.0,val minQty:Double=0.0)
private data class PeriodReport(val sales:Double,val due:Double,val invoices:Int,val payments:Map<String,Double>,val items:List<SalesProductRow>,val discount:Double)
private data class UserCommissionRow(val invoiceId:Long,val createdAt:String,val productName:String,val quantity:Double,val perUnit:Double,val total:Double)

private fun backPage(current:String):String=when(current){
    "إعدادات التقارير","إعدادات الطابعة","إعدادات الحسابات","إعدادات مبيعات المستخدم","المستخدمون","اللغة","النسخ الاحتياطي","قائمة المنتجات","إدارة المخزون"->"إدارة البرنامج"
    "أصناف المخزون","الريسبي","إذن صرف عهدة","سجلات حركة المخزون"->"إدارة المخزون"
    "تقرير فترة العمل","تقرير مبيعات المنتجات","تقرير الجرد","تنبيهات المخزون","تقرير أذون صرف عهدة","تقرير عمولات المستخدمين"->"التقارير"
    "التقارير"->"الرئيسية"
    else->"الرئيسية"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun QmaxApp(db:LocalDb, activity:ComponentActivity) {
    var page by rememberSaveable{mutableStateOf("الرئيسية")};var revision by remember{mutableIntStateOf(0)};var activeUser by remember{mutableStateOf(db.restoreSession())}
    var pendingLines by remember{mutableStateOf<List<Pair<Product,Double>>>(emptyList())}
    var activeCustomer by remember{mutableStateOf<Customer?>(null)}
    var selectedPaymentAccount by remember{mutableStateOf("نقدية")}
    var selectedInvoiceId by remember{mutableStateOf(0L)};var selectedReport by remember{mutableStateOf("تقرير فترة العمل")}
    val allTiles=listOf(Tile("فترة العمل",Icons.Default.Schedule),Tile("نقاط البيع",Icons.Default.PointOfSale),Tile("الفواتير",Icons.Default.Receipt),Tile("حركة المبيعات",Icons.Default.ReceiptLong),Tile("حسابات العملاء",Icons.Default.Groups),Tile("المخزون",Icons.Default.Inventory2),Tile("الحسابات",Icons.Default.AccountBalanceWallet),Tile("التقارير",Icons.Default.Assessment),Tile("إدارة البرنامج",Icons.Default.Settings))
    val tiles=allTiles
    LaunchedEffect(page, activeUser?.id) { val user=activeUser; if(user!=null && page!="الرئيسية" && !canOpenSection(user,page)) page="الرئيسية" }
    val folderPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->if(uri!=null){runCatching{activity.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)};db.setBackupFolder(uri);revision++}}
    val reportsFolderPicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->if(uri!=null){runCatching{activity.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)};db.setReportFolder(uri);revision++}}
    val restorePicker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){val ok=db.restoreBackup(uri);page=if(ok)"الرئيسية" else "النسخ الاحتياطي";revision++}}
    BackHandler(enabled=page!="الرئيسية"){page=backPage(page)}
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(topBar={if(activeUser!=null && page!="الرئيسية")TopAppBar(title={Text(if(db.language()=="en") englishTile(page).let{if(it==page) localizedPage(page) else it} else page,fontWeight=FontWeight.Bold)},navigationIcon={IconButton(onClick={page=backPage(page)}){Icon(Icons.Default.ArrowBack,"رجوع")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.White))},bottomBar={if(activeUser!=null && page=="الرئيسية"){Box(Modifier.fillMaxWidth().padding(horizontal=12.dp, vertical=8.dp),contentAlignment=Alignment.Center){Button(onClick={db.saveSession(null);activeUser=null;page="الرئيسية";pendingLines= emptyList();activeCustomer=null},modifier=Modifier.fillMaxWidth(0.72f).height(48.dp),shape=androidx.compose.ui.graphics.RectangleShape,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFD32F2F),contentColor=Color.White)){Text(if(db.language()=="en")"Log out" else "تسجيل الخروج",fontWeight=FontWeight.Bold)}}}},containerColor=Bg){pad->
            if(activeUser==null) LoginPage(db,pad,language=db.language(),onLogin={db.saveSession(it);activeUser=it;page="الرئيسية";revision++}) else key(revision){when(page){
                "الرئيسية"->Home(db,tiles,pad,db.language()){target->if(canOpenSection(activeUser!!,target)) page=target}
                "المنتجات"->Products(db,pad){revision++}
                "نقاط البيع"->{if(!db.hasOpenPeriod()) AlertDialog(onDismissRequest={page="الرئيسية"},title={Text("فترة العمل غير مفتوحة")},text={Text("يجب بدء فترة العمل أولًا قبل إنشاء فاتورة.")},confirmButton={TextButton(onClick={page="الرئيسية"}){Text("حسنًا")}}) else POS(db,pad,initialLines=pendingLines,customer=activeCustomer,user=activeUser!!,done={revision++},newInvoice={pendingLines= emptyList();activeCustomer=null;revision++;page="الرئيسية"},openSettlement={lines->pendingLines=lines;page="تسوية الحساب"})}
                "تسوية الحساب"->SettlementScreen(db,pendingLines,pad,customerId=activeCustomer?.id,user=activeUser!!,onBack={page="نقاط البيع"},onDone={revision++;pendingLines= emptyList();activeCustomer=null;page="الرئيسية"})
                "الفواتير"->InvoicesPage(db,pad,onSelect={selectedInvoiceId=it;page="عرض الفاتورة"})
                "عرض الفاتورة"->InvoiceDetails(db,selectedInvoiceId,pad,activity,onDeleted={revision++;page="الفواتير"})
                "تعديل الفاتورة"->InvoiceEditor(db,selectedInvoiceId,pad,onSaved={revision++;page="حركة المبيعات"},onCancel={page="عرض الفاتورة"})
                "حركة المبيعات"->SalesMovements(db,pad,onView={selectedInvoiceId=it;page="عرض الفاتورة"})
                "حسابات العملاء"->Customers(db,pad,onSale={customer->activeCustomer=customer;pendingLines= emptyList();page="نقاط البيع"},onDetails={customer->activeCustomer=customer;page="تفاصيل حساب العميل"},done={revision++})
                "تفاصيل حساب العميل"->CustomerDetails(db,activeCustomer,pad,onSale={customer->activeCustomer=customer;pendingLines= emptyList();page="نقاط البيع"},onEdit={page="تعديل بيانات العميل"},onCollect={page="تحصيل العميل"})
                "تحصيل العميل"->CustomerCollection(db,activeCustomer,pad,onDone={revision++;page="تفاصيل حساب العميل"},onCancel={page="تفاصيل حساب العميل"})
                "تعديل بيانات العميل"->CustomerEditor(activeCustomer,pad,onSave={c,n,m,g,a,shop->db.updateCustomer(c.id,n,m,g,a,shop);activeCustomer=Customer(c.id,n,m,g,a,shop);revision++;page="تفاصيل حساب العميل"},onCancel={page="تفاصيل حساب العميل"})
                "المخزون"->Inventory(db,pad){revision++}
                "الحسابات"->AccountsHome(db,pad,onPayments={page="حركة المدفوعات"},onCustomers={page="عملاء الحسابات"},openDetails={page=it})
                "عملاء الحسابات"->AccountsCustomers(db,pad,onDetails={activeCustomer=it;page="تفاصيل حساب العميل"})
                "حركة المدفوعات"->PaymentAccounts(db,pad,onSelect={selectedPaymentAccount=it;page="كشف حساب $it"})
                "كشف حساب نقدية","كشف حساب إنستا باي","كشف حساب حساب بنكي"->PaymentStatement(db,selectedPaymentAccount,pad,onDetails={page="تفاصيل الحساب ${selectedPaymentAccount}"})
                "تفاصيل الحساب نقدية","تفاصيل الحساب إنستا باي","تفاصيل الحساب حساب بنكي"->PaymentAccountDetails(db,selectedPaymentAccount,pad)
                "تفاصيل إيرادات مبيعات اليوم"->SalesDueAccountDetails(db,"إيرادات مبيعات اليوم",pad)
                "تفاصيل المستحقات"->SalesDueAccountDetails(db,"المستحقات",pad)
                "التقارير"->ReportsMenu(db,pad){selectedReport=it;page=it}
                "تقرير فترة العمل"->PeriodReportPage(db,pad)
                "تقرير مبيعات المنتجات"->ProductSalesReportPage(db,pad)
                "تقرير الجرد"->InventoryReportPage(db,pad)
                "تنبيهات المخزون"->StockAlertsReportPage(db,pad)
                "تقرير أذون صرف عهدة"->StockIssueReportPage(db,pad)
                "إدارة البرنامج"->ProgramManagementMenu(pad,db.language()){target->if(canOpenSection(activeUser!!,target))page=target}
                "إعدادات الحسابات"->AccountSettingsPage(db,pad,done={revision++})
                "إعدادات مبيعات المستخدم"->UserCommissionSettingsPage(db,pad,done={revision++})
                "تقرير عمولات المستخدمين"->UserCommissionReportPage(db,activeUser!!,pad)
                "إعدادات التقارير"->ReportSettingsPage(db,pad,onChooseFolder={reportsFolderPicker.launch(db.reportFolder())},done={revision++})
                "إعدادات الطابعة"->PrinterSettingsPage(db,pad,activity)
                "المستخدمون"->UsersPage(db,pad,current=activeUser!!,done={revision++})
                "اللغة"->LanguagePage(db,pad,onChanged={revision++})
                "النسخ الاحتياطي"->BackupPage(db,pad,onChooseFolder={folderPicker.launch(null)},onBackup={db.backupFolder()?.let{db.createBackup(it)} ?: false},onRestore={restorePicker.launch(arrayOf("application/zip","application/octet-stream"))})
                "إدارة المخزون"->StockManagementMenu(pad){target->if(canOpenSection(activeUser!!,target))page=target}
                "أصناف المخزون"->StockCatalog(db,pad){revision++}
                "الريسبي"->RecipeManager(db,pad){revision++}
                "إذن صرف عهدة"->StockAddInvoicePage(db,pad){revision++}
                "سجلات حركة المخزون"->StockLedgerPage(db,pad){revision++}
                "قائمة المنتجات"->ProductCatalog(db,pad){revision++}
                "حذف المنتجات","تعديل المنتجات","تعديل الأسعار"->ProductManagement(db,page,pad){revision++}
                "فترة العمل"->Work(db,pad,onClose={if(db.closePeriodWithBackup()){revision++;true}else{Toast.makeText(activity,"تعذر إنشاء النسخة الاحتياطية. لم يتم إنهاء فترة العمل.",Toast.LENGTH_LONG).show();false}},onOpen={db.openPeriod(0.0);revision++})
            }}
        }
    }
}
private fun localizedPage(ar:String):String = when(ar){"المستخدمون"->"Users";"النسخ الاحتياطي"->"Backup and Restore";"اللغة"->"Language";"تسوية الحساب"->"Settlement";"إدارة المخزون"->"Inventory Management";else->ar}

private fun englishTile(ar:String):String = when(ar){
    "نقاط البيع"->"Point of Sale"; "الفواتير"->"Invoices"; "حركة المبيعات"->"Sales Movements"; "حسابات العملاء"->"Customer Accounts"; "المخزون"->"Inventory"; "الحسابات"->"Accounts"; "التقارير"->"Reports"; "إدارة البرنامج"->"Program Management"; "فترة العمل"->"Work Period"; else->ar
}

@Composable private fun Home(db:LocalDb,tiles:List<Tile>,pad:PaddingValues,language:String="ar",open:(String)->Unit){
    fun label(ar:String,en:String)=if(language=="en")en else ar
    val t=db.totals();val balances=db.paymentAccountBalances()
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){
        Text("Qmax POS",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text(label("إدارة المبيعات والمخزون","Sales and Inventory Management"),color=Color.Gray)
        Spacer(Modifier.height(14.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.fillMaxWidth().padding(14.dp)){
                Text(label("ملخص اليوم","Today Summary"),fontWeight=FontWeight.Bold,fontSize=17.sp)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    Metric(label("مبيعات اليوم","Today Sales"),fmt(t.first))
                    Metric(label("المستحقات","Outstanding"),fmt(t.second))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    Metric(label("عدد الفواتير","Invoices"),t.third.toString())
                    Metric(label("الحساب البنكي","Bank Account"),fmt(balances["حساب بنكي"]?:0.0))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    Metric(label("النقدية","Cash"),fmt(balances["نقدية"]?:0.0))
                    Metric(label("إنستا باي","InstaPay"),fmt(balances["إنستا باي"]?:0.0))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(3),modifier=Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(tiles){tile->Card(Modifier.height(112.dp).clickable{open(tile.name)},colors=CardDefaults.cardColors(containerColor=Blue)){Column(Modifier.fillMaxSize().padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(tile.icon,label(tile.name,englishTile(tile.name)),tint=Color.White,modifier=Modifier.size(30.dp));Spacer(Modifier.height(7.dp));Text(label(tile.name,englishTile(tile.name)),color=Color.White,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}
        }
    }
}

@Composable private fun Metric(label:String,value:String){Column{Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=Ink,fontWeight=FontWeight.Bold,fontSize=16.sp)}}
@Composable private fun Products(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var n by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var bar by remember{mutableStateOf("")};var cat by remember{mutableStateOf("")};var cost by remember{mutableStateOf("0")};var price by remember{mutableStateOf("")};var qty by remember{mutableStateOf("0")};var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("إضافة منتج",fontWeight=FontWeight.Bold,fontSize=18.sp)
        Input("اسم المنتج",n,{n=it});Input("كود المنتج",code,{code=it});Input("الباركود",bar,{bar=it});Input("التصنيف",cat,{cat=it})
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Input("سعر الشراء",cost,{cost=it},Modifier.weight(1f),true);Input("سعر البيع *",price,{price=it},Modifier.weight(1f),true)}
        Input("الكمية الافتتاحية",qty,{qty=it},numeric=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        Button(onClick={val selling=price.toDoubleOrNull();if(n.isBlank()){error="اسم المنتج مطلوب"}else if(selling==null||selling<=0.0){error="السعر مطلوب، أدخل سعر بيع صحيحًا"}else{db.addProduct(n,code,bar,cat,cost.toDoubleOrNull()?:0.0,selling,qty.toDoubleOrNull()?:0.0);n="";code="";bar="";cat="";cost="0";price="";qty="0";error="";done()}},Modifier.fillMaxWidth()){Text("حفظ المنتج")}
        Text("قائمة المنتجات",fontWeight=FontWeight.Bold)
        LazyColumn{items(db.products()){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","الكود ${p.code} | الكمية ${p.qty} | التكلفة ${fmt(p.cost)}")}}
    }
}

@Composable private fun LoginPage(db:LocalDb,pad:PaddingValues,language:String="ar",onLogin:(AppUser)->Unit){
    val en=language=="en"
    var username by remember{mutableStateOf("admin")};var password by remember{mutableStateOf("")};var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(22.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
        Image(painter=painterResource(id=R.drawable.qmax_pos_login),contentDescription="Qmax POS",modifier=Modifier.fillMaxWidth().height(112.dp),contentScale=ContentScale.Fit)
        Spacer(Modifier.height(14.dp))
        Text(if(en)"Sign in" else "تسجيل الدخول",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
        Input(if(en)"Username" else "اسم المستخدم",username,{username=it})
        OutlinedTextField(value=password,onValueChange={password=it},modifier=Modifier.fillMaxWidth().padding(vertical=3.dp),label={Text(if(en)"Password" else "كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation())
        Text(if(en)"First login: username admin, password 1234. Change it after signing in." else "أول دخول: اسم المستخدم admin وكلمة المرور 1234 — غيّره بإضافة مستخدم جديد واستخدامه.",fontSize=11.sp,color=Color.Gray)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(onClick={val u=db.authenticate(username,password);if(u==null)error=if(en)"Incorrect username or password" else "اسم المستخدم أو كلمة المرور غير صحيحة" else onLogin(u)},Modifier.fillMaxWidth()){Text(if(en)"Sign in" else "دخول")}
    }
}
private val permissionSections = listOf(
    "نقاط البيع" to "pos", "الفواتير" to "invoices", "حركة المبيعات" to "sales_movements",
    "حسابات العملاء" to "customers", "المخزون" to "inventory", "الحسابات" to "accounts",
    "التقارير" to "reports", "إدارة البرنامج" to "program_management", "فترة العمل" to "work_period",
    "المستخدمون" to "users", "النسخ الاحتياطي" to "backup", "قائمة المنتجات" to "products",
    "إدارة المخزون" to "stock_management", "حركة المدفوعات" to "payments", "عملاء الحسابات" to "customers",
    "تقرير فترة العمل" to "reports", "تقرير مبيعات المنتجات" to "reports", "تقرير الجرد" to "reports", "تنبيهات المخزون" to "reports", "تقرير أذون صرف عهدة" to "reports", "تقرير عمولات المستخدمين" to "reports",
    "أصناف المخزون" to "stock_management", "الريسبي" to "stock_management", "إذن صرف عهدة" to "stock_management", "سجلات حركة المخزون" to "stock_management",
    "تعديل المنتجات" to "products", "حذف المنتجات" to "products", "تعديل الأسعار" to "products", "عملاء الحسابات" to "accounts",
    "تحصيل العميل" to "customers", "تفاصيل حساب العميل" to "customers", "حركة المدفوعات" to "payments",
    "تسوية الحساب" to "pos", "عرض الفاتورة" to "invoices", "تعديل الفاتورة" to "invoices",
    "إعدادات الحسابات" to "program_management", "إعدادات التقارير" to "program_management", "إعدادات الطابعة" to "program_management", "إعدادات مبيعات المستخدم" to "program_management", "تقرير عمولات المستخدمين" to "reports", "تفاصيل إيرادات مبيعات اليوم" to "accounts", "تفاصيل المستحقات" to "accounts", "تفاصيل الحساب نقدية" to "payments", "تفاصيل الحساب إنستا باي" to "payments", "تفاصيل الحساب حساب بنكي" to "payments",
    "كشف حساب نقدية" to "payments", "كشف حساب إنستا باي" to "payments", "كشف حساب حساب بنكي" to "payments",
    "تعديل بيانات العميل" to "customers", "المنتجات" to "products"
)
private val defaultRepPermissions = setOf("pos")
private fun canOpenSection(user:AppUser, section:String):Boolean = user.role=="مدير" || user.permissions.contains(permissionSections.firstOrNull{it.first==section}?.second ?: section)

@Composable private fun UsersPage(db:LocalDb,pad:PaddingValues,current:AppUser,done:()->Unit){
    var username by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var role by remember{mutableStateOf("مندوب")};var selectedPermissions by remember{mutableStateOf(defaultRepPermissions)}
    var message by remember{mutableStateOf("")};var selected by remember{mutableStateOf<AppUser?>(null)};var editing by remember{mutableStateOf(false)};var deleting by remember{mutableStateOf<AppUser?>(null)}
    val permissionOptions = listOf(
        "الدخول إلى نقاط البيع" to "pos", "الدخول إلى الفواتير" to "invoices", "الدخول إلى حركة المبيعات" to "sales_movements",
        "الدخول إلى حسابات العملاء" to "customers", "الدخول إلى المخزون" to "inventory", "الدخول إلى الحسابات" to "accounts",
        "الدخول إلى التقارير" to "reports", "الدخول إلى إدارة البرنامج" to "program_management", "الدخول إلى فترة العمل" to "work_period",
        "إدارة المستخدمين" to "users", "النسخ الاحتياطي والاستعادة" to "backup", "إدارة قائمة المنتجات" to "products",
        "إدارة المخزون والريسبي" to "stock_management", "حركة المدفوعات" to "payments", "عملاء الحسابات" to "customers",
        "تقرير فترة العمل" to "reports", "تقرير مبيعات المنتجات" to "reports", "تقرير الجرد" to "reports", "تنبيهات المخزون" to "reports", "تقرير أذون صرف عهدة" to "reports", "تقرير عمولات المستخدمين" to "reports"
    )
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp).verticalScroll(rememberScrollState())) {
        Text("المستخدمون",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("إضافة مستخدم جديد",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
        Input("اسم المستخدم",username,{username=it})
        OutlinedTextField(value=password,onValueChange={password=it},modifier=Modifier.fillMaxWidth().padding(vertical=3.dp),label={Text("كلمة المرور (4 أحرف على الأقل)")},singleLine=true,visualTransformation=PasswordVisualTransformation())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=role=="مدير",onClick={role="مدير";selectedPermissions=permissionOptions.map{it.second}.toSet()},label={Text("مدير")});FilterChip(selected=role=="مندوب",onClick={role="مندوب";selectedPermissions=defaultRepPermissions},label={Text("مندوب")})}
        Text("الصلاحيات (ضع علامة أمام كل قسم مسموح)",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
        permissionOptions.forEach{(label,key)->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=role=="مدير"||selectedPermissions.contains(key),onCheckedChange={checked->selectedPermissions=if(checked)selectedPermissions+key else selectedPermissions-key},enabled=role!="مدير");Text(label)}}
        Button(onClick={val ok=db.addUser(username,password,role,if(role=="مدير")permissionOptions.map{it.second}.toSet() else selectedPermissions);message=if(ok){username="";password="";role="مندوب";selectedPermissions=defaultRepPermissions;"تمت إضافة المستخدم"}else "تعذر الإضافة: تأكد من اسم المستخدم وكلمة المرور وعدم التكرار";done()},Modifier.fillMaxWidth()){Text("إضافة مستخدم")}
        if(message.isNotBlank())Text(message,color=Blue)
        Text("المستخدمون المسجلون",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp))
        db.users().forEach{u->Row(Modifier.fillMaxWidth().padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f).clickable{selected=u}){Text(u.username,fontWeight=FontWeight.Bold);Text(if(u.role=="مدير")"مدير - كل الصلاحيات" else "مندوب - صلاحيات مخصصة",fontSize=12.sp,color=Color.Gray)};TextButton(onClick={selected=u;editing=true}){Text("تعديل")};TextButton(onClick={if(u.id!=current.id)deleting=u}){Text("حذف",color=MaterialTheme.colorScheme.error)}};Divider()}
    }
    if(selected!=null && !editing) AlertDialog(onDismissRequest={selected=null},title={Text("بيانات المستخدم")},text={Text("الاسم: ${selected!!.username}\nالنوع: ${selected!!.role}\nالصلاحيات: ${if(selected!!.role=="مدير")"كاملة" else selected!!.permissions.size.toString()+" صلاحية"}")},confirmButton={TextButton(onClick={editing=true}){Text("تعديل")}},dismissButton={TextButton(onClick={selected=null}){Text("إغلاق")}})
    if(editing && selected!=null){val u=selected!!;var editName by remember(u.id){mutableStateOf(u.username)};var editPassword by remember(u.id){mutableStateOf("")};var editRole by remember(u.id){mutableStateOf(u.role)};var editPermissions by remember(u.id){mutableStateOf(u.permissions)}
        AlertDialog(onDismissRequest={editing=false;selected=null},title={Text("تعديل المستخدم")},text={Column(Modifier.heightIn(max=520.dp)){Input("اسم المستخدم",editName,{editName=it});OutlinedTextField(value=editPassword,onValueChange={editPassword=it},label={Text("كلمة مرور جديدة (اتركها فارغة دون تغيير)")},visualTransformation=PasswordVisualTransformation(),singleLine=true);Row{FilterChip(selected=editRole=="مدير",onClick={editRole="مدير";editPermissions=permissionOptions.map{it.second}.toSet()},label={Text("مدير")});FilterChip(selected=editRole=="مندوب",onClick={editRole="مندوب";editPermissions=defaultRepPermissions},label={Text("مندوب")})};Text("الصلاحيات",fontWeight=FontWeight.Bold);Column(Modifier.heightIn(max=300.dp)){permissionOptions.forEach{(label,key)->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=editRole=="مدير"||editPermissions.contains(key),onCheckedChange={v->editPermissions=if(v)editPermissions+key else editPermissions-key},enabled=editRole!="مدير");Text(label)}}}}},confirmButton={TextButton(onClick={message=if(db.updateUser(u.id,editName,editPassword,editRole,if(editRole=="مدير")permissionOptions.map{it.second}.toSet() else editPermissions)){editing=false;selected=null;done();"تم تعديل المستخدم"}else "تعذر التعديل: راجع الاسم وكلمة المرور"}){Text("حفظ")}},dismissButton={TextButton(onClick={editing=false;selected=null}){Text("إلغاء")}})
    }
    if(deleting!=null)AlertDialog(onDismissRequest={deleting=null},title={Text("حذف المستخدم")},text={Text("هل تريد حذف ${deleting!!.username}؟")},confirmButton={TextButton(onClick={db.deleteUser(deleting!!.id);deleting=null;done()}){Text("حذف")}},dismissButton={TextButton(onClick={deleting=null}){Text("إلغاء")}})
}

private val configurableReports = listOf("تقرير فترة العمل","تقرير مبيعات المنتجات","تقرير الجرد","تنبيهات المخزون","تقرير أذون صرف عهدة","تقرير عمولات المستخدمين")

@Composable private fun ReportSettingsPage(db:LocalDb,pad:PaddingValues,onChooseFolder:()->Unit,done:()->Unit){
    val folder=db.reportFolder()
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState())){
        Text("إعدادات التقارير",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("إعدادات عامة تُستخدم مع جميع التقارير.",color=Color.Gray,modifier=Modifier.padding(vertical=8.dp))
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(14.dp)){
                Text("مجلد حفظ التقارير PDF",fontWeight=FontWeight.Bold,color=Ink)
                Text(if(folder==null)"لم يتم تحديد مجلد بعد" else "تم تحديد مجلد حفظ التقارير",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(vertical=6.dp))
                Button(onClick=onChooseFolder,Modifier.fillMaxWidth()){Text(if(folder==null)"اختيار مجلد الحفظ" else "تغيير مجلد الحفظ")}
                Text("سيتم استخدام آخر مجلد تختاره تلقائيًا عند حفظ أي تقرير.",fontSize=12.sp,color=Color.Gray)
            }
        }
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(14.dp)){
                Text("إظهار التقارير داخل الأيقونة",fontWeight=FontWeight.Bold,color=Ink)
                Text("ضع علامة صح لإظهار التقرير داخل أيقونة التقارير، وأزلها لإخفائه دون حذف بياناته.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(vertical=6.dp))
                configurableReports.forEach { name ->
                    Row(Modifier.fillMaxWidth().clickable { db.setReportVisible(name,!db.isReportVisible(name)); done() }.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(name,Modifier.weight(1f),color=Ink,fontSize=14.sp)
                        androidx.compose.material3.Checkbox(checked=db.isReportVisible(name),onCheckedChange={db.setReportVisible(name,it);done()})
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth().padding(top=10.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(14.dp)){
                Text("فلاتر التقارير",fontWeight=FontWeight.Bold,color=Ink)
                Text("تظهر داخل كل تقرير فلاتر الفترة: اليوم، أمس، الأسبوع، الشهر، الشهر الماضي، والكل.",fontSize=13.sp,color=Color.Gray)
            }
        }
    }
}

@Composable private fun PrinterSettingsPage(db:LocalDb,pad:PaddingValues,activity:ComponentActivity){
    var paper by remember{mutableStateOf(db.printerPaper())}
    var orientation by remember{mutableStateOf(db.printerOrientation())}
    var fontSize by remember{mutableStateOf(db.printerFontSize())}
    var message by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(16.dp).verticalScroll(rememberScrollState())){
        Text("إعدادات الطابعة",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("تُجهز الفواتير والتقارير بتنسيق HTML، ثم تُرسل إلى خدمة الطباعة المثبتة على أندرويد.",color=Color.Gray,modifier=Modifier.padding(vertical=8.dp))
        Text("حجم الورق",fontWeight=FontWeight.Bold)
        Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=paper=="a4",onClick={paper="a4"});Text("A4")}
        Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=paper=="receipt",onClick={paper="receipt"});Text("إيصال حراري 80 مم")}
        Text("اتجاه الطباعة",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
        Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=orientation=="portrait",onClick={orientation="portrait"});Text("رأسي")}
        Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=orientation=="landscape",onClick={orientation="landscape"});Text("أفقي")}
        Text("حجم الخط",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            listOf("10","12","14","16").forEach{v->FilterChip(selected=fontSize==v,onClick={fontSize=v},label={Text(v)})}
        }
        Button(onClick={db.setPrinterPaper(paper);db.setPrinterOrientation(orientation);db.setPrinterFontSize(fontSize);message="تم حفظ إعدادات الطباعة"},Modifier.fillMaxWidth().padding(top=14.dp)){Text("حفظ الإعدادات")}
        OutlinedButton(onClick={runCatching{activity.startActivity(Intent(Settings.ACTION_PRINT_SETTINGS))}.onFailure{message="تعذر فتح إعدادات الطباعة على هذا الجهاز"}},Modifier.fillMaxWidth()){Text("إدارة الطابعات وخدمات الطباعة في أندرويد")}
        OutlinedButton(onClick={runCatching{activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))}.onFailure{message="تعذر فتح إعدادات Bluetooth"}},Modifier.fillMaxWidth()){Text("فتح إعدادات Bluetooth وإقران الطابعة")}
        Text("يمكن استخدام طابعة Bluetooth إذا كانت مدعومة من خلال خدمة طباعة مثبتة على الجهاز. البحث والاقتران بالطابعة يتم من إعدادات Bluetooth أو تطبيق/خدمة الطابعة.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=8.dp))
        if(message.isNotBlank())Text(message,color=Blue,modifier=Modifier.padding(top=8.dp))
    }
}

private fun escapeHtml(value:String):String=value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;")
private fun ComponentActivity.printInvoiceHtml(db:LocalDb,invoice:InvoiceSummary,lines:List<InvoiceLine>){
    val prefs=getSharedPreferences("qmax_printer",Context.MODE_PRIVATE)
    val paper=prefs.getString("paper","a4")?:"a4"
    val orientation=prefs.getString("orientation","portrait")?:"portrait"
    val font=prefs.getString("font_size","12")?:"12"
    val rows=lines.joinToString(""){line->"<tr><td>${escapeHtml(line.name)}</td><td>${fmt(line.qty)}</td><td>${fmt(line.price)}</td><td>${fmt(line.qty*line.price)}</td></tr>"}
    val date=escapeHtml(invoice.createdAt)
    val gross=lines.sumOf{it.qty*it.price}
    val discount=invoice.discount.coerceAtLeast(0.0).coerceAtMost(gross)
    val discountPercent=if(gross>0.0)discount*100.0/gross else 0.0
    val html="""<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>@page{size:${if(paper=="receipt")"80mm auto" else "A4 ${if(orientation=="landscape")"landscape" else "portrait"}"};margin:8mm}body{font-family:Arial,sans-serif;font-size:${font}px;color:#17324d;margin:0}h2{text-align:center;margin:0 0 12px} .meta{line-height:1.8;border:1px solid #ddd;padding:8px;margin-bottom:12px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:6px;text-align:right}th{background:#e8f1fb}.totals{margin-top:12px;line-height:2;font-weight:bold}.center{text-align:center}</style></head><body><h2>فاتورة مبيعات</h2><div class="meta">رقم الفاتورة: ${invoice.id}<br>التاريخ: $date<br>العميل: ${escapeHtml(invoice.customerName)}<br>الهاتف: ${escapeHtml(invoice.mobile.ifBlank{"—"})}<br>طريقة الدفع: ${escapeHtml(invoice.method)}</div><table><thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>$rows</tbody></table><div class="totals">الإجمالي قبل الخصم: ${fmt(gross)} ج.م<br>نسبة الخصم: ${fmt(discountPercent)}٪<br>قيمة الخصم: ${fmt(discount)} ج.م<br>الإجمالي بعد الخصم: ${fmt(invoice.total)} ج.م<br>المدفوع: ${fmt(invoice.paid)} ج.م<br>المتبقي: ${fmt(invoice.due)} ج.م</div><p class="center">شكرًا لتعاملكم معنا</p></body></html>"""
    val web=WebView(this)
    web.settings.javaScriptEnabled=false
    web.webViewClient=object:WebViewClient(){override fun onPageFinished(view:WebView,url:String?){runCatching{
        val manager=getSystemService(Context.PRINT_SERVICE) as PrintManager
        val adapter=view.createPrintDocumentAdapter("Qmax_Invoice_${invoice.id}")
        val media=if(paper=="receipt")PrintAttributes.MediaSize("QMAX_RECEIPT_80MM","80mm Receipt",3150,15000) else if(orientation=="landscape")PrintAttributes.MediaSize.ISO_A4.asLandscape() else PrintAttributes.MediaSize.ISO_A4
        val attrs=PrintAttributes.Builder().setMediaSize(media).setResolution(PrintAttributes.Resolution("qmax_print","Qmax Print",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build()
        manager.print("فاتورة_${invoice.id}",adapter,attrs)
    }.onFailure{Toast.makeText(this@printInvoiceHtml,"تعذر فتح الطباعة: ${it.localizedMessage}",Toast.LENGTH_LONG).show()}}}
    web.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)
}

private val reportPeriodOptions=listOf("اليوم","أمس","الأسبوع","الشهر","الشهر الماضي","الكل")
@Composable private fun ReportPeriodFilter(value:String,onChange:(String)->Unit){
    var expanded by remember{mutableStateOf(false)}
    Row(Modifier.fillMaxWidth().padding(vertical=6.dp),verticalAlignment=Alignment.CenterVertically){Text("الفترة الزمنية",fontWeight=FontWeight.SemiBold,color=Ink);Spacer(Modifier.weight(1f));Box{OutlinedButton(onClick={expanded=true}){Text("$value ▾")};DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){reportPeriodOptions.forEach{option->DropdownMenuItem(text={Text(option)},onClick={expanded=false;onChange(option)})}}}}
}

@Composable private fun ProgramManagementMenu(pad:PaddingValues,language:String="ar",open:(String)->Unit){
    val en=language=="en"
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(if(en)"Program Management" else "إدارة البرنامج",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text(if(en)"Manage products and application settings" else "إدارة المنتجات وبيانات البرنامج",color=Color.Gray)
        Spacer(Modifier.height(10.dp))
        RowCard(if(en)"Product List" else "قائمة المنتجات",if(en)"View, add, search, edit and delete products and change prices" else "عرض وإضافة وبحث وتعديل وحذف المنتجات وتعديل أسعارها"){open("قائمة المنتجات")}
        RowCard(if(en)"Users" else "المستخدمون",if(en)"Add users and configure administrator or sales-representative permissions" else "إضافة مستخدم وتحديد صلاحيات المدير أو المندوب"){open("المستخدمون")}
        RowCard(if(en)"Language" else "اللغة",if(en)"Choose Arabic or English interface language" else "اختيار لغة واجهة البرنامج العربية أو English"){open("اللغة")}
        RowCard(if(en)"Backup and Restore" else "النسخ الاحتياطي",if(en)"Automatic and manual backup, restore from ZIP" else "نسخ احتياطي تلقائي وعادي واستعادة ملف ZIP"){open("النسخ الاحتياطي")}
        RowCard("إعدادات التقارير","إعدادات شكل وبيانات التقارير ومجلد حفظ PDF"){open("إعدادات التقارير")}
        RowCard("إعدادات الطابعة","اختيار تنسيق الطباعة وإعدادات الورق والطباعة عبر خدمات أندرويد"){open("إعدادات الطابعة")}
        RowCard("إعدادات الحسابات","تحديد فترة احتساب المبيعات والمدفوعات وحسابات العملاء بشكل مستقل"){open("إعدادات الحسابات")}
        RowCard("إعدادات مبيعات المستخدم","تحديد عمولة كل قطعة لكل منتج مبيع"){open("إعدادات مبيعات المستخدم")}
        RowCard(if(en)"Inventory" else "المخزون",if(en)"Manage stock items, recipes, additions and movement records" else "إدارة أصناف المخزون والريسبي والإضافات وسجلات الحركة"){open("إدارة المخزون")}
    }
}

@Composable private fun UserCommissionSettingsPage(db:LocalDb,pad:PaddingValues,done:()->Unit){
    val products=db.products()
    val commissions=db.productCommissions()
    var selectedId by remember{mutableStateOf<Long?>(products.firstOrNull()?.id)}
    var amountText by remember{mutableStateOf("0")}
    var message by remember{mutableStateOf("")}
    LaunchedEffect(selectedId,commissions){amountText=fmt(commissions[selectedId]?:0.0)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp).verticalScroll(rememberScrollState())){
        Text("إعدادات مبيعات المستخدم",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("حدد عمولة ثابتة لكل قطعة من كل منتج. يتم حفظ قيمة العمولة مع الفاتورة وقت البيع.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(vertical=8.dp))
        if(products.isEmpty()) Text("لا توجد منتجات مسجلة",color=Color.Gray)
        else {
            Text("اختيار المنتج",fontWeight=FontWeight.Bold,color=Ink)
            products.forEach{p->
                Row(Modifier.fillMaxWidth().clickable{selectedId=p.id;amountText=fmt(commissions[p.id]?:0.0)}.padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=selectedId==p.id,onClick={selectedId=p.id;amountText=fmt(commissions[p.id]?:0.0)});Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.SemiBold,color=Ink);Text("العمولة الحالية: ${fmt(commissions[p.id]?:0.0)} ج.م / قطعة",fontSize=11.sp,color=Color.Gray)}}
                Divider()
            }
            OutlinedTextField(value=amountText,onValueChange={amountText=it},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp),label={Text("عمولة القطعة بالجنيه")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            Button(onClick={val id=selectedId;val amount=amountText.toDoubleOrNull();if(id!=null&&amount!=null&&amount>=0){db.setProductCommission(id,amount);message="تم حفظ العمولة";done()}else message="أدخل مبلغًا صحيحًا غير سالب"},modifier=Modifier.fillMaxWidth()){Text("حفظ العمولة")}
            if(message.isNotBlank())Text(message,color=Blue,modifier=Modifier.padding(top=8.dp))
        }
    }
}

@Composable private fun StockManagementMenu(pad:PaddingValues,open:(String)->Unit){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("إدارة المخزون",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink);RowCard("أصناف المخزون","إضافة صنف بالاسم والباركود والوحدة والكود"){open("أصناف المخزون")};RowCard("الريسبي","ربط منتج المبيعات بأصناف المخزون وكمياتها"){open("الريسبي")};RowCard("إذن صرف عهدة","تسجيل مستند إذن صرف عهدة"){open("إذن صرف عهدة")};RowCard("سجلات حركة المخزون","عرض وتعديل السجلات والرصيد بعد إغلاق فترة العمل فقط"){open("سجلات حركة المخزون")}}}


@Composable private fun ProductCatalog(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var query by remember{mutableStateOf("")}
    var selected by remember{mutableStateOf<Product?>(null)}
    var dialog by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    var name by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var barcode by remember{mutableStateOf("")};var category by remember{mutableStateOf("")}
    var cost by remember{mutableStateOf("0")};var price by remember{mutableStateOf("")};var qty by remember{mutableStateOf("0")}
    fun load(p:Product){selected=p;name=p.name;code=p.code;barcode=p.barcode;category=p.category;cost=p.cost.toString();price=p.price.toString();qty=p.qty.toString();error=""}
    val filtered=db.products().filter{it.name.contains(query,true)||it.code.contains(query,true)||it.barcode.contains(query,true)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("قائمة المنتجات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp),label={Text("بحث عن منتج بالاسم أو الكود أو الباركود")},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)})
        Button(onClick={selected=null;name="";code="";barcode="";category="";cost="0";price="";qty="0";error="";dialog="إضافة"},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("إضافة منتج") }
        Spacer(Modifier.height(8.dp))
        Text("المنتجات (${filtered.size})",fontWeight=FontWeight.Bold,color=Ink)
        LazyColumn(Modifier.weight(1f)){
            items(filtered,key={it.id}){p->
                Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.fillMaxWidth().padding(11.dp)){
                        Text(p.name,fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp)
                        Text("الكود: ${p.code.ifBlank{"—"}} | الباركود: ${p.barcode.ifBlank{"—"}}",fontSize=12.sp,color=Color.Gray)
                        Text("سعر البيع: ${fmt(p.price)} ج.م | الكمية: ${fmt(p.qty)}",fontSize=13.sp,color=Ink)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            TextButton(onClick={load(p);dialog="تعديل"},modifier=Modifier.weight(1f)){Icon(Icons.Default.Edit,null);Text("تعديل")}
                            TextButton(onClick={load(p);dialog="السعر"},modifier=Modifier.weight(1f)){Icon(Icons.Default.PriceChange,null);Text("تعديل السعر")}
                            TextButton(onClick={load(p);dialog="حذف"},modifier=Modifier.weight(1f)){Icon(Icons.Default.Delete,null,tint=MaterialTheme.colorScheme.error);Text("حذف",color=MaterialTheme.colorScheme.error)}
                        }
                    }
                }
            }
        }
    }
    if(dialog=="إضافة"||dialog=="تعديل") AlertDialog(
        onDismissRequest={dialog=""},title={Text(if(dialog=="إضافة")"إضافة منتج جديد" else "تعديل بيانات المنتج")},
        text={Column(Modifier.heightIn(max=430.dp)){
            Input("اسم المنتج *",name,{name=it});Input("كود المنتج",code,{code=it});Input("الباركود",barcode,{barcode=it});Input("التصنيف",category,{category=it})
            Input("سعر الشراء",cost,{cost=it},numeric=true)
            if(dialog=="إضافة") {Input("سعر البيع *",price,{price=it},numeric=true);Input("الكمية الافتتاحية",qty,{qty=it},numeric=true)}
            else Text("سعر البيع والكمية لا يتغيران من تعديل البيانات. استخدم زر تعديل السعر لتغيير سعر البيع.",fontSize=12.sp,color=Color.Gray)
            if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
        }},
        confirmButton={TextButton(onClick={
            val c=cost.toDoubleOrNull()?:0.0
            if(name.isBlank())error="اسم المنتج مطلوب"
            else if(c<0.0)error="أدخل تكلفة صحيحة"
            else if(dialog=="إضافة") {val selling=price.toDoubleOrNull();val q=qty.toDoubleOrNull();if(selling==null||selling<=0.0)error="السعر مطلوب، من فضلك أدخل سعر المنتج" else if(q==null||q<0.0)error="أدخل كمية صحيحة" else{db.addProduct(name.trim(),code.trim(),barcode.trim(),category.trim(),c,selling,q);dialog="";error="";done()}}
            else {db.updateProductDetails(selected!!.id,name.trim(),code.trim(),barcode.trim(),category.trim(),c);dialog="";error="";done()}
        }){Text("حفظ")}},dismissButton={TextButton(onClick={dialog="";error=""}){Text("إلغاء")}}
    )
    if(dialog=="السعر") AlertDialog(onDismissRequest={dialog=""},title={Text("تعديل سعر ${selected?.name.orEmpty()}")},text={Column{Input("سعر البيع الجديد *",price,{price=it},numeric=true);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val v=price.toDoubleOrNull();if(v==null||v<=0.0)error="السعر مطلوب ويجب أن يكون أكبر من صفر" else{db.updateProductPrice(selected!!.id,v);dialog="";error="";done()}}){Text("حفظ السعر")}},dismissButton={TextButton(onClick={dialog="";error=""}){Text("إلغاء")}})
    if(dialog=="حذف") AlertDialog(onDismissRequest={dialog=""},title={Text("تأكيد حذف المنتج")},text={Text("هل تريد حذف ${selected?.name.orEmpty()} نهائيًا من قائمة المنتجات؟ ستظل بياناته وأسعاره في الفواتير القديمة محفوظة.")},confirmButton={TextButton(onClick={db.deleteProduct(selected!!.id);dialog="";done()}){Text("حذف",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={dialog=""}){Text("إلغاء")}})
}

@Composable private fun ProductManagement(db:LocalDb,mode:String,pad:PaddingValues,done:()->Unit){
    var selected by remember{mutableStateOf<Product?>(null)}
    var showDeleteConfirm by remember{mutableStateOf(false)}
    var name by remember(selected){mutableStateOf(selected?.name?:"")}
    var code by remember(selected){mutableStateOf(selected?.code?:"")}
    var barcode by remember(selected){mutableStateOf(selected?.barcode?:"")}
    var category by remember(selected){mutableStateOf(selected?.category?:"")}
    var cost by remember(selected){mutableStateOf(selected?.cost?.toString()?:"0")}
    var price by remember(selected){mutableStateOf(selected?.price?.toString()?:"")}
    var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(mode,fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text(when(mode){"حذف المنتجات"->"اختر المنتج المراد حذفه";"تعديل المنتجات"->"اختر المنتج لتعديل بياناته";else->"اختر المنتج لتعديل سعر البيع"},color=Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyColumn{items(db.products(),key={it.id}){p->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{selected=p;if(mode=="حذف المنتجات")showDeleteConfirm=true},colors=CardDefaults.cardColors(containerColor=Color.White)){
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                    Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.SemiBold,color=Ink);Text("السعر: ${fmt(p.price)} ج.م  |  الكود: ${p.code}",fontSize=12.sp,color=Color.Gray)}
                    Text(when(mode){"حذف المنتجات"->"حذف";"تعديل المنتجات"->"تعديل";else->"السعر"},color=Blue,fontWeight=FontWeight.Bold)
                }
            }
        }}
    }
    if(mode=="تعديل المنتجات"&&selected!=null){
        AlertDialog(onDismissRequest={selected=null},title={Text("تعديل بيانات المنتج")},text={Column{Input("اسم المنتج",name,{name=it});Input("كود المنتج",code,{code=it});Input("الباركود",barcode,{barcode=it});Input("التصنيف",category,{category=it});Input("سعر الشراء",cost,{cost=it},numeric=true);Text("سعر البيع لا يتغير من هنا؛ استخدم تعديل الأسعار.",fontSize=12.sp,color=Color.Gray);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val c=cost.toDoubleOrNull();if(name.isBlank())error="اسم المنتج مطلوب" else if(c==null||c<0.0)error="أدخل تكلفة صحيحة" else{db.updateProductDetails(selected!!.id,name,code,barcode,category,c);selected=null;error="";done()}}){Text("حفظ")}},dismissButton={TextButton(onClick={selected=null}){Text("إلغاء")}})
    }
    if(mode=="تعديل الأسعار"&&selected!=null){
        AlertDialog(onDismissRequest={selected=null},title={Text("تعديل سعر ${selected!!.name}")},text={Column{Input("سعر البيع الجديد *",price,{price=it},numeric=true);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val v=price.toDoubleOrNull();if(v==null||v<=0.0)error="السعر مطلوب ويجب أن يكون أكبر من صفر" else{db.updateProductPrice(selected!!.id,v);selected=null;price="";error="";done()}}){Text("حفظ السعر")}},dismissButton={TextButton(onClick={selected=null;error=""}){Text("إلغاء")}})
    }
    if(mode=="حذف المنتجات"&&showDeleteConfirm&&selected!=null){
        AlertDialog(onDismissRequest={showDeleteConfirm=false;selected=null},title={Text("تأكيد حذف المنتج")},text={Text("هل تريد حذف ${selected!!.name}؟ ستظل تفاصيله وأسعاره المسجلة في الفواتير القديمة محفوظة.")},confirmButton={TextButton(onClick={db.deleteProduct(selected!!.id);showDeleteConfirm=false;selected=null;done()}){Text("حذف")}},dismissButton={TextButton(onClick={showDeleteConfirm=false;selected=null}){Text("إلغاء")}})
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun POS(db:LocalDb,pad:PaddingValues,initialLines:List<Pair<Product,Double>>,customer:Customer?,user:AppUser,done:()->Unit,newInvoice:()->Unit,openSettlement:(List<Pair<Product,Double>>)->Unit){
    val products=db.products();var cart by remember(initialLines){mutableStateOf(initialLines.associate{it.first.id to it.second})}
    var customPrices by remember(initialLines){mutableStateOf(emptyMap<Long,Double>())}
    var priceEditProduct by remember{mutableStateOf<Product?>(null)}
    var priceEditText by remember{mutableStateOf("")}
    var invoiceClock by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while(true) { invoiceClock=LocalDateTime.now(); delay(30_000) } }
    val invoiceDate=invoiceClock.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
    val invoiceTime=invoiceClock.format(DateTimeFormatter.ofPattern("hh:mm a", Locale("ar")))
    var paymentMethod by remember{mutableStateOf("نقدي")};var selectedCategory by remember{mutableStateOf("الكل")}
    var selectedProductId by remember{mutableStateOf<Long?>(null)}
    var saveError by remember{mutableStateOf("")};var saving by remember{mutableStateOf(false)}
    val categories=listOf("الكل")+products.map{it.category}.filter{it.isNotBlank()}.distinct()
    val visibleProducts=products.filter{selectedCategory=="الكل"||it.category==selectedCategory}
    val lines=products.filter{(cart[it.id]?:0.0)>0}.map{p->p.copy(price=customPrices[p.id]?:p.price) to (cart[p.id]?:0.0)}
    val total=lines.sumOf{it.first.price*it.second}
    @Composable fun ProductTiles(modifier:Modifier){
        Column(modifier){
            Text("الفئات",fontWeight=FontWeight.Bold,color=Ink)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
                categories.forEach{cat->
                    val isSelected=selectedCategory==cat
                    FilterChip(selected=isSelected,onClick={selectedCategory=cat;selectedProductId=null},label={Text(cat.ifBlank{"عام"},fontSize=12.sp,fontWeight=FontWeight.Bold)},colors=FilterChipDefaults.filterChipColors(containerColor=Color(0xFFFFE082),labelColor=Color(0xFF1B1B1B),selectedContainerColor=Color(0xFFFF9800),selectedLabelColor=Color(0xFF1B1B1B)),border=androidx.compose.foundation.BorderStroke(if(isSelected)2.dp else 1.dp,if(isSelected)Color(0xFFB66A00) else Color(0xFF9E9E9E)))
                }
            }
            Text("المنتجات",fontWeight=FontWeight.Bold,color=Ink,modifier=Modifier.padding(vertical=4.dp))
            LazyVerticalGrid(columns=GridCells.Adaptive(minSize=105.dp),modifier=Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                items(visibleProducts,key={it.id}){p->
                    val isSelected=selectedProductId==p.id
                    val tileBg=if(isSelected)Color(0xFF2E7D32) else Color(0xFFA5D6A7)
                    val tileText=if(isSelected)Color.White else Color(0xFF123B1C)
                    Card(Modifier.fillMaxWidth().height(82.dp).clickable{selectedProductId=p.id;cart=cart+(p.id to ((cart[p.id]?:0.0)+1))},colors=CardDefaults.cardColors(containerColor=tileBg,contentColor=tileText),border=androidx.compose.foundation.BorderStroke(if(isSelected)3.dp else 1.dp,if(isSelected)Color(0xFF145A25) else Color(0xFF2E7D32))){Column(Modifier.fillMaxSize().padding(6.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(p.name,fontWeight=FontWeight.ExtraBold,fontSize=13.sp,color=tileText,maxLines=2);Text("${fmt(p.price)} ج.م",fontWeight=FontWeight.Bold,fontSize=12.sp,color=if(isSelected)Color.White else Color(0xFF1B5E20))}}
                }
            }
        }
    }
    @Composable fun InvoicePanel(modifier:Modifier){
        Column(modifier){
            Text("الفاتورة",fontWeight=FontWeight.Bold,fontSize=20.sp,color=Ink)
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFE5F0FF)),border=androidx.compose.foundation.BorderStroke(1.dp,Blue.copy(alpha=.35f))){
                Row(Modifier.fillMaxWidth().padding(horizontal=9.dp, vertical=10.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                    Column(horizontalAlignment=Alignment.CenterHorizontally){Text("عدد الأصناف",fontSize=11.sp,color=Ink,fontWeight=FontWeight.Bold);Text(lines.size.toString(),fontSize=21.sp,color=Color(0xFF0B6E35),fontWeight=FontWeight.ExtraBold)}
                    Column(horizontalAlignment=Alignment.CenterHorizontally){Text("التاريخ",fontSize=11.sp,color=Ink,fontWeight=FontWeight.Bold);Text(invoiceDate,fontSize=13.sp,color=Ink,fontWeight=FontWeight.ExtraBold)}
                    Column(horizontalAlignment=Alignment.CenterHorizontally){Text("الوقت",fontSize=11.sp,color=Ink,fontWeight=FontWeight.Bold);Text(invoiceTime,fontSize=13.sp,color=Ink,fontWeight=FontWeight.ExtraBold)}
                }
            }
            Text("اسم العميل: ${customer?.name?:"عميل نقدي"}",fontWeight=FontWeight.SemiBold,color=Blue,modifier=Modifier.padding(vertical=5.dp))
            Row(Modifier.fillMaxWidth().background(Blue).padding(7.dp)){
                Text("الصنف",Modifier.weight(2f),color=Color.White,fontWeight=FontWeight.Bold);Text("الكمية",Modifier.weight(0.8f),color=Color.White,fontWeight=FontWeight.Bold);Text("السعر",Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.Bold);Text("الإجمالي",Modifier.weight(1.1f),color=Color.White,fontWeight=FontWeight.Bold)
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth()){
                items(lines,key={it.first.id}){(p,q)->Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(p.name,Modifier.weight(2f),fontSize=12.sp);Text(fmt(q),Modifier.weight(.8f),fontSize=12.sp);Text(fmt(p.price),Modifier.weight(1f),fontSize=12.sp);Text(fmt(p.price*q),Modifier.weight(1.1f),fontSize=12.sp,fontWeight=FontWeight.Bold)};Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){TextButton(onClick={val v=q-1;cart=if(v<=0)cart-p.id else cart+(p.id to v)}){Text("−")};TextButton(onClick={cart=cart+(p.id to q+1)}){Text("+")};TextButton(onClick={priceEditProduct=p;priceEditText=fmt(p.price)}){Text("تغيير السعر",fontSize=10.sp,color=Blue)};TextButton(onClick={cart=cart-p.id;customPrices=customPrices-p.id}){Text("حذف",color=Color.Red)}};Divider(color=Color.LightGray)}}
            }
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFE5F0FF)),modifier=Modifier.fillMaxWidth().padding(vertical=5.dp)){Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("إجمالي الفاتورة",fontWeight=FontWeight.Bold,color=Ink);Text("${fmt(total)} ج.م",fontWeight=FontWeight.Bold,fontSize=22.sp,color=Color(0xFF168A35))}}
            if(saveError.isNotBlank())Text(saveError,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
                Button(onClick={if(lines.isNotEmpty())openSettlement(lines)},modifier=Modifier.weight(1f),enabled=lines.isNotEmpty(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF159B36))){Text("تسوية",fontSize=11.sp)}
                Button(onClick={paymentMethod="نقدي"},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("نقدي",fontSize=11.sp)}
                Button(onClick={paymentMethod="إنستا باي"},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF7446B8))){Text("إنستا باي",fontSize=10.sp)}
                Button(onClick={if(!saving&&lines.isNotEmpty()){saving=true;saveError="";try{db.saveSale(lines,total,paymentMethod,customer?.id,user);cart=emptyMap();customPrices=emptyMap();newInvoice()}catch(e:Exception){saveError="تعذر حفظ الفاتورة: ${e.localizedMessage?:"حدث خطأ"}";saving=false}}},modifier=Modifier.weight(1.25f),enabled=lines.isNotEmpty()&&!saving,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFD92735))){Text(if(saving)"جارٍ الحفظ" else "حفظ الفاتورة",fontSize=10.sp)}
            }
            Text("طريقة الدفع المختارة: $paymentMethod",fontSize=11.sp,color=Color.Gray,modifier=Modifier.padding(top=3.dp))
        }
    }
    if(priceEditProduct!=null){
        AlertDialog(onDismissRequest={priceEditProduct=null},title={Text("تغيير سعر المنتج")},text={Column{Text("${priceEditProduct!!.name}");OutlinedTextField(value=priceEditText,onValueChange={priceEditText=it},label={Text("السعر الجديد")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))}},confirmButton={TextButton(onClick={val value=priceEditText.toDoubleOrNull();if(value!=null&&value>=0){customPrices=customPrices+(priceEditProduct!!.id to value);priceEditProduct=null}}){Text("حفظ")}},dismissButton={TextButton(onClick={priceEditProduct=null}){Text("إلغاء")}})
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(pad).padding(8.dp)){
        if(maxWidth>=700.dp){
            Row(Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                InvoicePanel(Modifier.weight(1.8f).fillMaxHeight())
                ProductTiles(Modifier.weight(1f).fillMaxHeight())
            }
        }else{
            Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(6.dp)){
                InvoicePanel(Modifier.weight(1.35f).fillMaxWidth())
                ProductTiles(Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

@Composable private fun SettlementScreen(db:LocalDb,lines:List<Pair<Product,Double>>,pad:PaddingValues,customerId:Long?,user:AppUser,onBack:()->Unit,onDone:()->Unit){
    val gross=lines.sumOf{it.first.price*it.second}
    var discountText by remember{mutableStateOf("0")}
    // Prefill the first payment method with the invoice total; the user can edit it
    // or split the amount across the other methods.
    var cashText by remember(gross){mutableStateOf(fmt(gross))}
    var bankText by remember{mutableStateOf("0")}
    var instaText by remember{mutableStateOf("0")}
    var customerAccountText by remember(gross){mutableStateOf("0")}
    var cashManuallyEdited by remember{mutableStateOf(false)}
    var saving by remember{mutableStateOf(false)}
    var saveError by remember{mutableStateOf("")}
    val discount=(discountText.toDoubleOrNull()?:0.0).coerceIn(0.0,100.0)
    val total=(gross-gross*discount/100.0).coerceAtLeast(0.0)
    val cash=cashText.toDoubleOrNull()?:0.0;val bank=bankText.toDoubleOrNull()?:0.0;val insta=instaText.toDoubleOrNull()?:0.0
    val customerAccount=customerAccountText.toDoubleOrNull()?:0.0
    val paid=cash+bank+insta
    val allocated=paid+customerAccount
    val remaining=(total-paid).coerceAtLeast(0.0)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("تسوية الحساب",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(12.dp)){
                Text("إجمالي الفاتورة: ${fmt(gross)} ج.م",fontWeight=FontWeight.Bold)
                Input("الخصم %",discountText,{value->
                    discountText=value
                    if(!cashManuallyEdited){
                        val discountValue=(value.toDoubleOrNull()?:0.0).coerceIn(0.0,100.0)
                        cashText=fmt((gross-gross*discountValue/100.0).coerceAtLeast(0.0))
                    }
                },numeric=true)
                Text("الإجمالي بعد الخصم: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold,color=Blue)
                Text("المدفوع: ${fmt(paid)} ج.م")
                Text("المتبقي على العميل: ${fmt(remaining)} ج.م",color=if(remaining<0)Color.Red else Ink,fontWeight=FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(8.dp));Text("طرق الدفع",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
            Input("نقدي",cashText,{cashText=it;cashManuallyEdited=true},Modifier.weight(1f),true)
            Input("إنستا باي",instaText,{instaText=it},Modifier.weight(1f),true)
        }
        Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
            Input("حساب العميل",customerAccountText,{customerAccountText=it},Modifier.weight(1f),true)
            Input("حساب بنكي",bankText,{bankText=it},Modifier.weight(1f),true)
        }
        Text("حساب العميل يسجل المبلغ الآجل في كشف حساب العميل ولا يُضاف إلى حركة المدفوعات. إجمالي الفاتورة مُدخل تلقائيًا في خانة النقدي ويمكن تقسيم المبلغ.",color=Color.Gray,fontSize=12.sp)
        Text("إجمالي المدفوع فعليًا: ${fmt(paid)} ج.م | المضاف لحساب العميل: ${fmt(customerAccount)} ج.م",color=Ink,fontWeight=FontWeight.SemiBold)
        Text("المتبقي غير المدفوع: ${fmt(remaining)} ج.م يُضاف لمستحقات العميل.",color=Color.Gray,fontSize=12.sp)
        Spacer(Modifier.height(8.dp))
        if(saveError.isNotBlank()) Text(saveError,color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        if(allocated>total+0.009) Text("إجمالي المبالغ الموزعة أكبر من إجمالي الفاتورة.",color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        if(remaining>0.009 && customerId==null) Text("اختر العميل أولاً لتسجيل المبلغ المتبقي على حسابه.",color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick=onBack,modifier=Modifier.weight(1f),enabled=!saving){Text("رجوع")}
            Button(
                onClick={
                    if(!saving && allocated<=total+0.009 && cash>=0 && bank>=0 && insta>=0 && customerAccount>=0 && lines.isNotEmpty() && (remaining<=0.009 || customerId!=null)){
                        saving=true
                        saveError=""
                        try {
                            db.saveSale(lines,mapOf("نقدي" to cash,"حساب بنكي" to bank,"إنستا باي" to insta,"حساب العميل" to customerAccount),discount,customerId,user)
                            onDone()
                        } catch (e:Exception) {
                            saveError="تعذر حفظ الفاتورة: ${e.localizedMessage ?: "حدث خطأ غير معروف"}"
                            saving=false
                        }
                    }
                },
                modifier=Modifier.weight(1f),
                enabled=!saving && allocated<=total+0.009 && cash>=0 && bank>=0 && insta>=0 && customerAccount>=0 && lines.isNotEmpty() && (remaining<=0.009 || customerId!=null)
            ){Text(if(saving)"جارٍ الحفظ..." else "حفظ الفاتورة وإغلاق")}
        }
    }
}

@Composable private fun Customers(db:LocalDb,pad:PaddingValues,onSale:(Customer)->Unit,onDetails:(Customer)->Unit,done:()->Unit){
    var query by remember{mutableStateOf("")};var showNew by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("حسابات العملاء",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("الفترة المحددة: ${db.accountPeriodLabel(db.accountPeriod("customers"))}",fontSize=12.sp,color=Color.Gray)
        Input("بحث عن عميل بالاسم أو الهاتف أو البيانات",query,{query=it})
        Button(onClick={showNew=true},Modifier.fillMaxWidth()){Text("+ عميل جديد")}
        Text("العملاء المسجلون",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
        val found=db.customers(query)
        if(found.isEmpty())Text(if(query.isBlank())"لا يوجد عملاء مسجلون" else "العميل غير مسجل، يمكنك إضافته من زر عميل جديد",color=Color.Gray,modifier=Modifier.padding(8.dp))
        LazyColumn{items(found,key={it.id}){c->RowCard(c.name,"${c.mobile} | ${c.governorate} | ${c.area} | ${c.shop}"){onDetails(c)}}}
    }
    if(showNew) CustomerFormDialog(null,db,onDismiss={showNew=false},onSave={n,m,g,a,shop->val id=db.addCustomer(n,m,g,a,shop);if(id>0){showNew=false;done()}})
}
@Composable private fun CustomerFormDialog(customer:Customer?,db:LocalDb,onDismiss:()->Unit,onSave:(String,String,String,String,String)->Unit){
    var n by remember(customer){mutableStateOf(customer?.name?:"")};var m by remember(customer){mutableStateOf(customer?.mobile?:"")};var g by remember(customer){mutableStateOf(customer?.governorate?:"")};var a by remember(customer){mutableStateOf(customer?.area?:"")};var shop by remember(customer){mutableStateOf(customer?.shop?:"")};var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(customer==null)"إضافة عميل جديد" else "تعديل بيانات العميل")},text={Column{Input("اسم العميل",n,{n=it});Input("رقم التليفون",m,{m=it},numeric=true);Input("المحافظة",g,{g=it});Input("اسم المنطقة",a,{a=it});Input("اسم المحل",shop,{shop=it});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={if(n.isBlank())error="اسم العميل مطلوب" else if(db.customerNameExists(n,customer?.id))error="هذا الاسم مسجل بالفعل، من فضلك أدخل اسمًا آخر أو ابحث عن العميل المسجل." else{onSave(n,m,g,a,shop)}}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun CustomerDetails(db:LocalDb,customer:Customer?,pad:PaddingValues,onSale:(Customer)->Unit,onEdit:()->Unit,onCollect:()->Unit){
    if(customer==null){Text("لم يتم تحديد عميل",modifier=Modifier.padding(pad));return}
    val totals=db.customerTotals(customer.id)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(customer.name,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("الهاتف: ${customer.mobile} | المحافظة: ${customer.governorate}",color=Color.Gray)
        Text("المنطقة: ${customer.area} | المحل: ${customer.shop}",color=Color.Gray)
        Card(Modifier.fillMaxWidth().padding(vertical=10.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text("إجمالي الفواتير: ${fmt(totals.first)} ج.م",fontWeight=FontWeight.Bold);Text("الرصيد المستحق: ${fmt(totals.second)} ج.م",fontWeight=FontWeight.Bold,color=Blue)}}
        Button(onClick={onSale(customer)},Modifier.fillMaxWidth()){Text("تحديد العميل وبدء فاتورة")}
        OutlinedButton(onClick=onCollect,Modifier.fillMaxWidth()){Text("تحصيل")}
        OutlinedButton(onClick=onEdit,Modifier.fillMaxWidth()){Text("تعديل عميل")}
        Text("تفاصيل الحساب والفواتير",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
        val invoices=db.customerInvoices(customer.id)
        if(invoices.isEmpty())Text("لا توجد فواتير مسجلة لهذا العميل",color=Color.Gray)
        LazyColumn{items(invoices){RowCard(it)}}
    }
}
@Composable private fun CustomerEditor(customer:Customer?,pad:PaddingValues,onSave:(Customer,String,String,String,String,String)->Unit,onCancel:()->Unit){
    if(customer==null)return
    var n by remember(customer){mutableStateOf(customer.name)};var m by remember(customer){mutableStateOf(customer.mobile)};var g by remember(customer){mutableStateOf(customer.governorate)};var a by remember(customer){mutableStateOf(customer.area)};var shop by remember(customer){mutableStateOf(customer.shop)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("تعديل بيانات العميل",fontWeight=FontWeight.Bold,fontSize=20.sp);Input("اسم العميل",n,{n=it});Input("رقم التليفون",m,{m=it},numeric=true);Input("المحافظة",g,{g=it});Input("اسم المنطقة",a,{a=it});Input("اسم المحل",shop,{shop=it});Button(onClick={if(n.isNotBlank())onSave(customer,n,m,g,a,shop)},Modifier.fillMaxWidth()){Text("حفظ التعديلات")};OutlinedButton(onClick=onCancel,Modifier.fillMaxWidth()){Text("إلغاء")}}
}
@Composable private fun Inventory(db:LocalDb,pad:PaddingValues,done:()->Unit){val rows=db.stockDashboard();Column(Modifier.fillMaxSize().padding(pad).padding(10.dp)){Text("المخزون",fontWeight=FontWeight.Bold,fontSize=20.sp);Text("عرض فقط",color=Color.Gray,fontSize=12.sp);ReportTableHeader(listOf("اسم الصنف","الوحدة","المباع","الوارد","الرصيد الحالي"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,it.unit,fmt(it.sold),fmt(it.incoming),fmt(it.current))) };item{ReportTableRow(listOf("الإجمالي","",fmt(rows.sumOf{it.sold}),fmt(rows.sumOf{it.incoming}),fmt(rows.sumOf{it.current})),true)}}}}
@Composable private fun StockCatalog(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var name by remember{mutableStateOf("")}
    var barcode by remember{mutableStateOf("")}
    var code by remember{mutableStateOf("")}
    var unit by remember{mutableStateOf("قطعة")}
    var minQty by remember{mutableStateOf("0")}
    var search by remember{mutableStateOf("")}
    var selected by remember{mutableStateOf<StockItem?>(null)}
    var dialog by remember{mutableStateOf(false)}
    val rows=db.stockItems().filter{it.name.contains(search,true)||it.code.contains(search,true)||it.barcode.contains(search,true)}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("أصناف المخزون",fontSize=20.sp,fontWeight=FontWeight.Bold)
        Input("بحث بالاسم أو الكود أو الباركود",search,{search=it})
        Button(onClick={selected=null;name="";barcode="";code="";unit="قطعة";minQty="0";dialog=true},Modifier.fillMaxWidth()){Text("إضافة صنف")}
        LazyColumn{
            items(rows){item->
                Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(10.dp)){
                        Text(item.name,fontWeight=FontWeight.Bold)
                        Text("الباركود ${item.barcode.ifBlank{"—"}} | الكود ${item.code.ifBlank{"—"}} | الوحدة ${item.unit} | الرصيد ${fmt(item.qty)}",fontSize=12.sp)
                        Row{
                            TextButton(onClick={selected=item;name=item.name;barcode=item.barcode;code=item.code;unit=item.unit;minQty=item.minQty.toString();dialog=true}){Text("تعديل")}
                            TextButton(onClick={db.deleteStockItem(item.id);done()}){Text("حذف",color=MaterialTheme.colorScheme.error)}
                        }
                    }
                }
            }
        }
    }
    if(dialog)AlertDialog(
        onDismissRequest={dialog=false},
        title={Text(if(selected==null)"إضافة صنف مخزون" else "تعديل صنف مخزون")},
        text={Column{
            Input("اسم الصنف",name,{name=it})
            Input("باركود الصنف",barcode,{barcode=it})
            Input("كود الصنف",code,{code=it})
            Input("الوحدة (قطعة / كرتونة...)",unit,{unit=it})
            Input("حد تنبيه انخفاض المخزون",minQty,{minQty=it},numeric=true)
        }},
        confirmButton={TextButton(onClick={
            val min=minQty.toDoubleOrNull()
            if(name.isNotBlank()&&unit.isNotBlank()&&min!=null&&min>=0){
                if(selected==null)db.addStock(name,barcode,code,unit,0.0,min) else db.updateStockItem(selected!!,name,barcode,code,unit,min)
                dialog=false;done()
            }
        }){Text("حفظ")}},
        dismissButton={TextButton(onClick={dialog=false}){Text("إلغاء")}}
    )
}

@Composable private fun RecipeManager(db:LocalDb,pad:PaddingValues,done:()->Unit){
    val products=db.products();val stocks=db.stockItems();var productId by remember{mutableStateOf(products.firstOrNull()?.id?.toString().orEmpty())};var stockId by remember{mutableStateOf(stocks.firstOrNull()?.id?.toString().orEmpty())};var qty by remember{mutableStateOf("1")};var unit by remember{mutableStateOf("قطعة")};var editing by remember{mutableStateOf<RecipeRow?>(null)};var deleteTarget by remember{mutableStateOf<RecipeRow?>(null)};var pExpanded by remember{mutableStateOf(false)};var sExpanded by remember{mutableStateOf(false)}
    val recipes=db.recipes()
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("الريسبي",fontSize=20.sp,fontWeight=FontWeight.Bold)
        Text("اختار منتج المبيعات وصنف المخزون والكمية التي تخصم عند بيع وحدة من المنتج",fontSize=12.sp,color=Color.Gray)
        if(products.isEmpty()||stocks.isEmpty())Text("أضف منتجات المبيعات وأصناف المخزون أولًا",color=MaterialTheme.colorScheme.error)
        else {
            Box { OutlinedButton(onClick={pExpanded=true},Modifier.fillMaxWidth()){Text(products.firstOrNull{it.id.toString()==productId}?.name?:"اختيار منتج المبيعات")};DropdownMenu(expanded=pExpanded,onDismissRequest={pExpanded=false}){products.forEach{DropdownMenuItem(text={Text(it.name)},onClick={productId=it.id.toString();pExpanded=false})}} }
            Box { OutlinedButton(onClick={sExpanded=true},Modifier.fillMaxWidth()){Text(stocks.firstOrNull{it.id.toString()==stockId}?.name?:"اختيار صنف المخزون")};DropdownMenu(expanded=sExpanded,onDismissRequest={sExpanded=false}){stocks.forEach{DropdownMenuItem(text={Text(it.name)},onClick={stockId=it.id.toString();sExpanded=false})}} }
            Input("الكمية المستهلكة لكل منتج",qty,{qty=it},numeric=true);Input("وحدة الخصم (قطعة / كرتونة)",unit,{unit=it})
            Button(onClick={val q=qty.toDoubleOrNull();if(q!=null&&q>0&&productId.isNotBlank()&&stockId.isNotBlank()){val e=editing;if(e==null)db.addRecipe(productId.toLong(),stockId.toLong(),q,unit) else db.updateRecipe(e.id,productId.toLong(),stockId.toLong(),q,unit);editing=null;qty="1";unit="قطعة";done()}},Modifier.fillMaxWidth()){Text(if(editing==null)"حفظ الريسبي" else "حفظ التعديل")}
            if(editing!=null)TextButton(onClick={editing=null;qty="1";unit="قطعة"}){Text("إلغاء التعديل")}
        }
        Text("الربط الحالي",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
        LazyColumn { items(recipes,key={it.id}){r->Card(Modifier.fillMaxWidth().padding(vertical=4.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(10.dp)){Text("${r.productName} ← ${r.stockName}",fontWeight=FontWeight.SemiBold);Text("${fmt(r.quantity)} ${r.unit} لكل وحدة مباعة",fontSize=12.sp,color=Color.Gray);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={editing=r;productId=r.productId.toString();stockId=r.stockId.toString();qty=r.quantity.toString();unit=r.unit}){Text("تعديل")};TextButton(onClick={deleteTarget=r}){Text("حذف",color=MaterialTheme.colorScheme.error)}}}}} }
    }
    if(deleteTarget!=null)AlertDialog(onDismissRequest={deleteTarget=null},title={Text("تأكيد حذف الريسبي")},text={Text("هل تريد حذف ربط ${deleteTarget!!.productName} مع ${deleteTarget!!.stockName}؟")},confirmButton={TextButton(onClick={db.deleteRecipe(deleteTarget!!.id);deleteTarget=null;done()}){Text("حذف",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={deleteTarget=null}){Text("إلغاء")}})
}

@Composable private fun StockAddInvoicePage(db:LocalDb,pad:PaddingValues,done:()->Unit){
    val stocks=db.stockItems()
    var selectedId by remember{mutableStateOf(stocks.firstOrNull()?.id?.toString().orEmpty())}
    var qty by remember{mutableStateOf("1")};var note by remember{mutableStateOf("")}
    var lines by remember{mutableStateOf<List<Pair<Long,Double>>>(emptyList())}
    var expanded by remember{mutableStateOf(false)};var message by remember{mutableStateOf("")}
    var selectedDoc by remember{mutableStateOf<StockDocumentRow?>(null)}
    var docLines by remember{mutableStateOf<List<StockDocumentLine>>(emptyList())}
    var editLine by remember{mutableStateOf<StockDocumentLine?>(null)};var editQty by remember{mutableStateOf("")}
    var confirmDelete by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
        Text("إذن صرف عهدة",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        if(stocks.isEmpty()) Text("أضف أصناف المخزون أولًا",color=MaterialTheme.colorScheme.error)
        else {
            Box { OutlinedButton(onClick={expanded=true},Modifier.fillMaxWidth()){Text(stocks.firstOrNull{it.id.toString()==selectedId}?.name?:"اختيار الصنف")};DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){stocks.forEach{it->DropdownMenuItem(text={Text("${it.name} (${it.unit}) — الرصيد ${fmt(it.qty)}")},onClick={selectedId=it.id.toString();expanded=false})}} }
            Input("الكمية المضافة",qty,{qty=it},numeric=true)
            Button(onClick={val q=qty.toDoubleOrNull();if(q!=null&&q>0&&selectedId.isNotBlank()){lines=lines+(selectedId.toLong() to q);qty="1";message=""}},Modifier.fillMaxWidth()){Text("إضافة الصنف للمستند")}
            Input("ملاحظات المستند",note,{note=it})
            Text("أصناف المستند (${lines.size})",fontWeight=FontWeight.Bold)
            LazyColumn(Modifier.weight(1f)){items(lines){line->val item=stocks.firstOrNull{it.id==line.first};RowCard(item?.name?:"صنف","الكمية: ${fmt(line.second)} ${item?.unit.orEmpty()}")}}
            if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
            Button(onClick={if(db.addStockPurchase(lines,note)){lines=emptyList();note="";message="";done()}else message="تعذر حفظ المستند. راجع الأصناف والكميات."},Modifier.fillMaxWidth(),enabled=lines.isNotEmpty()){Text("حفظ المستند")}
        }
        Text("المستندات",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
        Row(Modifier.fillMaxWidth().background(Color(0xFFE8F1FB)).padding(8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("رقم المستند",fontWeight=FontWeight.Bold);Text("التاريخ",fontWeight=FontWeight.Bold);Text("الأصناف",fontWeight=FontWeight.Bold)}
        LazyColumn(Modifier.weight(1f,false)) { items(db.stockDocuments(),key={it.id}){doc->
            Card(Modifier.fillMaxWidth().padding(vertical=3.dp).clickable{selectedDoc=doc;docLines=db.stockDocumentLines(doc.id)},colors=CardDefaults.cardColors(containerColor=Color.White)){
                Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text("#${doc.id}");Text(doc.createdAt.take(16));Text(doc.itemCount.toString());TextButton(onClick={selectedDoc=doc;docLines=db.stockDocumentLines(doc.id)}){Text("عرض المستندات")}}
            }
        }}
    }
    if(selectedDoc!=null) AlertDialog(onDismissRequest={selectedDoc=null},title={Text("مستند إذن صرف #${selectedDoc!!.id}")},text={Column(Modifier.heightIn(max=360.dp).verticalScroll(rememberScrollState())){
        Text("التاريخ: ${selectedDoc!!.createdAt}");if(selectedDoc!!.note.isNotBlank())Text("ملاحظات: ${selectedDoc!!.note}")
        Text("الأصناف",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
        docLines.forEach{line->Row(Modifier.fillMaxWidth().padding(vertical=4.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("${line.name} (${line.unit}) — ${fmt(line.quantity)}");TextButton(onClick={editLine=line;editQty=line.quantity.toString()}){Text("تعديل")}}}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={confirmDelete=true}){Text("حذف",color=MaterialTheme.colorScheme.error)}}
    }},confirmButton={TextButton(onClick={selectedDoc=null}){Text("إغلاق")}},dismissButton={TextButton(onClick={selectedDoc=null}){Text("إغلاق")}})
    if(editLine!=null) AlertDialog(onDismissRequest={editLine=null},title={Text("تعديل كمية ${editLine!!.name}")},text={Input("الكمية الجديدة",editQty,{editQty=it},numeric=true)},confirmButton={TextButton(onClick={val q=editQty.toDoubleOrNull();val doc=selectedDoc;val line=editLine;if(q!=null&&doc!=null&&line!=null&&db.updateStockDocumentLine(doc.id,line.stockItemId,q)){docLines=db.stockDocumentLines(doc.id);selectedDoc=db.stockDocuments().firstOrNull{it.id==doc.id};editLine=null;done()}}){Text("حفظ")}},dismissButton={TextButton(onClick={editLine=null}){Text("إلغاء")}})
    if(confirmDelete&&selectedDoc!=null) AlertDialog(onDismissRequest={confirmDelete=false},title={Text("حذف المستند")},text={Text("هل تريد حذف المستند رقم ${selectedDoc!!.id}؟ سيتم عكس الكميات من رصيد المخزون.")},confirmButton={TextButton(onClick={if(db.deleteStockDocument(selectedDoc!!.id)){confirmDelete=false;selectedDoc=null;done()}else{message="لا يمكن الحذف لأن الكميات لم تعد متاحة بالكامل بالمخزون";confirmDelete=false}}){Text("حذف",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("إلغاء")}})
}

@Composable private fun StockLedgerPage(db:LocalDb,pad:PaddingValues,done:()->Unit){var selected by remember{mutableStateOf<StockMovement?>(null)};var newQty by remember{mutableStateOf("")};var reason by remember{mutableStateOf("")};val locked=!db.canEditStock();val rows=db.stockLedger();Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("سجلات حركة المخزون",fontSize=20.sp,fontWeight=FontWeight.Bold);Text(if(locked)"التعديل متاح فقط بعد إغلاق فترة العمل" else "يمكن تعديل السجلات والرصيد بعد إغلاق فترة العمل",color=if(locked)MaterialTheme.colorScheme.error else Color.Gray,fontSize=12.sp);if(!locked){Text("تعديل الرصيد الحالي",fontWeight=FontWeight.Bold);db.stockItems().forEach{item->RowCard(item.name,"الرصيد الحالي: ${fmt(item.qty)}"){selected=StockMovement(-item.id,item.id,item.name,"تسوية رصيد",0.0,item.qty,item.qty,"تعديل رصيد يدوي","");newQty=item.qty.toString();reason="تسوية رصيد يدوي"}}};LazyColumn{items(rows){m->Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(9.dp)){Text("${m.stockName} — ${m.type}",fontWeight=FontWeight.Bold);Text("${m.createdAt} | كمية ${fmt(m.quantity)} | قبل ${fmt(m.before)} | بعد ${fmt(m.after)}",fontSize=11.sp);Text(m.reason,fontSize=11.sp,color=Color.Gray);if(!locked)TextButton(onClick={selected=m;newQty=m.after.toString();reason=m.reason}){Text("تعديل السجل")}}}}};if(selected!=null)AlertDialog(onDismissRequest={selected=null},title={Text("تعديل رصيد ${selected!!.stockName}")},text={Column{Input("الرصيد الجديد بعد الحركة",newQty,{newQty=it},numeric=true);Input("سبب التعديل",reason,{reason=it})}},confirmButton={TextButton(onClick={val q=newQty.toDoubleOrNull();if(q!=null&&q>=0){val m=selected!!;val ok=if(m.id<0)db.adjustStock(m.stockItemId,q,reason) else db.editStockMovement(m,q,reason);if(ok){selected=null;done()}}}){Text("حفظ")}},dismissButton={TextButton(onClick={selected=null}){Text("إلغاء")}})} }

@Composable private fun ReportsMenu(db:LocalDb,pad:PaddingValues,open:(String)->Unit){
    val reports=configurableReports.filter{db.isReportVisible(it)}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Text("التقارير",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Spacer(Modifier.height(10.dp))
        if(reports.isEmpty()) Text("لا توجد تقارير ظاهرة حاليًا. يمكنك إظهار التقارير من إدارة البرنامج ← إعدادات التقارير.",color=Color.Gray,modifier=Modifier.padding(12.dp))
        else reports.forEachIndexed{index,name->Card(Modifier.fillMaxWidth().padding(vertical=5.dp).clickable{open(name)},colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("${index+1}.",fontWeight=FontWeight.Bold,color=Blue);Spacer(Modifier.width(10.dp));Text(name,fontWeight=FontWeight.SemiBold,color=Ink);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronLeft,"فتح",tint=Blue)}}}
    }
}

@Composable private fun UserCommissionReportPage(db:LocalDb,user:AppUser,pad:PaddingValues){
    var filter by rememberSaveable{mutableStateOf("اليوم")}
    val rows=db.userCommissionReport(user,filter)
    val total=rows.sumOf{it.total}
    val totalQty=rows.sumOf{it.quantity}
    val productTotals=rows.groupBy{it.productName to it.perUnit}.map{(key,items)->SalesProductRow(key.first,items.sumOf{it.quantity},items.sumOf{it.total}) to key.second}
    val exportRows=rows.map{listOf(it.invoiceId.toString(),it.createdAt,it.productName,fmt(it.quantity),fmt(it.perUnit),fmt(it.total))}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تقرير عمولات المستخدمين",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("المستخدم: ${user.username} — يتم التعرف عليه تلقائيًا من جلسة الدخول",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=3.dp))
        ReportPeriodFilter(filter){filter=it}
        ReportMetric("إجمالي العمولة", "${fmt(total)} ج.م")
        ReportMetric("عدد القطع المحتسبة",fmt(totalQty))
        SaveReportButton("تقرير عمولات المستخدمين",listOf("المستخدم: ${user.username}","الفترة: $filter","إجمالي القطع: ${fmt(totalQty)}","إجمالي العمولة: ${fmt(total)} ج.م"),listOf("رقم الفاتورة","التاريخ","المنتج","الكمية","عمولة القطعة","إجمالي العمولة"),exportRows)
        ReportGeneratedAt()
        if(rows.isEmpty()) Text("لا توجد عمولات مسجلة للمستخدم خلال الفترة المحددة",color=Color.Gray,modifier=Modifier.padding(12.dp))
        else {
            Text("ملخص العمولة حسب المنتج",fontWeight=FontWeight.Bold,color=Ink,modifier=Modifier.padding(top=6.dp))
            ReportTableHeader(listOf("المنتج","الكمية","عمولة القطعة","إجمالي العمولة"))
            productTotals.forEach{(item,perUnit)->ReportTableRow(listOf(item.name,fmt(item.quantity),fmt(perUnit),fmt(item.total)))}
            ReportTableRow(listOf("إجمالي كل المنتجات",fmt(totalQty),"",fmt(total)),true)
            Text("تفاصيل الفواتير",fontWeight=FontWeight.Bold,color=Ink,modifier=Modifier.padding(top=12.dp))
            ReportTableHeader(listOf("الفاتورة","التاريخ","المنتج","الكمية","عمولة القطعة","الإجمالي"))
            LazyColumn(Modifier.weight(1f)){
                items(rows){r->ReportTableRow(listOf("#${r.invoiceId}",r.createdAt,r.productName,fmt(r.quantity),fmt(r.perUnit),fmt(r.total)))}
            }
        }
    }
}

@Composable private fun ReportMetric(label:String,value:String){Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(label,color=Color.Gray);Text(value,fontWeight=FontWeight.Bold,color=Ink)}}}
private data class ReportPdfTable(val summary:List<String>,val headers:List<String>,val rows:List<List<String>>) 

private fun saveReportPdf(context:Context, treeUri:Uri, title:String, table:ReportPdfTable) {
    var pdf:PdfDocument?=null
    var created:DocumentFile?=null
    try {
        val root=DocumentFile.fromTreeUri(context,treeUri) ?: error("مجلد الحفظ غير متاح")
        if(!root.canWrite()) error("لا توجد صلاحية للكتابة في المجلد المختار")
        pdf=PdfDocument()
        val landscape=table.headers.size>=6
        val pageWidth=if(landscape)842 else 595
        val pageHeight=if(landscape)595 else 842
        val margin=32f
        val contentWidth=pageWidth-2*margin
        val titlePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.rgb(22,91,153);textSize=20f;textAlign=Paint.Align.RIGHT;typeface=Typeface.create("sans-serif",Typeface.BOLD)}
        val metaPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.DKGRAY;textSize=10f;textAlign=Paint.Align.RIGHT;typeface=Typeface.create("sans-serif",Typeface.NORMAL)}
        val borderPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.rgb(190,202,215);style=Paint.Style.STROKE;strokeWidth=0.8f}
        val headerFill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.rgb(22,91,153);style=Paint.Style.FILL}
        val normalFill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.WHITE;style=Paint.Style.FILL}
        val totalFill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.rgb(230,240,250);style=Paint.Style.FILL}
        val dateText="تاريخ ووقت التقرير: "+LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy  HH:mm"))
        val columnCount=maxOf(1,table.headers.size)
        val colWidth=contentWidth/columnCount
        var pageNo=0
        var canvas:android.graphics.Canvas?=null
        var currentPage:PdfDocument.Page?=null
        var y=0f
        fun beginPage(){
            pageNo++
            val info=PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create()
            val page=pdf!!.startPage(info); currentPage=page; canvas=page.canvas
            canvas!!.drawText(title,pageWidth-margin,38f,titlePaint)
            canvas!!.drawText(dateText,pageWidth-margin,57f,metaPaint)
            y=75f
        }
        fun finishPage(){
            canvas?.drawText("صفحة $pageNo",pageWidth-margin,pageHeight-16f,metaPaint)
            currentPage?.let{pdf!!.finishPage(it)}
            currentPage=null; canvas=null
        }
        fun makeLayout(value:String, width:Int, size:Float, bold:Boolean):StaticLayout{
            val tp=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{color=AndroidColor.rgb(35,45,58);textSize=size;typeface=Typeface.create("sans-serif",if(bold)Typeface.BOLD else Typeface.NORMAL)}
            return StaticLayout.Builder.obtain(value.ifBlank{" "},0,value.ifBlank{" "}.length,tp,width.coerceAtLeast(24)).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setIncludePad(true).setLineSpacing(1f,1f).build()
        }
        fun drawTableRow(values:List<String>, header:Boolean=false, total:Boolean=false){
            val layouts=List(columnCount){i->makeLayout(values.getOrNull(i).orEmpty(),(colWidth-12f).toInt(),if(header)10f else 9.5f,header||total)}
            val rowHeight=maxOf(30f,(layouts.maxOfOrNull{it.height}?:16)+12f)
            if(y+rowHeight>pageHeight-34f){finishPage();beginPage(); if(table.headers.isNotEmpty()&&!header) drawTableRow(table.headers,header=true)}
            for(i in 0 until columnCount){
                val left=margin+i*colWidth
                val rect=android.graphics.RectF(left,y,left+colWidth,y+rowHeight)
                canvas!!.drawRect(rect,if(header)headerFill else if(total)totalFill else normalFill)
                canvas!!.drawRect(rect,borderPaint)
                val layout=layouts[i]
                canvas!!.save();canvas!!.translate(left+6f,y+(rowHeight-layout.height)/2f);layout.draw(canvas);canvas!!.restore()
            }
            y+=rowHeight
        }
        beginPage()
        // Summary is rendered as two-column cards; StaticLayout keeps Arabic shaping and wrapping correct.
        table.summary.chunked(2).forEachIndexed{rowIndex,pair->
            val half=contentWidth/2f
            val layouts=pair.map{makeLayout(it,(half-14f).toInt(),9.5f,true)}
            val rowHeight=maxOf(32f,(layouts.maxOfOrNull{it.height}?:16)+12f)
            if(y+rowHeight>pageHeight-34f){finishPage();beginPage()}
            pair.forEachIndexed{cellIndex,_ ->
                val x=margin+cellIndex*half
                val rect=android.graphics.RectF(x,y,x+half,y+rowHeight)
                canvas!!.drawRoundRect(rect,4f,4f,if((rowIndex+cellIndex)%2==0)totalFill else normalFill)
                canvas!!.drawRoundRect(rect,4f,4f,borderPaint)
                canvas!!.save();canvas!!.translate(x+7f,y+(rowHeight-layouts[cellIndex].height)/2f);layouts[cellIndex].draw(canvas);canvas!!.restore()
            }
            if(pair.size==1){val x=margin+half;val rect=android.graphics.RectF(x,y,x+half,y+rowHeight);canvas!!.drawRoundRect(rect,4f,4f,normalFill);canvas!!.drawRoundRect(rect,4f,4f,borderPaint)}
            y+=rowHeight+5f
        }
        if(table.headers.isNotEmpty()){
            if(y+32f>pageHeight-34f){finishPage();beginPage()}
            drawTableRow(table.headers,header=true)
            table.rows.forEachIndexed{index,row->drawTableRow(row,total=row.firstOrNull()?.contains("الإجمالي")==true || row.firstOrNull()?.contains("المجموع")==true)}
        }
        finishPage()
        val safe=title.replace(Regex("[^\\u0600-\\u06FFa-zA-Z0-9 _-]"),"").replace(" ","_")
        val filename="${safe}_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))}.pdf"
        created=root.createFile("application/pdf",filename) ?: error("تعذر إنشاء ملف التقرير داخل المجلد المختار")
        context.contentResolver.openOutputStream(created.uri,"w")?.use{out->pdf.writeTo(out)} ?: error("تعذر فتح ملف التقرير للكتابة")
        Toast.makeText(context,"تم حفظ التقرير داخل المجلد الذي اخترته",Toast.LENGTH_LONG).show()
    } catch(e:Exception){
        created?.let{runCatching{it.delete()}}
        Toast.makeText(context,"تعذر حفظ التقرير: ${e.localizedMessage ?: "خطأ غير معروف"}",Toast.LENGTH_LONG).show()
    } finally { runCatching{pdf?.close()} }
}

@Composable private fun SaveReportButton(title:String, summary:List<String>, headers:List<String>, rows:List<List<String>>){
    val context=androidx.compose.ui.platform.LocalContext.current
    val prefs=remember{context.getSharedPreferences("qmax_reports",Context.MODE_PRIVATE)}
    val selectedFolder=remember{mutableStateOf(prefs.getString("tree_uri",null)?.let{runCatching{Uri.parse(it)}.getOrNull()})}
    val table=remember(title,summary,headers,rows){ReportPdfTable(summary,headers,rows)}
    Button(onClick={
        val uri=selectedFolder.value
        val hasPermission=uri!=null && context.contentResolver.persistedUriPermissions.any{it.uri==uri && it.isWritePermission}
        if(uri==null || !hasPermission) Toast.makeText(context,"حدد مجلد حفظ التقارير من إدارة البرنامج ← إعدادات التقارير",Toast.LENGTH_LONG).show()
        else saveReportPdf(context,uri,title,table)
    },modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)){Text("حفظ التقرير PDF",fontWeight=FontWeight.Bold)}
}
@Composable private fun ReportGeneratedAt(){val stamp=remember{LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy  HH:mm"))};Text("تاريخ ووقت التقرير: $stamp",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=3.dp,bottom=8.dp))}
@Composable private fun PeriodReportPage(db:LocalDb,pad:PaddingValues){
    var filter by rememberSaveable{mutableStateOf("الكل")}
    val r=db.periodReport(filter)
    val itemTotal=r.items.sumOf{it.total}
    val discountPercent=if(itemTotal>0.0) r.discount*100.0/itemTotal else 0.0
    LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=12.dp),contentPadding=PaddingValues(top=12.dp,bottom=24.dp)) {
        item {
            Text("تقرير فترة العمل",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
            ReportPeriodFilter(filter){filter=it}
            SaveReportButton("تقرير فترة العمل",listOf("الفترة: $filter","إجمالي المبيعات: ${fmt(r.sales)} ج.م","إجمالي الخصومات: ${fmt(r.discount)} ج.م","نسبة الخصم: ${fmt(discountPercent)}%","عدد الفواتير: ${r.invoices}")+r.payments.map{"${it.key}: ${fmt(it.value)} ج.م"}+listOf("إجمالي المدفوعات: ${fmt(r.payments.values.sum())} ج.م","المتبقي على حساب العملاء: ${fmt(r.due)} ج.م"),listOf("الصنف","الكمية","النسبة","الإجمالي"),r.items.map{item->listOf(item.name,fmt(item.quantity),"${fmt(if(itemTotal>0)item.total*100/itemTotal else 0.0)}%","${fmt(item.total)} ج.م")}+listOf(listOf("الإجمالي",fmt(r.items.sumOf{it.quantity}),"${if(itemTotal>0)"100" else "0"}%","${fmt(itemTotal)} ج.م")))
            ReportGeneratedAt();ReportMetric("إجمالي المبيعات","${fmt(r.sales)} ج.م");ReportMetric("إجمالي الخصومات","${fmt(r.discount)} ج.م");ReportMetric("نسبة الخصم","${fmt(discountPercent)}%");ReportMetric("عدد الفواتير",r.invoices.toString());Text("المدفوعات الفعلية",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp))
        }
        items(r.payments.entries.toList()){entry->ReportMetric(entry.key,"${fmt(entry.value)} ج.م")}
        item {ReportMetric("إجمالي المدفوعات","${fmt(r.payments.values.sum())} ج.م");ReportMetric("المتبقي على حساب العملاء","${fmt(r.due)} ج.م");Text("مبيعات الأصناف",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp));ReportTableHeader(listOf("الصنف","الكمية","النسبة","الإجمالي"))}
        items(r.items){item->val percent=if(itemTotal>0)item.total*100/itemTotal else 0.0;ReportTableRow(listOf(item.name,fmt(item.quantity),"${fmt(percent)}%","${fmt(item.total)} ج.م"))}
        item {ReportTableRow(listOf("الإجمالي",fmt(r.items.sumOf{it.quantity}),"${if(itemTotal>0)"100" else "0"}%","${fmt(itemTotal)} ج.م"),true)}
    }
}
@Composable private fun ProductSalesReportPage(db:LocalDb,pad:PaddingValues){
    var filter by rememberSaveable{mutableStateOf("الكل")};val rows=db.allProductSales(filter);val qty=rows.sumOf{it.quantity};val total=rows.sumOf{it.total}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تقرير مبيعات المنتجات",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);ReportPeriodFilter(filter){filter=it};SaveReportButton("تقرير مبيعات المنتجات",listOf("الفترة: $filter","إجمالي عدد المنتجات المباعة: ${fmt(qty)}","إجمالي قيمة المبيعات: ${fmt(total)} ج.م"),listOf("المنتج","الكمية المباعة","إجمالي البيع"),rows.map{listOf(it.name,fmt(it.quantity),"${fmt(it.total)} ج.م")}+listOf(listOf("الإجمالي",fmt(qty),"${fmt(total)} ج.م")));ReportGeneratedAt();ReportMetric("إجمالي عدد المنتجات المباعة",fmt(qty));ReportMetric("إجمالي قيمة المبيعات","${fmt(total)} ج.م");ReportTableHeader(listOf("المنتج","الكمية المباعة","إجمالي البيع"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,fmt(it.quantity),"${fmt(it.total)} ج.م"))};item{ReportTableRow(listOf("الإجمالي",fmt(qty),"${fmt(total)} ج.م"),true)}}}
}
@Composable private fun InventoryReportPage(db:LocalDb,pad:PaddingValues){var filter by rememberSaveable{mutableStateOf("الكل")};val rows=db.inventoryReport(filter);Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تقرير الجرد",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);ReportPeriodFilter(filter){filter=it};Text("يعرض رصيد المخزون وحركته كما كانت عند نهاية الفترة المختارة.",fontSize=11.sp,color=Color.Gray);SaveReportButton("تقرير الجرد",listOf("الفترة: $filter","إجمالي الرصيد في نهاية الفترة: ${fmt(rows.sumOf{it.quantity})}"),listOf("الصنف","الوحدة","افتتاحي","وارد","مبيع","ختامي"),rows.map{listOf(it.name,it.unit,fmt(it.opening),fmt(it.incoming),fmt(it.sold),fmt(it.quantity))}+listOf(listOf("الإجمالي","",fmt(rows.sumOf{it.opening}),fmt(rows.sumOf{it.incoming}),fmt(rows.sumOf{it.sold}),fmt(rows.sumOf{it.quantity}))));ReportGeneratedAt();Text("رصيد المخزون وحركة الوارد والمبيع خلال الفترة المختارة",color=Color.Gray,fontSize=12.sp);ReportTableHeader(listOf("الصنف","الوحدة","افتتاحي","وارد","مبيع","ختامي"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,it.unit,fmt(it.opening),fmt(it.incoming),fmt(it.sold),fmt(it.quantity)))};item{ReportTableRow(listOf("الإجمالي","",fmt(rows.sumOf{it.opening}),fmt(rows.sumOf{it.incoming}),fmt(rows.sumOf{it.sold}),fmt(rows.sumOf{it.quantity})),true)}}}}
@Composable private fun StockIssueReportPage(db:LocalDb,pad:PaddingValues){
    var filter by rememberSaveable{mutableStateOf("الكل")}
    val docs=db.stockDocuments(filter);val rows=docs.flatMap{doc->db.stockDocumentLines(doc.id).map{line->listOf("#${doc.id}",doc.createdAt,line.name,line.unit,fmt(line.quantity))}}
    val total=rows.sumOf{it[4].toDoubleOrNull()?:0.0}
    val summary=listOf("عدد المستندات: ${docs.size}","عدد بنود الأصناف: ${rows.size}","إجمالي الكميات المسجلة: ${fmt(total)}")
    val headers=listOf("رقم المستند","التاريخ","الصنف","الوحدة","الكمية")
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
        Text("تقرير أذون صرف عهدة",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        ReportPeriodFilter(filter){filter=it}
        SaveReportButton("تقرير أذون صرف عهدة",listOf("الفترة: $filter")+summary,headers,rows)
        ReportGeneratedAt();ReportMetric("عدد المستندات",docs.size.toString());ReportMetric("عدد بنود الأصناف",rows.size.toString());ReportMetric("إجمالي الكميات",fmt(total))
        if(rows.isEmpty()) Text("لا توجد مستندات مسجلة حتى الآن",color=Color.Gray,modifier=Modifier.padding(12.dp))
        else {ReportTableHeader(headers);LazyColumn{items(rows){ReportTableRow(it)}}}
    }
}
@Composable private fun StockAlertsReportPage(db:LocalDb,pad:PaddingValues){var filter by rememberSaveable{mutableStateOf("الكل")};val rows=db.stockAlerts(filter);Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){Text("تنبيهات المخزون",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink);ReportPeriodFilter(filter){filter=it};Text("تعرض حالة الأرصدة عند نهاية الفترة المختارة.",fontSize=11.sp,color=Color.Gray);SaveReportButton("تنبيهات المخزون",listOf("الفترة: $filter","عدد الأصناف النافدة أو المنخفضة: ${rows.size}"),listOf("الصنف","النوع","الرصيد","الحالة"),rows.map{listOf(it.name,it.source,fmt(it.quantity),if(it.quantity<=0.0)"نافد" else "منخفض")});ReportGeneratedAt();ReportMetric("الأصناف النافدة",rows.size.toString());Text("الأصناف النافدة",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=10.dp));if(rows.isEmpty())Text("لا توجد أصناف منخفضة أو نافدة",color=Color.Gray,modifier=Modifier.padding(10.dp)) else {ReportTableHeader(listOf("الصنف","النوع","الرصيد","الحالة"));LazyColumn{items(rows){ReportTableRow(listOf(it.name,it.source,fmt(it.quantity),if(it.quantity<=0.0)"نافد" else "منخفض"))}}};Text("يظهر الصنف منخفضًا عند بلوغ حد التنبيه الذي يتم ضبطه للصنف، والنافد عند وصول الرصيد إلى صفر.",color=Color.Gray,fontSize=12.sp,modifier=Modifier.padding(top=12.dp))}}
@Composable private fun ReportTableHeader(cells:List<String>){Row(Modifier.fillMaxWidth().padding(top=8.dp,bottom=4.dp)){cells.forEach{Text(it,Modifier.weight(1f),fontSize=11.sp,fontWeight=FontWeight.Bold,color=Blue)}}}
@Composable private fun ReportTableRow(cells:List<String>,total:Boolean=false){Card(Modifier.fillMaxWidth().padding(vertical=2.dp),colors=CardDefaults.cardColors(containerColor=if(total)Color(0xFFE8F1FB) else Color.White)){Row(Modifier.fillMaxWidth().padding(9.dp),verticalAlignment=Alignment.CenterVertically){cells.forEach{Text(it,Modifier.weight(1f),fontSize=11.sp,fontWeight=if(total)FontWeight.Bold else FontWeight.Normal,color=Ink)}}}}
@Composable private fun BackupPage(db:LocalDb,pad:PaddingValues,onChooseFolder:()->Unit,onBackup:()->Boolean,onRestore:()->Unit){
    var message by remember{mutableStateOf("")};var confirmRestore by remember{mutableStateOf(false)};var confirmClear by remember{mutableStateOf(false)}
    val folder=db.backupFolder(); val en=db.language()=="en"
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(if(en)"Backup and Restore" else "النسخ الاحتياطي واستعادة البيانات",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text(if(folder==null){if(en)"No automatic backup folder selected" else "لم يتم تحديد مجلد للنسخ التلقائي"}else{if(en)"Automatic backup folder selected" else "تم تحديد مجلد لحفظ النسخ التلقائية"},color=Color.Gray,fontSize=13.sp)
        Button(onClick=onChooseFolder,Modifier.fillMaxWidth()){Text(if(en)"Choose automatic backup folder" else "تحديد مجلد النسخ التلقائي")}
        Button(onClick={message=if(folder==null){if(en)"Choose a backup folder first" else "حدد مجلد الحفظ أولًا"}else if(onBackup()){if(en)"Backup created successfully" else "تم إنشاء النسخة الاحتياطية بنجاح"}else{if(en)"Could not create backup" else "تعذر إنشاء النسخة الاحتياطية"}},Modifier.fillMaxWidth(),enabled=folder!=null){Text(if(en)"Create backup now" else "إنشاء نسخة احتياطية الآن")}
        OutlinedButton(onClick={confirmRestore=true},Modifier.fillMaxWidth()){Text(if(en)"Restore database from ZIP" else "استعادة قاعدة البيانات من ZIP")}
        Divider(Modifier.padding(vertical=10.dp))
        Text(if(en)"Clear All Transactions" else "Clear All Transactions – مسح جميع العمليات",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.error,fontSize=17.sp)
        Text(if(en)"Creates a ZIP backup first, then deletes sales, collections, stock movements and work periods. Products and customers remain registered; product and stock balances are reset to zero. Recipes, users and settings are preserved." else "ينشئ نسخة ZIP احتياطية أولًا، ثم يمسح المبيعات والتحصيلات وحركات المخزون وفترات العمل. يحتفظ بالمنتجات والعملاء المسجلين، ويصفر أرصدة المنتجات وأصناف المخزون. يحتفظ بالريسبي والمستخدمين والإعدادات.",fontSize=12.sp,color=Color.Gray)
        Button(onClick={confirmClear=true},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=MaterialTheme.colorScheme.error)){Text(if(en)"Clear All Transactions" else "مسح جميع العمليات")}
        Text(if(en)"Automatic backup is created after closing a work period when a folder is selected." else "يتم إنشاء نسخة تلقائية بعد إنهاء فترة العمل عند تحديد مجلد الحفظ.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=12.dp))
        if(message.isNotBlank())Text(message,color=Blue,modifier=Modifier.padding(top=8.dp))
    }
    if(confirmRestore)AlertDialog(onDismissRequest={confirmRestore=false},title={Text(if(en)"Confirm restore" else "تأكيد الاستعادة")},text={Text(if(en)"Restoring will replace the current database. Create a backup first. Continue?" else "استعادة النسخة ستستبدل قاعدة البيانات الحالية. يفضل إنشاء نسخة احتياطية أولًا. هل تريد اختيار ملف ZIP؟")},confirmButton={TextButton(onClick={confirmRestore=false;onRestore()}){Text(if(en)"Choose ZIP" else "اختيار ملف ZIP")}},dismissButton={TextButton(onClick={confirmRestore=false}){Text(if(en)"Cancel" else "إلغاء")}})
    if(confirmClear)AlertDialog(onDismissRequest={confirmClear=false},title={Text(if(en)"Confirm clearing all transactions" else "تأكيد مسح جميع العمليات")},text={Text(if(en)"A ZIP backup must be created successfully before clearing. Sales, payment history, stock movements and work periods will be deleted. Products and customers remain, while their balances are reset. Continue?" else "سيتم إنشاء نسخة ZIP أولًا. بعد نجاحها ستحذف المبيعات والتحصيلات وحركات المخزون وفترات العمل، مع الاحتفاظ بالمنتجات والعملاء وتعريفاتهم وتصفير أرصدتهم. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={confirmClear=false;message=if(db.clearAllTransactions()){if(en)"Backup saved and all transactions cleared successfully" else "تم حفظ النسخة الاحتياطية ومسح جميع العمليات بنجاح"}else{if(en)"Backup failed; no data was deleted" else "فشل إنشاء النسخة الاحتياطية؛ لم يتم حذف أي بيانات"}}){Text(if(en)"Backup and clear" else "نسخ احتياطي ومسح")}},dismissButton={TextButton(onClick={confirmClear=false}){Text(if(en)"Cancel" else "إلغاء")}})
}

@Composable private fun LanguagePage(db:LocalDb,pad:PaddingValues,onChanged:()->Unit){
    var selected by remember{mutableStateOf(db.language())}
    val en=selected=="en"
    Column(Modifier.fillMaxSize().padding(pad).padding(18.dp)){
        Text(if(en)"Application language" else "لغة البرنامج",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text(if(en)"Choose the language used by the application interface." else "اختر اللغة المستخدمة في واجهة البرنامج.",color=Color.Gray,modifier=Modifier.padding(vertical=10.dp))
        Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=selected=="ar",onClick={selected="ar"});Text("العربية",fontSize=17.sp)}
        Row(verticalAlignment=Alignment.CenterVertically){RadioButton(selected=selected=="en",onClick={selected="en"});Text("English",fontSize=17.sp)}
        Button(onClick={db.setLanguage(selected);onChanged()},Modifier.fillMaxWidth().padding(top=16.dp)){Text(if(en)"Save language" else "حفظ اللغة")}
        Text(if(en)"The selected language is saved and remains selected after restarting the app." else "يتم حفظ اللغة المختارة وتظل مفعّلة بعد إغلاق البرنامج وفتحه مرة أخرى.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=10.dp))
    }
}

@Composable private fun Work(db:LocalDb,pad:PaddingValues,onClose:()->Boolean,onOpen:()->Unit){
    var closeError by remember{mutableStateOf(false)}
    val isOpen=db.hasOpenPeriod()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(isOpen) { if(isOpen) while(true) { now=System.currentTimeMillis(); delay(1000) } }
    val times=db.latestPeriodTimes()
    val start=times?.first
    val end=times?.second ?: if(isOpen) now else null
    val elapsed=if(start!=null&&end!=null)(end-start).coerceAtLeast(0L)/1000 else 0L
    val hours=elapsed/3600; val minutes=(elapsed%3600)/60; val seconds=elapsed%60
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("فترة العمل",fontWeight=FontWeight.Bold,fontSize=20.sp)
        RowCard(if(isOpen) db.period() else "لا توجد فترة عمل مفتوحة")
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF4D6))){Column(Modifier.padding(16.dp)){Text("مدة فترة العمل",fontWeight=FontWeight.Bold,color=Ink);Text(if(times==null)"لم تبدأ فترة عمل بعد" else "${hours} ساعة و ${minutes} دقيقة${if(isOpen)" و ${seconds} ثانية" else ""}",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink);if(isOpen)Text("يتم تحديث المدة تلقائيًا",fontSize=12.sp,color=Color.Gray)}}
        Button(onClick=onOpen,Modifier.fillMaxWidth(),enabled=!isOpen){Text("فتح فترة عمل")}
        OutlinedButton(onClick={closeError=!onClose()},Modifier.fillMaxWidth(),enabled=isOpen){Text("إنهاء فترة العمل")}
    }
    if(closeError)AlertDialog(onDismissRequest={closeError=false},title={Text("تعذر إنهاء فترة العمل")},text={Text("لم يتم حفظ النسخة الاحتياطية في المجلد المحدد، لذلك لم يتم إنهاء فترة العمل. تحقق من صلاحية المجلد وحاول مرة أخرى.")},confirmButton={TextButton(onClick={closeError=false}){Text("حسنًا")}})
}
@Composable private fun InvoicesPage(db:LocalDb,pad:PaddingValues,onSelect:(Long)->Unit){
    var query by remember{mutableStateOf("")}
    val rows=db.invoiceSummaries(query)
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("الفواتير",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Input("بحث برقم الفاتورة أو اسم العميل أو الهاتف",query,{query=it})
        if(rows.isEmpty())Text("لا توجد فواتير مطابقة",color=Color.Gray,modifier=Modifier.padding(10.dp))
        LazyColumn{items(rows,key={it.id}){inv->
            RowCard("فاتورة رقم ${inv.id} | ${inv.customerName}","${inv.createdAt} | الإجمالي ${fmt(inv.total)} ج.م | المدفوع ${fmt(inv.paid)} | المتبقي ${fmt(inv.due)} | ${inv.method}"){onSelect(inv.id)}
        }}
    }
}

@Composable private fun InvoiceDetails(db:LocalDb,invoiceId:Long,pad:PaddingValues,activity:ComponentActivity,onDeleted:()->Unit){
    val inv=db.invoiceSummaries(invoiceId.toString()).firstOrNull{it.id==invoiceId}
    if(inv==null){Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){Text("الفاتورة غير موجودة")};return}
    val lines=db.invoiceLines(invoiceId)
    val payments=db.invoicePayments(invoiceId)
    val grossTotal=lines.sumOf{it.qty*it.price}
    val discountAmount=inv.discount.coerceAtLeast(0.0).coerceAtMost(grossTotal)
    val discountPercent=if(grossTotal>0.0) discountAmount/grossTotal*100.0 else 0.0
    var askDelete by remember(invoiceId){mutableStateOf(false)}
    var deleteMessage by remember(invoiceId){mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تفاصيل الفاتورة رقم ${inv.id}",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(12.dp)){
                Text("رقم الفاتورة: ${inv.id}")
                val (invoiceDate,invoiceTime)=formatInvoiceDateTime(inv.createdAt)
                Text("التاريخ: $invoiceDate",fontWeight=FontWeight.SemiBold)
                Text("الوقت: $invoiceTime",fontWeight=FontWeight.SemiBold)
                Text("اسم العميل: ${inv.customerName}")
                Text("رقم العميل: ${inv.mobile.ifBlank{"—"}}")
                Text("اسم المحل: ${inv.shop.ifBlank{"—"}}")
                Text("المحافظة: ${inv.governorate.ifBlank{"—"}}")
                Text("نوع الدفع: ${inv.method}")
                payments.filterValues{it>0}.forEach{(method,amount)->Text("$method: ${fmt(amount)} ج.م",fontSize=12.sp,color=Color.Gray)}
            }
        }
        Text("تفاصيل الأصناف",fontWeight=FontWeight.Bold,color=Ink)
        Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
            Text("الصنف",Modifier.weight(2f),fontWeight=FontWeight.Bold,fontSize=11.sp)
            Text("الكمية",Modifier.weight(0.8f),fontWeight=FontWeight.Bold,fontSize=11.sp)
            Text("سعر الوحدة",Modifier.weight(1.2f),fontWeight=FontWeight.Bold,fontSize=11.sp)
            Text("الإجمالي",Modifier.weight(1.2f),fontWeight=FontWeight.Bold,fontSize=11.sp)
        }
        Divider()
        LazyColumn(Modifier.weight(1f)){
            items(lines,key={it.id}){line->Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                Text(line.name,Modifier.weight(2f),fontSize=11.sp)
                Text(fmt(line.qty),Modifier.weight(0.8f),fontSize=11.sp)
                Text(fmt(line.price),Modifier.weight(1.2f),fontSize=11.sp)
                Text(fmt(line.qty*line.price),Modifier.weight(1.2f),fontSize=11.sp)
            };Divider()}
        }
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                Text("إجمالي الفاتورة قبل الخصم: ${fmt(grossTotal)} ج.م",fontWeight=FontWeight.SemiBold)
                Text("نسبة الخصم: ${fmt(discountPercent)}٪")
                Text("قيمة الخصم: ${fmt(discountAmount)} ج.م",color=Color(0xFFB45309))
                Divider(Modifier.padding(vertical=3.dp))
                Text("الإجمالي بعد الخصم: ${fmt(inv.total)} ج.م",fontWeight=FontWeight.Bold,color=Ink)
                Text("المدفوع: ${fmt(inv.paid)} ج.م")
                Text("المتبقي: ${fmt(inv.due)} ج.م",color=if(inv.due>0.009)MaterialTheme.colorScheme.error else Ink,fontWeight=FontWeight.Bold)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(onClick={activity.printInvoiceHtml(db,inv,lines)},Modifier.weight(1f)){Text("طباعة الفاتورة")}
            OutlinedButton(onClick={askDelete=true},Modifier.weight(1f),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.error)){Text("حذف الفاتورة")}
        }
    }
    if(askDelete)AlertDialog(onDismissRequest={askDelete=false},title={Text("تأكيد حذف الفاتورة")},text={Text("سيتم حذف الفاتورة رقم ${inv.id} وإلغاء كل التحصيلات المرتبطة بها وإرجاع كميات المنتجات والمخزون. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={val ok=db.deleteInvoice(invoiceId);askDelete=false;deleteMessage=if(ok)"تم حذف الفاتورة وعكس حركاتها" else "تعذر حذف الفاتورة"}){Text("حذف نهائي",color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={askDelete=false}){Text("إلغاء")}})
    if(deleteMessage.isNotBlank())AlertDialog(onDismissRequest={deleteMessage="";if(!db.invoiceSummaries(invoiceId.toString()).any{it.id==invoiceId})onDeleted()},title={Text("الفواتير")},text={Text(deleteMessage)},confirmButton={TextButton(onClick={val deleted=!db.invoiceSummaries(invoiceId.toString()).any{it.id==invoiceId};deleteMessage="";if(deleted)onDeleted()}){Text("حسنًا")}})
}

@Composable private fun SalesMovements(db:LocalDb,pad:PaddingValues,onView:(Long)->Unit){
    var query by remember{mutableStateOf("")}
    val rows=db.salesAccountInvoices(query)
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("حركة المبيعات",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("الفترة المحددة: ${db.accountPeriodLabel(db.accountPeriod("sales"))}",fontSize=12.sp,color=Color.Gray)
        Input("بحث برقم الفاتورة أو اسم العميل أو الهاتف",query,{query=it})
        if(rows.isEmpty())Text("لا توجد حركات مبيعات",color=Color.Gray)
        LazyColumn{items(rows,key={it.id}){inv->
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                Column(Modifier.padding(11.dp)){
                    Text("فاتورة رقم ${inv.id} — ${inv.customerName}",fontWeight=FontWeight.Bold,color=Ink)
                    val (invoiceDate,invoiceTime)=formatInvoiceDateTime(inv.createdAt)
                    Text("$invoiceDate - $invoiceTime | الإجمالي ${fmt(inv.total)} ج.م | المدفوع ${fmt(inv.paid)} | المتبقي ${fmt(inv.due)}",fontSize=11.sp,color=Color.Gray)
                    OutlinedButton(onClick={onView(inv.id)},Modifier.fillMaxWidth()){Text("عرض")}
                }
            }
        }}
    }
}

@Composable private fun InvoiceEditor(db:LocalDb,invoiceId:Long,pad:PaddingValues,onSaved:()->Unit,onCancel:()->Unit){
    val inv=db.invoiceSummaries(invoiceId.toString()).firstOrNull{it.id==invoiceId}
    if(inv==null){Text("الفاتورة غير موجودة",Modifier.padding(pad));return}
    var lines by remember(invoiceId){mutableStateOf(db.invoiceLines(invoiceId))}
    var error by remember{mutableStateOf("")}
    val total=(lines.filter{it.qty>0}.sumOf{it.qty*it.price}-inv.discount).coerceAtLeast(0.0)
    val paid=inv.paid
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تعديل الفاتورة رقم $invoiceId",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
        Text("${inv.customerName} | ${inv.createdAt}",color=Color.Gray,fontSize=12.sp)
        Text("الأصناف والكميات والأسعار",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
        LazyColumn(Modifier.weight(1f)){
            items(lines,key={it.id}){line->
                Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){
                    Text(line.name,fontWeight=FontWeight.SemiBold)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        Input("الكمية",line.qty.toString(),{v->val n=v.toDoubleOrNull();if(n!=null)lines=lines.map{if(it.id==line.id)it.copy(qty=n)else it}},Modifier.weight(1f),true)
                        Input("سعر الوحدة",line.price.toString(),{v->val n=v.toDoubleOrNull();if(n!=null)lines=lines.map{if(it.id==line.id)it.copy(price=n)else it}},Modifier.weight(1f),true)
                    }
                    TextButton(onClick={lines=lines.map{if(it.id==line.id)it.copy(qty=0.0)else it}}){Text("حذف الصنف من الفاتورة",color=MaterialTheme.colorScheme.error)}
                    Divider()
                }
            }
        }
        Text("المدفوع المسجل: ${fmt(paid)} ج.م — يتم الحفاظ على حركات الدفع والتحصيل كما هي.",color=Color.Gray,fontSize=12.sp)
        Text("الإجمالي الجديد: ${fmt(total)} ج.م | المتبقي: ${fmt((total-paid).coerceAtLeast(0.0))} ج.م",fontWeight=FontWeight.Bold,color=Ink,fontSize=12.sp)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick=onCancel,Modifier.weight(1f)){Text("إلغاء")}
            Button(onClick={
                when{paid>total+0.009->error="إجمالي الفاتورة الجديد أقل من المبلغ المدفوع؛ لا يمكن حفظ التعديل";lines.none{it.qty>0}->error="لا يمكن حفظ فاتورة بدون أصناف";db.updateInvoice(invoiceId,lines)->onSaved();else->error="تعذر حفظ تعديل الفاتورة"}
            },Modifier.weight(1f)){Text("حفظ التعديلات")}
        }
    }
}

@Composable private fun ListPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);if(data.isEmpty())Text("لا توجد سجلات حتى الآن",color=Color.Gray);LazyColumn{items(data){RowCard(it)}}}}
@Composable private fun AccountsHome(db:LocalDb,pad:PaddingValues,onPayments:()->Unit,onCustomers:()->Unit,openDetails:(String)->Unit){
    var filter by rememberSaveable{mutableStateOf(if(db.hasOpenPeriod())"فترة العمل الحالية" else "اليوم")}
    var expanded by remember{mutableStateOf(false)}
    val totals=db.dashboardTotals(filter)
    val filters=listOf("فترة العمل الحالية","فترة العمل السابقة","اليوم","الشهر","الأسبوع الحالي","الأسبوع الماضي","الكل")
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("الحسابات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Card(Modifier.fillMaxWidth().padding(vertical=6.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.fillMaxWidth().padding(12.dp)){
                Text("المبيعات",fontWeight=FontWeight.Bold,fontSize=17.sp,color=Ink)
                Box(Modifier.fillMaxWidth().padding(top=6.dp)){
                    OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text("الفلترة: $filter   ▾")}
                    DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){filters.forEach{v->DropdownMenuItem(text={Text(v)},onClick={filter=v;expanded=false})}}
                }
                Row(Modifier.fillMaxWidth().padding(vertical=7.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Metric("إيرادات المبيعات",fmt(totals.first))
                    Metric("المستحقات",fmt(totals.second))
                    Metric("عدد الفواتير",totals.third.toString())
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick={openDetails("تفاصيل إيرادات مبيعات اليوم")},modifier=Modifier.weight(1f)){Text("تفاصيل الإيرادات",fontSize=11.sp)}
                    OutlinedButton(onClick={openDetails("تفاصيل المستحقات")},modifier=Modifier.weight(1f)){Text("تفاصيل المستحقات",fontSize=11.sp)}
                }
            }
        }
        RowCard("حركة المدفوعات","النقدية وإنستا باي والحساب البنكي"){onPayments()}
        RowCard("العملاء","حسابات العملاء المسجلين وتفاصيل الحساب والتحصيل"){onCustomers()}
    }
}

@Composable private fun AccountsCustomers(db:LocalDb,pad:PaddingValues,onDetails:(Customer)->Unit){
    var query by remember{mutableStateOf("")}
    val customers=db.customers(query)
    val outstanding=db.totalCustomerOutstanding()
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
        Text("حسابات العملاء",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("الفترة المحددة: ${db.accountPeriodLabel(db.accountPeriod("customers"))}",fontSize=12.sp,color=Color.Gray)
        Card(Modifier.fillMaxWidth().padding(vertical=7.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(13.dp)) {
                Text("إجمالي المبالغ غير المحصلة",color=Color.Gray,fontSize=13.sp)
                Text("${fmt(outstanding)} ج.م",fontWeight=FontWeight.Bold,fontSize=23.sp,color=Blue)
            }
        }
        Input("بحث باسم العميل أو الهاتف",query,{query=it})
        Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceBetween){
            Text("العميل",fontWeight=FontWeight.Bold,fontSize=12.sp)
            Text("المديونية  |  المحصل  |  المتبقي",fontWeight=FontWeight.Bold,fontSize=10.sp)
        }
        Divider(color=Color.LightGray)
        LazyColumn { items(customers,key={it.id}) { c ->
            val t=db.customerTotals(c.id)
            val collected=(t.first-t.second).coerceAtLeast(0.0)
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{onDetails(c)},colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(11.dp)) {
                    Text(c.name,fontWeight=FontWeight.Bold,color=Ink)
                    if(c.mobile.isNotBlank()) Text(c.mobile,color=Color.Gray,fontSize=11.sp)
                    Row(Modifier.fillMaxWidth().padding(top=7.dp),horizontalArrangement=Arrangement.SpaceBetween){
                        Column { Text("المديونية",fontSize=10.sp,color=Color.Gray);Text(fmt(t.first),fontSize=12.sp,fontWeight=FontWeight.SemiBold) }
                        Column { Text("المحصل",fontSize=10.sp,color=Color.Gray);Text(fmt(collected),fontSize=12.sp,fontWeight=FontWeight.SemiBold) }
                        Column { Text("المتبقي",fontSize=10.sp,color=Color.Gray);Text(fmt(t.second),fontSize=12.sp,color=Blue,fontWeight=FontWeight.Bold) }
                    }
                    OutlinedButton(onClick={onDetails(c)},modifier=Modifier.fillMaxWidth().padding(top=5.dp)){Text("تفاصيل الحساب")}
                }
            }
        } }
        if(customers.isEmpty()) Text("لا يوجد عملاء مسجلون",color=Color.Gray)
    }
}
@Composable private fun CustomerCollection(db:LocalDb,customer:Customer?,pad:PaddingValues,onDone:()->Unit,onCancel:()->Unit){
    var amount by remember{mutableStateOf("")}; var method by remember{mutableStateOf("نقدي")}; var error by remember{mutableStateOf("")}
    val due=customer?.let{db.customerTotals(it.id).second}?:0.0
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
        Text("تحصيل عميل",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("العميل: ${customer?.name.orEmpty()}")
        Text("الرصيد المستحق: ${fmt(due)} ج.م",fontWeight=FontWeight.Bold,color=Blue)
        Input("مبلغ التحصيل",amount,{amount=it},numeric=true)
        Text("طريقة التحصيل",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp))
        listOf("نقدي","إنستا باي","حساب بنكي").forEach{m->FilterChip(selected=method==m,onClick={method=m},label={Text(m)},modifier=Modifier.padding(end=5.dp))}
        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
        Button(onClick={val v=amount.toDoubleOrNull();when{customer==null->error="لم يتم تحديد عميل";v==null||v<=0->error="أدخل مبلغ تحصيل صحيح";v>due+0.009->error="مبلغ التحصيل أكبر من الرصيد المستحق";db.collectCustomer(customer.id,v,method)->onDone();else->error="تعذر تسجيل التحصيل"}},Modifier.fillMaxWidth().padding(top=12.dp)){Text("حفظ التحصيل")}
        OutlinedButton(onClick=onCancel,Modifier.fillMaxWidth()){Text("إلغاء")}
    }
}
@Composable private fun PaymentAccounts(db:LocalDb,pad:PaddingValues,onSelect:(String)->Unit){
    val balances=db.paymentAccountBalances()
    val totalPaid=(balances["نقدية"]?:0.0)+(balances["إنستا باي"]?:0.0)+(balances["حساب بنكي"]?:0.0)
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("حركة المدفوعات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("إجمالي المدفوعات المسجلة فعليًا",color=Color.Gray,fontSize=12.sp)
        Card(Modifier.fillMaxWidth().padding(vertical=8.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(13.dp)){
                Text("الإجمالي الكلي",color=Color.Gray,fontSize=12.sp)
                Text("${fmt(totalPaid)} ج.م",fontWeight=FontWeight.Bold,fontSize=23.sp,color=Blue)
                Divider(Modifier.padding(vertical=7.dp),color=Color.LightGray)
                listOf("نقدية","إنستا باي","حساب بنكي").forEach{account->
                    Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.SpaceBetween){
                        Text("إجمالي $account",color=Ink,fontSize=13.sp)
                        Text("${fmt(balances[account]?:0.0)} ج.م",fontWeight=FontWeight.SemiBold,fontSize=13.sp)
                    }
                }
            }
        }
        Text("الفترة المحددة: ${db.accountPeriodLabel(db.accountPeriod("payments"))}",color=Color.Gray,fontSize=12.sp)
        Text("اضغط على الحساب لعرض كشف الحركات",color=Color.Gray,fontSize=12.sp)
        listOf("نقدية","إنستا باي","حساب بنكي").forEach{account->
            RowCard(account,"إجمالي المدفوعات: ${fmt(balances[account]?:0.0)} ج.م | عرض كشف الحساب"){onSelect(account)}
        }
    }
}
@Composable private fun PaymentStatement(db:LocalDb,account:String,pad:PaddingValues,onDetails:()->Unit){
    val balances=db.paymentAccountBalances()
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("كشف حساب $account",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(14.dp)){
                Text("الرصيد الحالي",color=Color.Gray)
                Text("${fmt(balances[account]?:0.0)} ج.م",fontWeight=FontWeight.Bold,fontSize=23.sp,color=Blue)
            }
        }
        Button(onClick=onDetails,modifier=Modifier.fillMaxWidth().padding(top=10.dp)){Text("تفاصيل الحساب")}
        Text("حركات التحصيل",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=5.dp))
        val movements=db.paymentMovements(account)
        if(movements.isEmpty()) Text("لا توجد حركات مسجلة لهذا الحساب حتى الآن",color=Color.Gray)
        LazyColumn{items(movements){m->RowCard("فاتورة رقم ${m.invoiceId} | ${fmt(m.amount)} ج.م","التاريخ: ${m.createdAt}")}}
    }
}

@Composable private fun AccountSettingsPage(db:LocalDb,pad:PaddingValues,done:()->Unit){
    val options=listOf("month" to "الشهر","period" to "فترة العمل","week" to "الأسبوع الحالي","last_week" to "الأسبوع الماضي","all" to "الكل")
    val accounts=listOf("sales" to "حركة المبيعات","sales_today" to "إيرادات مبيعات اليوم","receivables" to "المستحقات","payments" to "حساب المدفوعات","customers" to "حسابات العملاء")
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("إعدادات الحسابات",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("حدد فترة الاحتساب لكل حساب بشكل مستقل. خيار الكل يحتفظ بالأرصدة تراكمياً حتى بعد إغلاق فترة العمل.",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(vertical=7.dp))
        LazyColumn { items(accounts){(key,title)->
            var selected by remember(key){mutableStateOf(db.accountPeriod(key))}
            Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                Column(Modifier.padding(12.dp)){
                    Text(title,fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp)
                    options.chunked(2).forEach{group->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        group.forEach{(value,label)->Row(Modifier.weight(1f).clickable{selected=value;db.setAccountPeriod(key,value);done()},verticalAlignment=Alignment.CenterVertically){Checkbox(checked=selected==value,onCheckedChange={selected=value;db.setAccountPeriod(key,value);done()},modifier=Modifier.size(34.dp));Text(label,fontSize=12.sp)}}
                        if(group.size==1)Spacer(Modifier.weight(1f))
                    }}
                }
            }
        }}
    }
}

@Composable private fun PaymentAccountDetails(db:LocalDb,account:String,pad:PaddingValues){
    var query by remember{mutableStateOf("")}
    var filter by remember{mutableStateOf("الكل")}
    var expanded by remember{mutableStateOf(false)}
    val options=listOf("الكل","فترة العمل الحالية","فترة العمل السابقة","الشهر","الأسبوع الماضي")
    val allMovements=db.filteredPaymentMovements(account,filter)
    var running=0.0
    val balances=allMovements.map{m->running+=m.amount;m.id to running}.toMap()
    val movements=allMovements.filter{query.isBlank() || it.invoiceId.toString().contains(query,true) || fmt(it.amount).contains(query,true) || it.createdAt.contains(query,true)}
    val total=allMovements.sumOf{it.amount}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تفاصيل حساب $account",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("إجمالي العمليات المعروضة: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold,color=Blue,modifier=Modifier.padding(vertical=6.dp))
        OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("بحث في العمليات")},leadingIcon={Icon(Icons.Default.Search,null)})
        Box(Modifier.fillMaxWidth().padding(vertical=7.dp)){
            OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()) {Text("الفلترة: $filter   ▾")}
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){options.forEach{v->DropdownMenuItem(text={Text(v)},onClick={filter=v;expanded=false})}}
        }
        Row(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("العملية",fontWeight=FontWeight.Bold,fontSize=12.sp);Text("المبلغ | الرصيد",fontWeight=FontWeight.Bold,fontSize=12.sp)}
        Divider(color=Color.LightGray)
        if(movements.isEmpty())Text("لا توجد عمليات في الفترة المحددة",color=Color.Gray,modifier=Modifier.padding(12.dp))
        LazyColumn { items(movements.asReversed(),key={it.id}){m->
            Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                Column(Modifier.padding(10.dp)){
                    Text("فاتورة رقم ${m.invoiceId}",fontWeight=FontWeight.Bold,color=Ink)
                    Text(m.createdAt,fontSize=11.sp,color=Color.Gray)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${fmt(m.amount)} ج.م",fontWeight=FontWeight.SemiBold);Text("الرصيد: ${fmt(balances[m.id]?:0.0)} ج.م",fontSize=12.sp,color=Blue)}
                }
            }
        }}
    }
}
@Composable private fun SalesDueAccountDetails(db:LocalDb,accountType:String,pad:PaddingValues){
    var query by remember{mutableStateOf("")}
    val settingKey=if(accountType=="المستحقات")"receivables" else "sales_today"
    val initialFilter=when(db.accountPeriod(settingKey)){"month"->"الشهر";"period"->"فترة العمل الحالية";"week"->"الأسبوع الحالي";"last_week"->"الأسبوع الماضي";else->"الكل"}
    var filter by remember(accountType){mutableStateOf(initialFilter)};var expanded by remember{mutableStateOf(false)}
    val options=listOf("فترة العمل الحالية","فترة العمل السابقة","اليوم","الشهر","الأسبوع الحالي","الأسبوع الماضي","الكل")
    val rows=db.accountInvoiceDetails(accountType,filter,query)
    val amount=if(accountType=="المستحقات")rows.sumOf{it.due}else rows.sumOf{it.total}
    Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)){
        Text("تفاصيل $accountType",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("الإجمالي المعروض: ${fmt(amount)} ج.م | عدد الفواتير: ${rows.size}",fontWeight=FontWeight.Bold,color=Blue,modifier=Modifier.padding(vertical=6.dp))
        OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("بحث برقم الفاتورة أو اسم العميل")},leadingIcon={Icon(Icons.Default.Search,null)})
        Box(Modifier.fillMaxWidth().padding(vertical=7.dp)){
            OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text("الفلترة: $filter   ▾")}
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){options.forEach{v->DropdownMenuItem(text={Text(v)},onClick={filter=v;expanded=false})}}
        }
        if(rows.isEmpty())Text("لا توجد فواتير في الفترة المحددة",color=Color.Gray,modifier=Modifier.padding(12.dp))
        LazyColumn{items(rows,key={it.id}){inv->Card(Modifier.fillMaxWidth().padding(vertical=3.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
            Column(Modifier.padding(10.dp)){
                Text("فاتورة رقم ${inv.id} | ${inv.customerName}",fontWeight=FontWeight.Bold,color=Ink)
                Text(inv.createdAt,fontSize=11.sp,color=Color.Gray)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("الإجمالي: ${fmt(inv.total)} ج.م",fontSize=12.sp);Text("المستحق: ${fmt(inv.due)} ج.م",fontSize=12.sp,color=Blue)}
            }
        }}}
    }
}
@Composable private fun InfoPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);data.forEach{RowCard(it)}}}
@Composable private fun Input(label:String,value:String,onChange:(String)->Unit,modifier:Modifier=Modifier,numeric:Boolean=false){OutlinedTextField(value,onChange,modifier.fillMaxWidth().padding(vertical=3.dp),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(numeric)KeyboardType.Decimal else KeyboardType.Text))}
@Composable private fun RowCard(title:String,sub:String="",click:(()->Unit)?=null){Card(Modifier.fillMaxWidth().padding(vertical=4.dp).then(if(click!=null)Modifier.clickable{click()}else Modifier),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text(title,fontWeight=FontWeight.SemiBold,color=Ink);if(sub.isNotBlank())Text(sub,color=Color.Gray,fontSize=12.sp)}}}
private fun formatInvoiceDateTime(raw:String):Pair<String,String>{
    return try {
        val parser=SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone=TimeZone.getTimeZone("UTC") }
        val date=parser.parse(raw) ?: return raw to ""
        val day=SimpleDateFormat("dd/MM/yyyy", Locale("ar")).format(date)
        val time=SimpleDateFormat("hh:mm a", Locale("ar")).format(date)
        day to time
    } catch (_:Exception) { raw to "" }
}

private fun fmt(v:Double)="%.2f".format(v)
