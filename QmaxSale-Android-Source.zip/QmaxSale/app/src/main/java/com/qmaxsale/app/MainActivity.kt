package com.qmaxsale.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1677D2)
private val Ink = Color(0xFF17324D)
private val Bg = Color(0xFFF5F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = LocalDb(this)
        setContent { QmaxApp(db) }
    }
}

private class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "qmax_sale.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,barcode TEXT,category TEXT,cost REAL DEFAULT 0,price REAL DEFAULT 0,qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,mobile TEXT,governorate TEXT,area TEXT,shop TEXT,balance REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,total REAL,paid REAL,due REAL,method TEXT)")
        db.execSQL("CREATE TABLE invoice_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,qty REAL,price REAL,cost REAL)")
        db.execSQL("CREATE TABLE stock_items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,barcode TEXT,qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE work_periods(id INTEGER PRIMARY KEY AUTOINCREMENT,opened_at TEXT DEFAULT CURRENT_TIMESTAMP,opening_cash REAL,closed_at TEXT,is_open INTEGER DEFAULT 1)")
        db.execSQL("ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0")
        db.execSQL("CREATE TABLE invoice_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE invoices ADD COLUMN discount REAL DEFAULT 0")
            db.execSQL("CREATE TABLE IF NOT EXISTS invoice_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER NOT NULL,method TEXT NOT NULL,amount REAL NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        }
    }
    fun addProduct(n:String,c:String,b:String,cat:String,cost:Double,price:Double,qty:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost);put("price",price);put("qty",qty) }
        writableDatabase.insert("products",null,v)
    }
    fun products():List<Product> { val a=mutableListOf<Product>();readableDatabase.rawQuery("SELECT id,name,code,barcode,category,cost,price,qty FROM products ORDER BY name",null).use { c->while(c.moveToNext())a.add(Product(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getDouble(5),c.getDouble(6),c.getDouble(7))) };return a }
    fun updateProductDetails(id:Long,n:String,c:String,b:String,cat:String,cost:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost) }
        writableDatabase.update("products",v,"id=?",arrayOf(id.toString()))
    }
    fun updateProductPrice(id:Long,price:Double) {
        val v=ContentValues().apply { put("price",price) }
        writableDatabase.update("products",v,"id=?",arrayOf(id.toString()))
    }
    fun deleteProduct(id:Long) {
        // Invoice lines keep their saved name, quantity, price and cost snapshots.
        writableDatabase.delete("products","id=?",arrayOf(id.toString()))
    }
    fun addCustomer(n:String,m:String,g:String,a:String,s:String) { val v=ContentValues().apply{put("name",n);put("mobile",m);put("governorate",g);put("area",a);put("shop",s)};writableDatabase.insert("customers",null,v) }
    fun customers():List<String> { val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT name||' | '||ifnull(mobile,'') FROM customers ORDER BY name",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a }
    fun stockItems():List<String> { val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT name||' | كمية: '||qty FROM stock_items ORDER BY name",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a }
    fun addStock(n:String,b:String,q:Double) { val v=ContentValues().apply{put("name",n);put("barcode",b);put("qty",q)};writableDatabase.insert("stock_items",null,v) }
    fun saveSale(lines:List<Pair<Product,Double>>,paid:Double,method:String) {
        saveSale(lines, mapOf(method to paid.coerceAtLeast(0.0)), 0.0)
    }
    fun saveSale(lines:List<Pair<Product,Double>>,payments:Map<String,Double>,discount:Double) {
        val gross=lines.sumOf{it.first.price*it.second}
        val discountValue=(gross*discount.coerceIn(0.0,100.0)/100.0).coerceAtMost(gross)
        val total=(gross-discountValue).coerceAtLeast(0.0)
        val paid=payments.values.filter{it>0.0}.sum().coerceAtMost(total)
        val due=(total-paid).coerceAtLeast(0.0)
        val d=writableDatabase;d.beginTransaction()
        try {
            val methods=payments.filterValues{it>0.0}.keys.joinToString(" + ").ifBlank{"حساب العميل"}
            val methodLabel=if(methods.contains(" + "))"متعدد" else methods
            val finalMethod=if(due>0.009) "$methodLabel + آجل" else methodLabel
            val v=ContentValues().apply{put("total",total);put("paid",paid);put("due",due);put("method",finalMethod);put("discount",discountValue)}
            val id=d.insert("invoices",null,v)
            lines.forEach{(p,q)->val x=ContentValues().apply{put("invoice_id",id);put("product_id",p.id);put("name",p.name);put("qty",q);put("price",p.price);put("cost",p.cost)};d.insert("invoice_lines",null,x);d.execSQL("UPDATE products SET qty=qty-? WHERE id=?",arrayOf(q,p.id))}
            payments.filterValues{it>0.0}.forEach{(method,amount)->val pay=ContentValues().apply{put("invoice_id",id);put("method",method);put("amount",amount)};d.insert("invoice_payments",null,pay)}
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun invoices():List<String> { val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT 'فاتورة #'||id||' | الإجمالي '||total||' | مدفوع '||paid||' | متبقي '||due FROM invoices ORDER BY id DESC",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a }
    fun totals():Triple<Double,Double,Int>{readableDatabase.rawQuery("SELECT ifnull(sum(total),0),ifnull(sum(due),0),count(*) FROM invoices WHERE date(created_at)=date('now','localtime')",null).use{it.moveToFirst();return Triple(it.getDouble(0),it.getDouble(1),it.getInt(2))}}
    fun stockValue():Double{readableDatabase.rawQuery("SELECT ifnull(sum(qty*cost),0) FROM products",null).use{it.moveToFirst();return it.getDouble(0)}}
    fun period():String{readableDatabase.rawQuery("SELECT opened_at,opening_cash FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())return "فترة مفتوحة منذ ${it.getString(0)} | افتتاحي ${it.getDouble(1)}"};return "لا توجد فترة عمل مفتوحة"}
    fun openPeriod(cash:Double){writableDatabase.execSQL("UPDATE work_periods SET is_open=0 WHERE is_open=1");val v=ContentValues().apply{put("opening_cash",cash)};writableDatabase.insert("work_periods",null,v)}
    fun closePeriod(){writableDatabase.execSQL("UPDATE work_periods SET is_open=0,closed_at=CURRENT_TIMESTAMP WHERE is_open=1")}
}
private data class Product(val id:Long,val name:String,val code:String,val barcode:String,val category:String,val cost:Double,val price:Double,val qty:Double)
private data class Tile(val name:String,val icon:ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun QmaxApp(db:LocalDb) {
    var page by remember{mutableStateOf("الرئيسية")};var revision by remember{mutableIntStateOf(0)}
    var pendingLines by remember{mutableStateOf<List<Pair<Product,Double>>>(emptyList())}
    val tiles=listOf(Tile("المنتجات",Icons.Default.ShoppingBag),Tile("نقاط البيع",Icons.Default.PointOfSale),Tile("عمليات المبيعات",Icons.Default.ReceiptLong),Tile("حسابات العملاء",Icons.Default.Groups),Tile("المخزون",Icons.Default.Inventory2),Tile("الحسابات",Icons.Default.AccountBalanceWallet),Tile("التقارير",Icons.Default.Assessment),Tile("إدارة البرنامج",Icons.Default.Settings),Tile("فترة العمل",Icons.Default.Schedule))
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(topBar={if(page!="الرئيسية")TopAppBar(title={Text(page,fontWeight=FontWeight.Bold)},navigationIcon={IconButton(onClick={page="الرئيسية"}){Icon(Icons.Default.ArrowBack,"رجوع")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.White))},containerColor=Bg){pad->
            key(revision){when(page){
                "الرئيسية"->Home(db,tiles,pad){page=it}
                "المنتجات"->Products(db,pad){revision++}
                "نقاط البيع"->POS(db,pad,initialLines=pendingLines,done={revision++},openSettlement={lines->pendingLines=lines;page="تسوية الحساب"})
                "تسوية الحساب"->SettlementScreen(db,pendingLines,pad,onBack={page="نقاط البيع"},onDone={revision++;pendingLines= emptyList();page="نقاط البيع"})
                "عمليات المبيعات"->ListPage("عمليات المبيعات",db.invoices(),pad)
                "حسابات العملاء"->Customers(db,pad){revision++}
                "المخزون"->Inventory(db,pad){revision++}
                "الحسابات"->InfoPage("الحسابات",listOf("مبيعات اليوم: ${fmt(db.totals().first)} ج.م","المستحقات: ${fmt(db.totals().second)} ج.م","قيمة المخزون بالتكلفة: ${fmt(db.stockValue())} ج.م"),pad)
                "التقارير"->InfoPage("التقارير",listOf("مبيعات اليوم: ${fmt(db.totals().first)} ج.م","المستحقات: ${fmt(db.totals().second)} ج.م","عدد فواتير اليوم: ${db.totals().third}","قيمة المخزون: ${fmt(db.stockValue())} ج.م"),pad)
                "إدارة البرنامج"->ProgramManagementMenu(pad){page=it}
                "حذف المنتجات","تعديل المنتجات","تعديل الأسعار"->ProductManagement(db,page,pad){revision++}
                "فترة العمل"->Work(db,pad){revision++}
            }}
        }
    }
}
@Composable private fun Home(db:LocalDb,tiles:List<Tile>,pad:PaddingValues,open:(String)->Unit){val t=db.totals();Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){Text("Qmax Sale",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink);Text("إدارة المبيعات والمخزون",color=Color.Gray);Spacer(Modifier.height(14.dp));Card(colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("ملخص اليوم",fontWeight=FontWeight.Bold,fontSize=17.sp);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("مبيعات اليوم",fmt(t.first));Metric("المستحقات",fmt(t.second))};Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("عدد الفواتير",t.third.toString());Metric("رصيد المخزون",fmt(db.stockValue()))}}};Spacer(Modifier.height(14.dp));LazyVerticalGrid(columns=GridCells.Fixed(3),modifier=Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){items(tiles){tile->Card(Modifier.height(112.dp).clickable{open(tile.name)},colors=CardDefaults.cardColors(containerColor=Blue)){Column(Modifier.fillMaxSize().padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(tile.icon,tile.name,tint=Color.White,modifier=Modifier.size(30.dp));Spacer(Modifier.height(7.dp));Text(tile.name,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}}}}
@Composable private fun Metric(label:String,value:String){Column{Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=Ink,fontWeight=FontWeight.Bold,fontSize=16.sp)}}
@Composable private fun Products(db:LocalDb,pad:PaddingValues,done:()->Unit){
    var n by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var bar by remember{mutableStateOf("")};var cat by remember{mutableStateOf("")};var cost by remember{mutableStateOf("0")};var price by remember{mutableStateOf("")};var qty by remember{mutableStateOf("0")};var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("إضافة منتج",fontWeight=FontWeight.Bold,fontSize=18.sp)
        Input("اسم المنتج",n,{n=it});Input("كود المنتج",code,{code=it});Input("الباركود",bar,{bar=it});Input("التصنيف",cat,{cat=it})
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Input("سعر الشراء",cost,{cost=it},Modifier.weight(1f),true);Input("سعر البيع *",price,{price=it},Modifier.weight(1f),true)}
        Input("الكمية الافتتاحية",qty,{qty=it},numeric=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=13.sp)
        Button(onClick={val selling=price.toDoubleOrNull();if(n.isBlank()){error="اسم المنتج مطلوب"}else if(selling==null||selling<=0.0){error="السعر مطلوب، أدخل سعر بيع صحيحًا"}else{db.addProduct(n,code,bar,cat,cost.toDoubleOrNull()?:0.0,selling,qty.toDoubleOrNull()?:0.0);n="";code="";bar="";cat="";cost="0";price="";qty="0";error="";done()}},Modifier.fillMaxWidth()){Text("حفظ المنتج")}
        Text("قائمة المنتجات",fontWeight=FontWeight.Bold)
        LazyColumn{items(db.products()){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","الكود ${p.code} | الكمية ${p.qty} | التكلفة ${fmt(p.cost)}")}}
    }
}

@Composable private fun ProgramManagementMenu(pad:PaddingValues,open:(String)->Unit){
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("إدارة البرنامج",fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text("إدارة بيانات المنتجات وأسعارها",color=Color.Gray)
        Spacer(Modifier.height(10.dp))
        listOf("حذف المنتجات" to "حذف منتج من القائمة مع تأكيد قبل الحذف","تعديل المنتجات" to "تعديل الاسم والكود والباركود والتصنيف والتكلفة","تعديل الأسعار" to "تعديل سعر البيع فقط دون تغيير بيانات المنتج").forEach{(title,sub)->
            RowCard(title,sub){open(title)}
        }
    }
}

@Composable private fun ProductManagement(db:LocalDb,mode:String,pad:PaddingValues,done:()->Unit){
    var selected by remember{mutableStateOf<Product?>(null)}
    var showDeleteConfirm by remember{mutableStateOf(false)}
    var name by remember(selected){mutableStateOf(selected?.name?:"")}
    var code by remember(selected){mutableStateOf(selected?.code?:"")}
    var barcode by remember(selected){mutableStateOf(selected?.barcode?:"")}
    var category by remember(selected){mutableStateOf(selected?.category?:"")}
    var cost by remember(selected){mutableStateOf(selected?.cost?.toString()?:"0")}
    var price by remember(selected){mutableStateOf(selected?.price?.toString()?:"")}
    var error by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text(mode,fontWeight=FontWeight.Bold,fontSize=21.sp,color=Ink)
        Text(when(mode){"حذف المنتجات"->"اختر المنتج المراد حذفه";"تعديل المنتجات"->"اختر المنتج لتعديل بياناته";else->"اختر المنتج لتعديل سعر البيع"},color=Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyColumn{items(db.products(),key={it.id}){p->
            Card(Modifier.fillMaxWidth().padding(vertical=4.dp).clickable{selected=p;if(mode=="حذف المنتجات")showDeleteConfirm=true},colors=CardDefaults.cardColors(containerColor=Color.White)){
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){
                    Column(Modifier.weight(1f)){Text(p.name,fontWeight=FontWeight.SemiBold,color=Ink);Text("السعر: ${fmt(p.price)} ج.م  |  الكود: ${p.code}",fontSize=12.sp,color=Color.Gray)}
                    Text(when(mode){"حذف المنتجات"->"حذف";"تعديل المنتجات"->"تعديل";else->"السعر"},color=Blue,fontWeight=FontWeight.Bold)
                }
            }
        }}
    }
    if(mode=="تعديل المنتجات"&&selected!=null){
        AlertDialog(onDismissRequest={selected=null},title={Text("تعديل بيانات المنتج")},text={Column{Input("اسم المنتج",name,{name=it});Input("كود المنتج",code,{code=it});Input("الباركود",barcode,{barcode=it});Input("التصنيف",category,{category=it});Input("سعر الشراء",cost,{cost=it},numeric=true);Text("سعر البيع لا يتغير من هنا؛ استخدم تعديل الأسعار.",fontSize=12.sp,color=Color.Gray);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val c=cost.toDoubleOrNull();if(name.isBlank())error="اسم المنتج مطلوب" else if(c==null||c<0.0)error="أدخل تكلفة صحيحة" else{db.updateProductDetails(selected!!.id,name,code,barcode,category,c);selected=null;error="";done()}}){Text("حفظ")}},dismissButton={TextButton(onClick={selected=null}){Text("إلغاء")}})
    }
    if(mode=="تعديل الأسعار"&&selected!=null){
        AlertDialog(onDismissRequest={selected=null},title={Text("تعديل سعر ${selected!!.name}")},text={Column{Input("سعر البيع الجديد *",price,{price=it},numeric=true);if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}},confirmButton={TextButton(onClick={val v=price.toDoubleOrNull();if(v==null||v<=0.0)error="السعر مطلوب ويجب أن يكون أكبر من صفر" else{db.updateProductPrice(selected!!.id,v);selected=null;price="";error="";done()}}){Text("حفظ السعر")}},dismissButton={TextButton(onClick={selected=null;error=""}){Text("إلغاء")}})
    }
    if(mode=="حذف المنتجات"&&showDeleteConfirm&&selected!=null){
        AlertDialog(onDismissRequest={showDeleteConfirm=false;selected=null},title={Text("تأكيد حذف المنتج")},text={Text("هل تريد حذف ${selected!!.name}؟ ستظل تفاصيله وأسعاره المسجلة في الفواتير القديمة محفوظة.")},confirmButton={TextButton(onClick={db.deleteProduct(selected!!.id);showDeleteConfirm=false;selected=null;done()}){Text("حذف")}},dismissButton={TextButton(onClick={showDeleteConfirm=false;selected=null}){Text("إلغاء")}})
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun POS(db:LocalDb,pad:PaddingValues,initialLines:List<Pair<Product,Double>>,done:()->Unit,openSettlement:(List<Pair<Product,Double>>)->Unit){
    val products=db.products();var cart by remember(initialLines){mutableStateOf(initialLines.associate{it.first.id to it.second})}
    val lines=products.filter{(cart[it.id]?:0.0)>0}.map{it to (cart[it.id]?:0.0)}
    val total=lines.sumOf{it.first.price*it.second}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("اختر المنتجات لإضافتها للفاتورة",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(onClick={val p=products.firstOrNull();if(p!=null)cart=cart+(p.id to ((cart[p.id]?:0.0)+1))}){Text("نقدي سريع")}
            OutlinedButton(onClick={if(lines.isNotEmpty())openSettlement(lines)} ,enabled=lines.isNotEmpty()){Text("تسوية الحساب")}
        }
        LazyColumn(Modifier.weight(1f)){
            items(products){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","بالسلة: ${cart[p.id]?:0.0} — المتاح ${p.qty} — اضغط للإضافة"){cart=cart+(p.id to ((cart[p.id]?:0.0)+1))}}
        }
        Text("إجمالي الفاتورة: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold)
        Button(onClick={if(lines.isNotEmpty()){db.saveSale(lines,total,"نقدي");cart= emptyMap();done()}},Modifier.fillMaxWidth(),enabled=lines.isNotEmpty()){Text("حفظ نقدي سريع")}
    }
}

@Composable private fun SettlementScreen(db:LocalDb,lines:List<Pair<Product,Double>>,pad:PaddingValues,onBack:()->Unit,onDone:()->Unit){
    val gross=lines.sumOf{it.first.price*it.second}
    var discountText by remember{mutableStateOf("0")}
    var cashText by remember{mutableStateOf("0")}
    var bankText by remember{mutableStateOf("0")}
    var instaText by remember{mutableStateOf("0")}
    var activeMethod by remember{mutableStateOf("نقدي")}
    val discount=(discountText.toDoubleOrNull()?:0.0).coerceIn(0.0,100.0)
    val total=(gross-gross*discount/100.0).coerceAtLeast(0.0)
    val cash=cashText.toDoubleOrNull()?:0.0;val bank=bankText.toDoubleOrNull()?:0.0;val insta=instaText.toDoubleOrNull()?:0.0
    val paid=cash+bank+insta;val remaining=total-paid
    fun updateActive(value:String){when(activeMethod){"نقدي"->cashText=value;"حساب بنكي"->bankText=value;else->instaText=value}}
    Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){
        Text("تسوية الحساب",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink)
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(12.dp)){
                Text("إجمالي الفاتورة: ${fmt(gross)} ج.م",fontWeight=FontWeight.Bold)
                Input("الخصم %",discountText,{discountText=it},numeric=true)
                Text("الإجمالي بعد الخصم: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold,color=Blue)
                Text("المدفوع: ${fmt(paid)} ج.م")
                Text("المتبقي على العميل: ${fmt(remaining)} ج.م",color=if(remaining<0)Color.Red else Ink,fontWeight=FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(8.dp));Text("توزيع المبلغ على طرق الدفع",fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            listOf("نقدي","حساب بنكي","إنستا باي").forEach{m->FilterChip(selected=activeMethod==m,onClick={activeMethod=m},label={Text(m)})}
        }
        Input("مبلغ $activeMethod",when(activeMethod){"نقدي"->cashText;"حساب بنكي"->bankText;else->instaText},{updateActive(it)},numeric=true)
        Text("المتبقي يُسجل على حساب العميل (آجل) تلقائيًا إذا لم يتم دفعه.",color=Color.Gray,fontSize=12.sp)
        Spacer(Modifier.height(6.dp));Text("مبالغ سريعة",fontWeight=FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
            listOf(1,5,10,20,50,100).forEach{v->OutlinedButton(onClick={val current=when(activeMethod){"نقدي"->cash;"حساب بنكي"->bank;else->insta};updateActive((current+v).toString())},modifier=Modifier.weight(1f),contentPadding=PaddingValues(2.dp)){Text(v.toString(),fontSize=11.sp)}}
        }
        Text("لوحة إدخال سريعة",fontWeight=FontWeight.SemiBold)
        val keys=listOf("7","8","9","4","5","6","1","2","3","0","00","⌫")
        keys.chunked(3).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){row.forEach{k->OutlinedButton(onClick={val current=when(activeMethod){"نقدي"->cashText;"حساب بنكي"->bankText;else->instaText};val next=if(k=="⌫")current.dropLast(1).ifBlank{"0"}else if(current=="0")k else current+k;updateActive(next)},modifier=Modifier.weight(1f)){Text(k)}}}}
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick=onBack,modifier=Modifier.weight(1f)){Text("رجوع")}
            Button(onClick={if(remaining>=-0.009&&cash>=0&&bank>=0&&insta>=0&&lines.isNotEmpty()){db.saveSale(lines,mapOf("نقدي" to cash,"حساب بنكي" to bank,"إنستا باي" to insta),discount);onDone()}},modifier=Modifier.weight(1f),enabled=remaining>=-0.009&&cash>=0&&bank>=0&&insta>=0&&lines.isNotEmpty()){Text("تأكيد التسوية")}
        }
    }
}

@Composable private fun Customers(db:LocalDb,pad:PaddingValues,done:()->Unit){var n by remember{mutableStateOf("")};var m by remember{mutableStateOf("")};var g by remember{mutableStateOf("")};var a by remember{mutableStateOf("")};var s by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("إضافة عميل",fontWeight=FontWeight.Bold);Input("اسم العميل",n,{n=it});Input("رقم الموبايل",m,{m=it});Input("المحافظة",g,{g=it});Input("المنطقة",a,{a=it});Input("اسم المحل",s,{s=it});Button(onClick={if(n.isNotBlank()){db.addCustomer(n,m,g,a,s);n="";m="";g="";a="";s="";done()}},Modifier.fillMaxWidth()){Text("حفظ العميل")};Text("العملاء",fontWeight=FontWeight.Bold);LazyColumn{items(db.customers()){RowCard(it)}}}}
@Composable private fun Inventory(db:LocalDb,pad:PaddingValues,done:()->Unit){var n by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var q by remember{mutableStateOf("0")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("أصناف المخزون",fontWeight=FontWeight.Bold);Input("اسم صنف المخزون",n,{n=it});Input("الباركود",b,{b=it});Input("الكمية الافتتاحية",q,{q=it},numeric=true);Button(onClick={if(n.isNotBlank()){db.addStock(n,b,q.toDoubleOrNull()?:0.0);n="";b="";q="0";done()}},Modifier.fillMaxWidth()){Text("إضافة صنف")};Text("الأصناف المسجلة",fontWeight=FontWeight.Bold);LazyColumn{items(db.stockItems()){RowCard(it)}}}}
@Composable private fun Work(db:LocalDb,pad:PaddingValues,done:()->Unit){var cash by remember{mutableStateOf("0")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("فترة العمل",fontWeight=FontWeight.Bold,fontSize=20.sp);RowCard(db.period());Input("النقدية الافتتاحية",cash,{cash=it},numeric=true);Button(onClick={db.openPeriod(cash.toDoubleOrNull()?:0.0);done()},Modifier.fillMaxWidth()){Text("فتح فترة عمل")};OutlinedButton(onClick={db.closePeriod();done()},Modifier.fillMaxWidth()){Text("إنهاء فترة العمل")}}}
@Composable private fun ListPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);if(data.isEmpty())Text("لا توجد سجلات حتى الآن",color=Color.Gray);LazyColumn{items(data){RowCard(it)}}}}
@Composable private fun InfoPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);data.forEach{RowCard(it)}}}
@Composable private fun Input(label:String,value:String,onChange:(String)->Unit,modifier:Modifier=Modifier,numeric:Boolean=false){OutlinedTextField(value,onChange,modifier.fillMaxWidth().padding(vertical=3.dp),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(numeric)KeyboardType.Decimal else KeyboardType.Text))}
@Composable private fun RowCard(title:String,sub:String="",click:(()->Unit)?=null){Card(Modifier.fillMaxWidth().padding(vertical=4.dp).then(if(click!=null)Modifier.clickable{click()}else Modifier),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text(title,fontWeight=FontWeight.SemiBold,color=Ink);if(sub.isNotBlank())Text(sub,color=Color.Gray,fontSize=12.sp)}}}
private fun fmt(v:Double)="%.2f".format(v)
