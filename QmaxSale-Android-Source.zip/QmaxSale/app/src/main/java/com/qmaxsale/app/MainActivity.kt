package com.qmaxsale.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QmaxSaleApp() }
    }
}

private data class HomeItem(val title: String, val icon: ImageVector)

@Composable
fun QmaxSaleApp() {
    val blue = Color(0xFF1677D2)
    val items = listOf(
        HomeItem("المنتجات", Icons.Default.ShoppingBag),
        HomeItem("نقاط البيع", Icons.Default.PointOfSale),
        HomeItem("عمليات المبيعات", Icons.Default.ReceiptLong),
        HomeItem("حسابات العملاء", Icons.Default.Groups),
        HomeItem("المخزون", Icons.Default.Inventory2),
        HomeItem("الحسابات", Icons.Default.AccountBalanceWallet),
        HomeItem("التقارير", Icons.Default.Assessment),
        HomeItem("إدارة البرنامج", Icons.Default.Settings),
        HomeItem("فترة العمل", Icons.Default.Schedule)
    )
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF5F7FA)) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Text("Qmax Sale", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color(0xFF17324D))
                Text("إدارة المبيعات والمخزون", color = Color.Gray, fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text("ملخص اليوم", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            SummaryCell("مبيعات اليوم", "0.00")
                            SummaryCell("المستحقات", "0.00")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            SummaryCell("عدد الفواتير", "0")
                            SummaryCell("التحصيلات", "0.00")
                        }
                        Spacer(Modifier.height(10.dp))
                        SummaryCell("رصيد المخزون", "0")
                    }
                }
                Spacer(Modifier.height(18.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(items) { item ->
                        Card(
                            modifier = Modifier.height(112.dp).clickable { },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = blue),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(Modifier.fillMaxSize().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Icon(item.icon, contentDescription = item.title, tint = Color.White, modifier = Modifier.size(30.dp))
                                Spacer(Modifier.height(8.dp))
                                Text(item.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            }
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun SummaryCell(label: String, value: String) {
    Column {
        Text(label, color = Color.Gray, fontSize = 12.sp)
        Text(value, color = Color(0xFF17324D), fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
