package com.qmaxsale.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1677D2)
private val Ink = Color(0xFF17324D)
private val Bg = Color(0xFFF5F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = LocalDb(this)
        setContent { QmaxApp(db) }
    }
}

private class LocalDb(ctx: Context) : SQLiteOpenHelper(ctx, "qmax_sale.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,barcode TEXT,category TEXT,cost REAL DEFAULT 0,price REAL DEFAULT 0,qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,mobile TEXT,governorate TEXT,area TEXT,shop TEXT,balance REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,total REAL,paid REAL,due REAL,method TEXT)")
        db.execSQL("CREATE TABLE invoice_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_id INTEGER,product_id INTEGER,name TEXT,qty REAL,price REAL,cost REAL)")
        db.execSQL("CREATE TABLE stock_items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,barcode TEXT,qty REAL DEFAULT 0)")
        db.execSQL("CREATE TABLE work_periods(id INTEGER PRIMARY KEY AUTOINCREMENT,opened_at TEXT DEFAULT CURRENT_TIMESTAMP,opening_cash REAL,closed_at TEXT,is_open INTEGER DEFAULT 1)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addProduct(n:String,c:String,b:String,cat:String,cost:Double,price:Double,qty:Double) {
        val v=ContentValues().apply { put("name",n);put("code",c);put("barcode",b);put("category",cat);put("cost",cost);put("price",price);put("qty",qty) }
        writableDatabase.insert("products",null,v)
    }
    fun products():List<Product> { val a=mutableListOf<Product>();readableDatabase.rawQuery("SELECT id,name,code,barcode,category,cost,price,qty FROM products ORDER BY name",null).use { c->while(c.moveToNext())a.add(Product(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"",c.getString(4)?:"",c.getDouble(5),c.getDouble(6),c.getDouble(7))) };return a }
    fun addCustomer(n:String,m:String,g:String,a:String,s:String) { val v=ContentValues().apply{put("name",n);put("mobile",m);put("governorate",g);put("area",a);put("shop",s)};writableDatabase.insert("customers",null,v) }
    fun customers():List<String> { val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT name||' | '||ifnull(mobile,'') FROM customers ORDER BY name",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a }
    fun stockItems():List<String> { val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT name||' | كمية: '||qty FROM stock_items ORDER BY name",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a }
    fun addStock(n:String,b:String,q:Double) { val v=ContentValues().apply{put("name",n);put("barcode",b);put("qty",q)};writableDatabase.insert("stock_items",null,v) }
    fun saveSale(lines:List<Pair<Product,Double>>,paid:Double,method:String) { val total=lines.sumOf{it.first.price*it.second};val d=writableDatabase;d.beginTransaction();try{val v=ContentValues().apply{put("total",total);put("paid",paid);put("due",(total-paid).coerceAtLeast(0.0));put("method",method)};val id=d.insert("invoices",null,v);lines.forEach{(p,q)->val x=ContentValues().apply{put("invoice_id",id);put("product_id",p.id);put("name",p.name);put("qty",q);put("price",p.price);put("cost",p.cost)};d.insert("invoice_lines",null,x);d.execSQL("UPDATE products SET qty=qty-? WHERE id=?",arrayOf(q,p.id))};d.setTransactionSuccessful()}finally{d.endTransaction()} }
    fun invoices():List<String> { val a=mutableListOf<String>();readableDatabase.rawQuery("SELECT 'فاتورة #'||id||' | الإجمالي '||total||' | مدفوع '||paid||' | متبقي '||due FROM invoices ORDER BY id DESC",null).use{c->while(c.moveToNext())a.add(c.getString(0))};return a }
    fun totals():Triple<Double,Double,Int>{readableDatabase.rawQuery("SELECT ifnull(sum(total),0),ifnull(sum(due),0),count(*) FROM invoices WHERE date(created_at)=date('now','localtime')",null).use{it.moveToFirst();return Triple(it.getDouble(0),it.getDouble(1),it.getInt(2))}}
    fun stockValue():Double{readableDatabase.rawQuery("SELECT ifnull(sum(qty*cost),0) FROM products",null).use{it.moveToFirst();return it.getDouble(0)}}
    // Dashboard balances are calculated from persisted opening cash and invoice payments.
    fun cashBalance():Double {
        readableDatabase.rawQuery("SELECT (SELECT ifnull(sum(opening_cash),0) FROM work_periods) + (SELECT ifnull(sum(paid),0) FROM invoices WHERE method='نقدي')",null).use { it.moveToFirst(); return it.getDouble(0) }
    }
    fun instaPayBalance():Double {
        readableDatabase.rawQuery("SELECT ifnull(sum(paid),0) FROM invoices WHERE method='إنستا باي'",null).use { it.moveToFirst(); return it.getDouble(0) }
    }
    fun period():String{readableDatabase.rawQuery("SELECT opened_at,opening_cash FROM work_periods WHERE is_open=1 ORDER BY id DESC LIMIT 1",null).use{if(it.moveToFirst())return "فترة مفتوحة منذ ${it.getString(0)} | افتتاحي ${it.getDouble(1)}"};return "لا توجد فترة عمل مفتوحة"}
    fun openPeriod(cash:Double){writableDatabase.execSQL("UPDATE work_periods SET is_open=0 WHERE is_open=1");val v=ContentValues().apply{put("opening_cash",cash)};writableDatabase.insert("work_periods",null,v)}
    fun closePeriod(){writableDatabase.execSQL("UPDATE work_periods SET is_open=0,closed_at=CURRENT_TIMESTAMP WHERE is_open=1")}
}
private data class Product(val id:Long,val name:String,val code:String,val barcode:String,val category:String,val cost:Double,val price:Double,val qty:Double)
private data class Tile(val name:String,val icon:ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun QmaxApp(db:LocalDb) {
    var page by remember{mutableStateOf("الرئيسية")};var revision by remember{mutableIntStateOf(0)}
    val tiles=listOf(Tile("المنتجات",Icons.Default.ShoppingBag),Tile("نقاط البيع",Icons.Default.PointOfSale),Tile("عمليات المبيعات",Icons.Default.ReceiptLong),Tile("حسابات العملاء",Icons.Default.Groups),Tile("المخزون",Icons.Default.Inventory2),Tile("الحسابات",Icons.Default.AccountBalanceWallet),Tile("التقارير",Icons.Default.Assessment),Tile("إدارة البرنامج",Icons.Default.Settings),Tile("فترة العمل",Icons.Default.Schedule))
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(topBar={if(page!="الرئيسية")TopAppBar(title={Text(page,fontWeight=FontWeight.Bold)},navigationIcon={IconButton(onClick={page="الرئيسية"}){Icon(Icons.Default.ArrowBack,"رجوع")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.White))},containerColor=Bg){pad->
            key(revision){when(page){
                "الرئيسية"->Home(db,tiles,pad){page=it}
                "المنتجات"->Products(db,pad){revision++}
                "نقاط البيع"->POS(db,pad){revision++}
                "عمليات المبيعات"->ListPage("عمليات المبيعات",db.invoices(),pad)
                "حسابات العملاء"->Customers(db,pad){revision++}
                "المخزون"->Inventory(db,pad){revision++}
                "الحسابات"->InfoPage("الحسابات",listOf("مبيعات اليوم: ${fmt(db.totals().first)} ج.م","المستحقات: ${fmt(db.totals().second)} ج.م","قيمة المخزون بالتكلفة: ${fmt(db.stockValue())} ج.م"),pad)
                "التقارير"->InfoPage("التقارير",listOf("مبيعات اليوم: ${fmt(db.totals().first)} ج.م","المستحقات: ${fmt(db.totals().second)} ج.م","عدد فواتير اليوم: ${db.totals().third}","قيمة المخزون: ${fmt(db.stockValue())} ج.م"),pad)
                "إدارة البرنامج"->InfoPage("إدارة البرنامج",listOf("إدارة المنتجات","تعديل أسعار المنتجات","أصناف المخزون","Recipe","إعدادات المستخدمين"),pad)
                "فترة العمل"->Work(db,pad){revision++}
            }}
        }
    }
}
@Composable private fun Home(db:LocalDb,tiles:List<Tile>,pad:PaddingValues,open:(String)->Unit){val t=db.totals();Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)){Text("Qmax Sale",fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink);Text("إدارة المبيعات والمخزون",color=Color.Gray);Spacer(Modifier.height(14.dp));Card(colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("ملخص اليوم",fontWeight=FontWeight.Bold,fontSize=17.sp);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("مبيعات اليوم",fmt(t.first));Metric("المستحقات",fmt(t.second))};Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("عدد الفواتير",t.third.toString());Metric("رصيد المخزون",fmt(db.stockValue()))};Spacer(Modifier.height(10.dp));Divider(color=Bg);Spacer(Modifier.height(8.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("نقدي", "${fmt(db.cashBalance())} ج.م");Metric("إنستا باي", "${fmt(db.instaPayBalance())} ج.م")}}};Spacer(Modifier.height(14.dp));LazyVerticalGrid(columns=GridCells.Fixed(3),modifier=Modifier.fillMaxSize(),horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){items(tiles){tile->Card(Modifier.height(112.dp).clickable{open(tile.name)},colors=CardDefaults.cardColors(containerColor=Blue)){Column(Modifier.fillMaxSize().padding(5.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(tile.icon,tile.name,tint=Color.White,modifier=Modifier.size(30.dp));Spacer(Modifier.height(7.dp));Text(tile.name,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.SemiBold)}}}}}}
@Composable private fun Metric(label:String,value:String){Column{Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=Ink,fontWeight=FontWeight.Bold,fontSize=16.sp)}}
@Composable private fun Products(db:LocalDb,pad:PaddingValues,done:()->Unit){var n by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var bar by remember{mutableStateOf("")};var cat by remember{mutableStateOf("")};var cost by remember{mutableStateOf("0")};var price by remember{mutableStateOf("0")};var qty by remember{mutableStateOf("0")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("إضافة منتج",fontWeight=FontWeight.Bold,fontSize=18.sp);Input("اسم المنتج",n,{n=it});Input("كود المنتج",code,{code=it});Input("الباركود",bar,{bar=it});Input("التصنيف",cat,{cat=it});Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Input("سعر الشراء",cost,{cost=it},Modifier.weight(1f),true);Input("سعر البيع",price,{price=it},Modifier.weight(1f),true)};Input("الكمية الافتتاحية",qty,{qty=it},numeric=true);Button(onClick={if(n.isNotBlank()){db.addProduct(n,code,bar,cat,cost.toDoubleOrNull()?:0.0,price.toDoubleOrNull()?:0.0,qty.toDoubleOrNull()?:0.0);n="";code="";bar="";cat="";done()}},Modifier.fillMaxWidth()){Text("حفظ المنتج")};Text("قائمة المنتجات",fontWeight=FontWeight.Bold);LazyColumn{items(db.products()){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","الكود ${p.code} | الكمية ${p.qty} | التكلفة ${fmt(p.cost)}")}}}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun POS(db:LocalDb,pad:PaddingValues,done:()->Unit){val products=db.products();var cart by remember{mutableStateOf(mapOf<Long,Double>())};var paid by remember{mutableStateOf("0")};var method by remember{mutableStateOf("نقدي")};val total=products.sumOf{it.price*(cart[it.id]?:0.0)};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("اختر المنتجات لإضافتها للفاتورة",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={val p=products.firstOrNull();if(p!=null)cart=cart+(p.id to ((cart[p.id]?:0.0)+1))}){Text("نقدي سريع")};OutlinedButton(onClick={method="تسوية الحساب"}){Text("تسوية الحساب")}};LazyColumn(Modifier.weight(1f)){items(products){p->RowCard("${p.name} | ${fmt(p.price)} ج.م","المتاح ${p.qty} — اضغط للإضافة"){cart=cart+(p.id to ((cart[p.id]?:0.0)+1))}}};Text("إجمالي الفاتورة: ${fmt(total)} ج.م",fontWeight=FontWeight.Bold);Input("المبلغ المدفوع",paid,{paid=it},numeric=true);var expanded by remember{mutableStateOf(false)};ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}){OutlinedTextField(method,{method=it},Modifier.menuAnchor().fillMaxWidth(),readOnly=true,label={Text("طريقة الدفع")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)});ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){listOf("نقدي","حساب بنكي","إنستا باي","حساب العميل").forEach{DropdownMenuItem(text={Text(it)},onClick={method=it;expanded=false})}}};Button(onClick={val lines=products.filter{(cart[it.id]?:0.0)>0}.map{it to (cart[it.id]?:0.0)};if(lines.isNotEmpty()){db.saveSale(lines,paid.toDoubleOrNull()?:0.0,method);cart= emptyMap();paid="0";done()}},Modifier.fillMaxWidth()){Text("حفظ الفاتورة")}}}
@Composable private fun Customers(db:LocalDb,pad:PaddingValues,done:()->Unit){var n by remember{mutableStateOf("")};var m by remember{mutableStateOf("")};var g by remember{mutableStateOf("")};var a by remember{mutableStateOf("")};var s by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("إضافة عميل",fontWeight=FontWeight.Bold);Input("اسم العميل",n,{n=it});Input("رقم الموبايل",m,{m=it});Input("المحافظة",g,{g=it});Input("المنطقة",a,{a=it});Input("اسم المحل",s,{s=it});Button(onClick={if(n.isNotBlank()){db.addCustomer(n,m,g,a,s);n="";m="";g="";a="";s="";done()}},Modifier.fillMaxWidth()){Text("حفظ العميل")};Text("العملاء",fontWeight=FontWeight.Bold);LazyColumn{items(db.customers()){RowCard(it)}}}}
@Composable private fun Inventory(db:LocalDb,pad:PaddingValues,done:()->Unit){var n by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var q by remember{mutableStateOf("0")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("أصناف المخزون",fontWeight=FontWeight.Bold);Input("اسم صنف المخزون",n,{n=it});Input("الباركود",b,{b=it});Input("الكمية الافتتاحية",q,{q=it},numeric=true);Button(onClick={if(n.isNotBlank()){db.addStock(n,b,q.toDoubleOrNull()?:0.0);n="";b="";q="0";done()}},Modifier.fillMaxWidth()){Text("إضافة صنف")};Text("الأصناف المسجلة",fontWeight=FontWeight.Bold);LazyColumn{items(db.stockItems()){RowCard(it)}}}}
@Composable private fun Work(db:LocalDb,pad:PaddingValues,done:()->Unit){var cash by remember{mutableStateOf("0")};Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text("فترة العمل",fontWeight=FontWeight.Bold,fontSize=20.sp);RowCard(db.period());Input("النقدية الافتتاحية",cash,{cash=it},numeric=true);Button(onClick={db.openPeriod(cash.toDoubleOrNull()?:0.0);done()},Modifier.fillMaxWidth()){Text("فتح فترة عمل")};OutlinedButton(onClick={db.closePeriod();done()},Modifier.fillMaxWidth()){Text("إنهاء فترة العمل")}}}
@Composable private fun ListPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);if(data.isEmpty())Text("لا توجد سجلات حتى الآن",color=Color.Gray);LazyColumn{items(data){RowCard(it)}}}}
@Composable private fun InfoPage(title:String,data:List<String>,pad:PaddingValues){Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);data.forEach{RowCard(it)}}}
@Composable private fun Input(label:String,value:String,onChange:(String)->Unit,modifier:Modifier=Modifier,numeric:Boolean=false){OutlinedTextField(value,onChange,modifier.fillMaxWidth().padding(vertical=3.dp),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=if(numeric)KeyboardType.Decimal else KeyboardType.Text))}
@Composable private fun RowCard(title:String,sub:String="",click:(()->Unit)?=null){Card(Modifier.fillMaxWidth().padding(vertical=4.dp).then(if(click!=null)Modifier.clickable{click()}else Modifier),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text(title,fontWeight=FontWeight.SemiBold,color=Ink);if(sub.isNotBlank())Text(sub,color=Color.Gray,fontSize=12.sp)}}}
private fun fmt(v:Double)="%.2f".format(v)
