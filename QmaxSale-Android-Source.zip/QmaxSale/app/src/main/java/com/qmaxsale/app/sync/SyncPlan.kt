package com.qmaxsale.app.sync

/**
 * Offline-first synchronization contract.
 * Local Room data is the source of truth while offline. The sync worker will upload
 * pending rows using stable UUIDs, then mark them synced only after server confirmation.
 * Conflict policy: server records are not overwritten by stale local timestamps;
 * invoice and stock movement records are append-only and deduplicated by UUID.
 */
interface SyncPlan {
    suspend fun synchronizePendingChanges()
}

object SupabaseConfig {
    // Configure through BuildConfig/local.properties before enabling cloud sync.
    const val PROJECT_URL = ""
    const val ANON_KEY = ""
}
