-- Qmax Sale cloud schema starter. Run in Supabase SQL Editor after creating a project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key,
  name text not null,
  code text,
  barcode text,
  category text not null default 'عام',
  purchase_cost numeric(14,2) not null default 0,
  selling_price numeric(14,2) not null default 0,
  stock_quantity numeric(14,3) not null default 0,
  image_path text,
  updated_at timestamptz not null default now()
);
create unique index if not exists products_code_unique on public.products(code) where code is not null and code <> '';
create unique index if not exists products_barcode_unique on public.products(barcode) where barcode is not null and barcode <> '';

create table if not exists public.customers (
  id uuid primary key,
  name text not null,
  mobile text,
  governorate text,
  area text,
  shop_name text,
  customer_code text,
  balance numeric(14,2) not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.work_periods (
  id uuid primary key,
  opened_at timestamptz not null,
  opening_cash numeric(14,2) not null default 0,
  closed_at timestamptz,
  closing_cash numeric(14,2),
  is_open boolean not null default true
);

create table if not exists public.sales_invoices (
  id uuid primary key,
  invoice_number text not null unique,
  customer_id uuid references public.customers(id),
  work_period_id uuid references public.work_periods(id),
  created_at timestamptz not null default now(),
  subtotal numeric(14,2) not null,
  discount numeric(14,2) not null default 0,
  total numeric(14,2) not null,
  paid numeric(14,2) not null default 0,
  due numeric(14,2) not null default 0,
  status text not null default 'completed'
);

create table if not exists public.sales_invoice_lines (
  id uuid primary key,
  invoice_id uuid not null references public.sales_invoices(id) on delete cascade,
  product_id uuid not null references public.products(id),
  product_name_snapshot text not null,
  quantity numeric(14,3) not null,
  purchase_cost_snapshot numeric(14,2) not null,
  selling_price_snapshot numeric(14,2) not null,
  line_total numeric(14,2) not null
);

create table if not exists public.stock_items (
  id uuid primary key,
  name text not null,
  code text,
  barcode text,
  unit text not null default 'قطعة',
  quantity numeric(14,3) not null default 0,
  minimum_quantity numeric(14,3) not null default 0
);
create table if not exists public.recipes (
  id uuid primary key,
  product_id uuid not null references public.products(id),
  stock_item_id uuid not null references public.stock_items(id),
  quantity_per_product numeric(14,3) not null default 1,
  unit text not null default 'قطعة'
);
create table if not exists public.stock_movements (
  id uuid primary key,
  stock_item_id uuid not null references public.stock_items(id),
  movement_type text not null,
  quantity numeric(14,3) not null,
  before_quantity numeric(14,3) not null,
  after_quantity numeric(14,3) not null,
  reason text,
  source_invoice_id uuid,
  created_at timestamptz not null default now(),
  work_period_id uuid references public.work_periods(id)
);

create table if not exists public.stock_add_invoices (
  id uuid primary key,
  created_at timestamptz not null default now(),
  note text
);
create table if not exists public.stock_add_lines (
  id uuid primary key,
  invoice_id uuid not null references public.stock_add_invoices(id) on delete cascade,
  stock_item_id uuid not null references public.stock_items(id),
  quantity numeric(14,3) not null check (quantity > 0)
);

create table if not exists public.payments (
  id uuid primary key,
  invoice_id uuid references public.sales_invoices(id),
  customer_id uuid references public.customers(id),
  work_period_id uuid references public.work_periods(id),
  method text not null check (method in ('cash','bank','instapay','customer_credit')),
  amount numeric(14,2) not null,
  created_at timestamptz not null default now()
);

-- Enable RLS before production use. Policies are intentionally not opened globally.
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.work_periods enable row level security;
alter table public.sales_invoices enable row level security;
alter table public.sales_invoice_lines enable row level security;
alter table public.stock_items enable row level security;
alter table public.recipes enable row level security;
alter table public.stock_movements enable row level security;
alter table public.stock_add_invoices enable row level security;
alter table public.stock_add_lines enable row level security;
alter table public.payments enable row level security;
