# Qmax Sale — Android project starter

This is the first source-project foundation for the agreed Qmax Sale app.

## Included in this first delivery
- Native Android app project using Kotlin + Jetpack Compose.
- Dashboard matching the agreed 3×3 blue-tile arrangement and daily summary panel.
- Local Room database entities for products, customers, work periods, invoices, invoice lines, stock items, recipes, stock movements, and payments.
- Supabase SQL schema starter for cloud persistence.
- Offline-first synchronization contract and notes.

## Important status
This is a project foundation, **not yet the completed POS/accounting application and not a tested APK**. The dashboard tiles are currently visual entry points; their screens and transaction workflows still need implementation and device testing. Supabase credentials and secure account/RLS policies must be configured before cloud synchronization is enabled.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

- Minimum Android version: Android 8.0 (API 26) in this starter configuration.
- For the user's Android 10 phone, this is compatible.
- Do not place the Supabase service-role key inside the Android app. Use only a restricted anon/publishable key with correctly configured RLS.

## Next implementation stages
1. Login and user administration with securely managed authentication.
2. Product/category management, barcode lookup and image upload.
3. POS cart, cash shortcut, settlement screen, split payments and invoice history.
4. Customer balances and collections.
5. Inventory items, recipes and automatic stock movement recording.
6. Work-period open/close and retained period reports.
7. Accounting, profit reports and Supabase background synchronization with conflict handling.

## Offline data safety
Room is the local source of truth. Invoice IDs and movement IDs are designed to be stable UUIDs for idempotent synchronization. Before production use, add database migrations and tested backup/restore procedures; do not use destructive migration on real data.

## Build APK from GitHub using a phone
The repository includes `.github/workflows/android-debug.yml`. After uploading the project contents to a GitHub repository, open **Actions**, select **Build Qmax Sale debug APK**, choose **Run workflow**, and download the `QmaxSale-debug-apk` artifact after the run succeeds.

## Settlement update
- The settlement screen now starts with the invoice gross amount in the cash amount field; this amount remains editable.
- Payment allocations can be split across cash, bank account, InstaPay, and customer account.
- Customer-account allocations are recorded as receivables and are not counted as cash received.
- The `حفظ وإغلاق` action stores the invoice and payment allocations, then returns to the home screen after a successful save.
- A remaining balance requires a selected customer so the receivable is attached to the correct customer.

## Invoice history and sales movements update (source changes)
- Added a dedicated **الفواتير** home tile with search by invoice number, customer name, or phone.
- Invoice view shows date/number, customer name and phone, shop name, governorate, payment method and payment allocations, item rows, totals, paid amount and remaining balance.
- Renamed **عمليات المبيعات** to **حركة المبيعات** and added per-invoice view, edit, and delete actions.
- Invoice editing supports changing existing item quantities/prices and removing an item. Product stock is adjusted by the quantity difference and invoice totals/customer due are recalculated. Existing payment/collection movements are preserved; an edit that would make the invoice total lower than the amount already paid is rejected.
- Confirmed invoice deletion removes its payment movements and invoice rows, restores sold quantities to the product stock, and recalculates customer outstanding balances from the remaining invoices.

**Build/test status:** Source-level changes were checked and the SQLite reversal statements were simulated. A full Android Gradle build and on-device test were not run in this environment; build the debug APK with the included GitHub Actions workflow or Android Studio before relying on it for live sales.
