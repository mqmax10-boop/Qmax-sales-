# Qmax Sale — Android source project

مشروع أندرويد باستخدام Kotlin وJetpack Compose، مع قاعدة بيانات SQLite محلية للعمل دون اتصال.

## التحديثات الموجودة في هذه النسخة
- شاشة رئيسية وملخص يومي، مع تصحيح استعلام مبيعات اليوم لاستخدام التاريخ المحلي.
- شاشة الفواتير وحركة المبيعات وتعديل/حذف الفاتورة وعكس المدفوعات والمخزون.
- إدارة المنتجات والعملاء وطرق الدفع والحسابات والتقارير.
- إدارة المخزون، وحدات الأصناف، الريسبي، فواتير إضافة المخزون، وسجلات الحركة.
- شاشة المخزون تعرض اسم الصنف والوحدة والمباع والوارد والرصيد الحالي.
- الريسبي: الضغط على السجل لا يحذفه؛ توجد أزرار تعديل وحذف مع تأكيد قبل الحذف.
- إدارة مستخدمين بصلاحيات مستقلة محفوظة لكل مستخدم بمربعات اختيار؛ جميع أيقونات الشاشة الرئيسية تظل ظاهرة وواضحة، والضغط على قسم غير مسموح به لا يفتحه. الضغط على اسم المستخدم يعرض بياناته، مع زري تعديل وحذف منفصلين. كلمات المرور مخزنة باستخدام PBKDF2 مع salt عشوائي.
- النسخ الاحتياطي إلى مجلد يختاره المستخدم، وإنشاء نسخة يدوية أو تلقائية عند إنهاء فترة العمل، واستعادة ملف ZIP بعد التحقق من سلامة قاعدة SQLite.

## بيانات الدخول الأولية
- اسم المستخدم: `admin`
- كلمة المرور الأولية: `1234`
- أنشئ حساب مدير بكلمة مرور جديدة من إدارة البرنامج > المستخدمون، ثم استخدم الحساب الجديد. لا تترك كلمة المرور الأولية مستخدمة في التشغيل الفعلي.

## ملاحظات مهمة
- هذا التسليم يحتوي على تحديثات المصدر المذكورة أعلاه، لكنه **لم يُبنَ كـ APK ولم يُختبر على جهاز فعلي في هذه الجلسة**.
- اختيار اللغة عربي/English وتطبيق الترجمة على كل الشاشات لم يُستكمل بعد. كذلك زر Clear All Transactions مع النسخ الاحتياطي التلقائي قبله لم يُنفذ في هذه النسخة.
- المزامنة السحابية مع Supabase غير مفعّلة؛ يلزم إعداد المفاتيح وسياسات RLS واختبارها.
- النسخة الاحتياطية تضم ملف قاعدة البيانات المحلية وملفات تفضيلات التطبيق. الصور/الملفات الخارجية التي لا تُخزن داخل قاعدة البيانات ليست ضمن ملف ZIP الحالي.
- قبل استخدام بيانات حقيقية، اختبر النسخ والاستعادة على نسخة تجريبية أولًا.

## البناء
افتح المجلد في Android Studio، نفّذ Gradle Sync، ثم Build > Build APK(s). الحد الأدنى Android 8 (API 26)، وهو متوافق من حيث الحد الأدنى مع Android 10.

يمكن استخدام GitHub Actions المرفق: ارفع محتويات المشروع إلى GitHub، ثم افتح Actions وشغّل **Build Qmax Sale debug APK**، وبعد نجاح التشغيل نزّل artifact باسم `QmaxSale-debug-apk`.

## Language and Clear All Transactions update
- Added an Arabic / English language selector under Program Management. The selected value is persisted in app preferences.
- Added English labels for the sign-in screen, dashboard tiles and summary, program-management menu, top bar, and backup/restore/clear screen. Other detailed feature screens still contain Arabic labels and need a full translation pass before the entire application can be described as fully bilingual.
- Added Clear All Transactions in Backup and Restore. The operation creates a ZIP backup first (using the selected backup folder, or an internal app safety-backup location if no folder is selected). If backup creation fails, no data is deleted.
- After a successful backup, sales invoices, invoice lines, payment records, stock movement/addition records, and work periods are cleared. Product and stock-item definitions, customer records, recipes, users, and settings remain; product/stock quantities and customer balances are reset to zero.
