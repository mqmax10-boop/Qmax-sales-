# Qmax Sale — Android project starter

This is the first source-project foundation for the agreed Qmax Sale app.

## Included in this first delivery
- Native Android app project using Kotlin + Jetpack Compose.
- Dashboard matching the agreed 3×3 blue-tile arrangement and daily summary panel.
- Local Room database entities for products, customers, work periods, invoices, invoice lines, stock items, recipes, stock movements, and payments.
- Supabase SQL schema starter for cloud persistence.
- Offline-first synchronization contract and notes.

## Important status
This is a project foundation, **not yet the completed POS/accounting application and not a tested APK**. The dashboard tiles are currently visual entry points; their screens and transaction workflows still need implementation and device testing. Supabase credentials and secure account/RLS policies must be configured before cloud synchronization is enabled.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

- Minimum Android version: Android 8.0 (API 26) in this starter configuration.
- For the user's Android 10 phone, this is compatible.
- Do not place the Supabase service-role key inside the Android app. Use only a restricted anon/publishable key with correctly configured RLS.

## Next implementation stages
1. Login and user administration with securely managed authentication.
2. Product/category management, barcode lookup and image upload.
3. POS cart, cash shortcut, settlement screen, split payments and invoice history.
4. Customer balances and collections.
5. Inventory items, recipes and automatic stock movement recording.
6. Work-period open/close and retained period reports.
7. Accounting, profit reports and Supabase background synchronization with conflict handling.

## Offline data safety
Room is the local source of truth. Invoice IDs and movement IDs are designed to be stable UUIDs for idempotent synchronization. Before production use, add database migrations and tested backup/restore procedures; do not use destructive migration on real data.

## Build APK from GitHub using a phone
The repository includes `.github/workflows/android-debug.yml`. After uploading the project contents to a GitHub repository, open **Actions**, select **Build Qmax Sale debug APK**, choose **Run workflow**, and download the `QmaxSale-debug-apk` artifact after the run succeeds.


## سجل حركة المبيعات
- لكل فاتورة رقم فريد، وتُربط بفترة العمل المفتوحة.
- تحفظ بنود الفاتورة باسم المنتج والكمية وسعر البيع وتكلفة الشراء وقت البيع.
- ينشأ سجل مستقل لكل بند في جدول `sales_movements`، يشمل رقم الفاتورة والمنتج والكمية والسعر والتكلفة وإجمالي السطر والمخزون قبل/بعد الحركة والتاريخ وفترة العمل.
- حفظ الفاتورة وبنودها وخصم المخزون وحركات المبيعات عملية SQLite ذرية؛ أي فشل يلغي العملية كلها.
- لا يسمح بالبيع دون فترة مفتوحة، ولا بإغلاق فترة تحتوي فواتير آجلة/غير مسددة.
- تمت إضافة ترقية محلية من قاعدة الإصدار 1 إلى 2 مع الحفاظ على البيانات الموجودة.
